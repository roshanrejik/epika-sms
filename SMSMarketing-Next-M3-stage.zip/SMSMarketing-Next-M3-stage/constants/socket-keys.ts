export const socketKeys = {
  conversationId: 'conversationId',
};
