import { styled } from '@mui/material/styles';
import { FormControl, OutlinedInput, TextField } from '@mui/material';

export const btnstyle = { margin: '20px 0', backgroundColor: 'var(--epika-primary-color)' };

export const StyledTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: theme.shape.borderRadius,
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
      borderColor: 'var(--epika-primary-color)',
    },
    '&.Mui-error .MuiOutlinedInput-notchedOutline': {
      borderColor: theme.palette.error.main,
    },
  },
  '& .MuiInputLabel-root': {
    '&.Mui-focused': {
      color: 'var(--epika-primary-color)',
    },
    '&.Mui-error': {
      color: theme.palette.error.main,
    },
    '&.Mui-focused.Mui-error': {
      color: theme.palette.error.main,
    },
  },
}));

export const CustomFormControl = styled(FormControl)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: theme.shape.borderRadius,
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
      borderColor: 'var(--epika-primary-color)',
    },
    '&.Mui-error .MuiOutlinedInput-notchedOutline': {
      borderColor: theme.palette.error.main,
    },
  },
  '& .MuiInputLabel-root': {
    '&.Mui-focused': {
      color: 'var(--epika-primary-color)',
    },
    '&.Mui-error': {
      color: theme.palette.error.main,
    },
    '&.Mui-focused.Mui-error': {
      color: theme.palette.error.main,
    },
  },
}));

export const CustomOutlinedInput = styled(OutlinedInput)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: theme.shape.borderRadius,
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
      borderColor: 'var(--epika-primary-color)',
    },
    '&.Mui-error .MuiOutlinedInput-notchedOutline': {
      borderColor: theme.palette.error.main,
    },
  },
  '& .MuiInputLabel-root': {
    '&.Mui-focused': {
      color: 'var(--epika-primary-color)',
    },
    '&.Mui-error': {
      color: theme.palette.error.main,
    },
    '&.Mui-focused.Mui-error': {
      color: theme.palette.error.main,
    },
  },
}));

export const getEntityType = (name: string): string => {
  if (name.includes('/admin/teams/')) return 'Team';
  if (name.includes('/admin/agents/')) return 'Agent';
  if (name.includes('/admin/roles-and-permissions/')) return 'Role';
  if (name.includes('/customers/')) return 'Customer';
  if (name.includes('/campaigns/')) return 'Campaign';
  if (name.includes('/canned/')) return 'Canned response';
  if (name.includes('/followups/')) return 'Follow ups';
  if (name.includes('/messages/')) return 'Messages Export/Import';
  if (name.includes('/plugins/')) return 'Web plugin';
  return '';
};
