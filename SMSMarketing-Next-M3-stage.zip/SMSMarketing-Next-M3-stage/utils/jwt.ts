import cookies from './cookies';

export const checkPathnameWithToken = (pathname: any) => {
  if (
    pathname === '/' ||
    pathname === '/auth/email/' ||
    pathname === '/auth/signUp/' ||
    pathname === '/auth/forgotPassword/' ||
    pathname === '/auth/aboutYourself/' ||
    pathname === '/auth/password/' ||
    pathname === '/auth/emailConfirmation/' ||
    pathname === '/auth/accountCreated/' ||
    pathname === '/auth/passwordChangedSuccessfully/' ||
    pathname === '/auth/setNewPassword/'
  )
    return true;
};

export const checkPathnameWithoutToken = (accessToken: any, pathname: any) => {
  if (
    accessToken ||
    pathname === '/auth/email/' ||
    pathname === '/auth/signUp/' ||
    pathname === '/auth/forgotPassword/' ||
    pathname === '/auth/aboutYourself/' ||
    pathname === '/auth/password/' ||
    pathname === '/auth/emailConfirmation/' ||
    pathname === '/auth/accountCreated/' ||
    pathname === '/auth/passwordChangedSuccessfully/' ||
    pathname === '/auth/setNewPassword/'
  )
    return true;
};

export const routeToRoot = (accessToken: any, pathname: any) => {
  if (!accessToken && pathname === '/') return true;
};

export const logoutSession = () => {
  cookies.remove('accessToken', { path: '/' });
  cookies.remove('refreshToken', { path: '/' });
  cookies.remove('email', { path: '/' });
  cookies.remove('user', { path: '/' });
  window ? (window.location.href = '/') : '';
};

export const isAccessFalseForName = (name: string) => {
  const userCookie = cookies.get('user');
  const accessLevels = JSON.parse(atob(userCookie)).role.accessLevels;
  return accessLevels.some((entry: any) => entry.name === name && entry.access === false);
};
