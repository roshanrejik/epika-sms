export const getHeaderTitle = (
  pathName: string,
  searchParams: string | null,
  readOnly: string | null,
) => {
  const title: { [key: string]: string } = {
    '/': 'Dashboard',
    '/analytics/': 'Analytics',
    '/admin/agents/': 'Teams and Permissions',
    '/admin/teams/': 'Teams and Permissions',
    '/admin/roles-and-permissions/': 'Teams and Permissions',
    '/admin/agents/add-agent/': searchParams ? 'Edit Agent' : 'Add New Agent',
    '/admin/teams/add-team/': searchParams ? 'Edit Team' : 'Add New Team',
    '/admin/teams/edit-team/': 'Edit Team',
    '/admin/roles-and-permissions/add-role/':
      readOnly == 'true' ? 'View Role' : searchParams ? 'Edit Role' : 'Add New Role',
    '/canned/': 'Canned Responses',
    '/campaigns/': 'Campaigns',
    '/campaigns/add-campaign/create-campaign/': 'Campaigns',
    '/campaigns/add-campaign/settings/': 'Campaigns',
    '/campaigns/add-campaign/recipients-api-toggle/': 'Campaigns',
    '/campaigns/add-campaign/schedule/': 'Campaigns',
    '/customers/': 'Customers',
    '/customers/add-customer/': searchParams ? 'Edit Customer' : 'Add New Customer',
    '/dashboard/': 'Dashboard',
    '/followups/': 'Follow-Ups Manager',
    '/followups/add-followup/': 'Add Follow-Up',
    '/importexport/': 'Import And Export',
    '/plugins/': 'Plugins',
  };
  return title[pathName];
};

export const getDefaultTeamsAndPermissionsTab = (pathName: string) => {
  const tab: { [key: string]: number } = {
    '/admin/agents/': 0,
    '/admin/agents/add-agent/': 0,
    '/admin/teams/': 1,
    '/admin/teams/add-team/': 1,
    '/admin/teams/edit-team/': 1,
    '/admin/roles-and-permissions/': 2,
    '/admin/roles-and-permissions/add-role/': 2,
  };
  return tab[pathName];
};

export const getDefaultAddCampaignTab = (pathName: string) => {
  const tab: { [key: string]: number } = {
    '/campaigns/add-campaign/create-campaign/': 0,
    '/campaigns/add-campaign/settings/': 1,
    '/campaigns/add-campaign/recipients-api-toggle/': 2,
    '/campaigns/add-campaign/schedule/': 3,
  };
  return tab[pathName];
};

export const findById = (itemId: string, itemList: any) => {
  return itemList.find((item: any) => item._id === itemId);
};

export const userListForSelection = (userList: any) => {
  return userList?.map((user: any) => ({
    _id: user._id,
    name: user.name,
  }));
};

export const checkAvailability = (data: any) => {
  if (
    (data[0].value === true && data[1].value === true) ||
    (data[0].value === false && data[1].value === false)
  ) {
    return '';
  } else if (data[0].value === true) {
    return true;
  } else {
    return false;
  }
};
const timeOptions = {
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: true,
};

export const formatUSDate = (isoString: any) => {
  const date = new Date(isoString);
  const now = new Date();

  // Helper function to format the time
  const formatTime = (date: any) => date.toLocaleString('en-US', timeOptions).replace(',', '');

  // Calculate the difference in days
  const isToday = now.toDateString() === date.toDateString();

  if (isToday) {
    return ` ${formatTime(date)}`;
  } else {
    // Define options for formatting the full date and time
    const dateTimeOptions = {
      year: 'numeric',
      month: 'long',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    };
    return date.toLocaleString('en-US', dateTimeOptions).replace(',', '').replace(' at', ',');
  }
};

export function replacePlaceholders(message: string, customer: any) {
  const firstName = customer.firstName === 'anonymous' ? '' : customer.firstName;
  const placeholders: any = {
    '{{firstName}}': firstName,
    '{{lastName}}': customer.lastName,
    '{{email}}': customer.email,
    '{{phone}}': customer.phone,
  };
  const replacedMessage = message.replace(/\{\{(\w+)\}\}/g, (match: any) => {
    let value = placeholders[match];
    if (value === undefined) {
      value = '';
    }
    return value;
  });

  return replacedMessage;
}

export function capitalizeFirstChar(str: string) {
  if (typeof str !== 'string' || str.length === 0) {
    return '';
  }
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Formats a phone number to +1 (XXX) XXX-XXXX format.
 * @param phone - The phone number to format.
 * @returns The formatted phone number.
 */
export function formatPhoneNumber(phone: string): string {
  // Remove all non-numeric characters except for '+'
  const numericValue = phone.replace(/[^\d+]/g, '');

  // Ensure the number starts with '+1' and is followed by 10 digits
  if (numericValue.startsWith('+1') && numericValue.length === 12) {
    const cleanedValue = numericValue.slice(2); // Remove the '+1'
    return `+1 (${cleanedValue.slice(0, 3)}) ${cleanedValue.slice(3, 6)}-${cleanedValue.slice(6)}`;
  } else if (numericValue.length === 10) {
    return `+1 (${numericValue.slice(0, 3)}) ${numericValue.slice(3, 6)}-${numericValue.slice(6)}`;
  }

  // Return the original phone number if it does not match the expected format
  return phone;
}
export function campaignsData(obj: any) {
  const propertiesToDelete = [
    'lastUpdatedBy',
    'createdAt',
    'report',
    'createdBy',
    'updatedAt',
    'status',
    'id',
    'allowUndeliveredCustomers',
    'previousFilterRule',
  ];

  propertiesToDelete.forEach((property) => {
    if (Object.prototype.hasOwnProperty.call(obj, property)) {
      delete obj[property];
    }
  });

  if (Object.prototype.hasOwnProperty.call(obj, 'filterRule') && hasEmptyFields(obj.filterRule)) {
    obj.filterRule = [];
  }

  return obj;
}

function hasEmptyFields(data: any[]): boolean {
  return data?.some((condition) => {
    if (!condition) return true;

    const hasEmptyAnd =
      condition.and &&
      (condition.and.length === 0 ||
        condition.and.some(
          (andCondition: any) => andCondition.field === '' || andCondition.value === '',
        ));

    const hasEmptyOr =
      condition.or &&
      (condition.or.length === 0 ||
        condition.or.some(
          (orCondition: any) => orCondition.field === '' || orCondition.value === '',
        ));

    return hasEmptyAnd || hasEmptyOr;
  });
}

export const convertUTCToLocal = (utcDateString, offset = -5) => {
  // Create a Date object from the UTC date string
  const utcDate = new Date(utcDateString);

  // Calculate the local time by adding the offset in milliseconds
  const localTime = new Date(utcDate.getTime() + offset * 60 * 60 * 1000);

  // Log the details for debugging

  return localTime;
};

export const formatUSDateTimeZone = (isoString) => {
  const date = new Date(isoString);
  const now = new Date();

  // Helper function to format the time
  const formatTime = (date) => {
    const timeOptions = {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
      timeZone: 'UTC',
    };
    return date.toLocaleString('en-US', timeOptions).replace(',', '');
  };

  // Calculate the difference in days
  const isToday = now.toDateString() === date.toDateString();

  if (isToday) {
    return ` ${formatTime(date)}`;
  } else {
    // Define options for formatting the full date and time
    const dateTimeOptions = {
      year: 'numeric',
      month: 'long',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
      timeZone: 'UTC',
    };
    return date.toLocaleString('en-US', dateTimeOptions).replace(',', '').replace(' at', ',');
  }
};

export function hasFilterRule(campaign: any) {
  return campaign?.filterRule?.length > 0;
}
