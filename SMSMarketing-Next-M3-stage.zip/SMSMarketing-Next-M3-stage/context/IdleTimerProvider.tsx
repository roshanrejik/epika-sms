'use client';
import config from '@/config';
import { logout } from '@/lib/features/userSlice';
import { logoutSession } from '@/utils';
import React, { createContext, useState } from 'react';
import { IdleTimerProvider } from 'react-idle-timer';
import { useDispatch } from 'react-redux';
import { useScreenHeight } from './ScreenHeightProvider';

// Define types for context values
interface IdleTimerContextProps {
  isIdle: boolean;
}

// Create a context for the idle timer
export const IdleTimerContext = createContext<IdleTimerContextProps>({
  isIdle: false,
});

// Idle Timer Provider component
const IdleTimerContextProvider = ({ children }: any) => {
  const [isIdle, setIsIdle] = useState<boolean>(false);
  const { availableHeight } = useScreenHeight();
  const dispatch = useDispatch();
  // Callback function to handle idle state
  const onIdle = () => {
    setIsIdle(true);
    logoutSession();
    dispatch(logout());
  };

  // Reset idle state when user becomes active
  const onActive = () => {
    setIsIdle(false);
  };

  return (
    <IdleTimerProvider
      timeout={Number(config.COOKIE_TIME)} // Idle timeout in milliseconds (5 minutes)
      onIdle={onIdle}
      onActive={onActive}
    >
      <IdleTimerContext.Provider value={{ isIdle }}>
        <main className="main" style={{ height: availableHeight + 'px' }}>
          {children}
        </main>
      </IdleTimerContext.Provider>
    </IdleTimerProvider>
  );
};

export default IdleTimerContextProvider;
