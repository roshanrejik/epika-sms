import React, { createContext, useState, useContext, ReactNode } from 'react';
import ShortUniqueId from 'short-uuid';

interface CampaignContextProps {
  campaign: Campaign | null;
  setCampaign: React.Dispatch<React.SetStateAction<Campaign | null>>;
  updateCampaignField: (field: keyof Campaign, value: any) => void;
  resetCampaign: () => void;
}

const CampaignContext = createContext<CampaignContextProps | undefined>(undefined);

interface CampaignProviderProps {
  children: ReactNode;
}

export const CampaignProvider: React.FC<CampaignProviderProps> = ({ children }) => {
  const translator = ShortUniqueId();
  const newUUID = translator.generate().substring(0, 6);
  const [campaign, setCampaign] = useState<Campaign | null>({
    name: '',
    description: '',
    slug: newUUID,
    messages: [{ text: '', optOut: false }],
    responsetype: '1',
    assignType: '1',
    followUpId: undefined,
    filterRule: [
      {
        or: [{ field: '', value: '' }],
      },
    ],
    active: true,
    schedule: '1',
    sendByApi: false,
    removeUndeliveredCustomers: false,
    recipients: 0,
    previousFilterRule: [],
  });

  const updateCampaignField = (field: keyof Campaign, value: any) => {
    setCampaign((prevCampaign: Campaign | null) => {
      if (prevCampaign) {
        return {
          ...prevCampaign,
          [field]: value,
        };
      }
      return prevCampaign;
    });
  };

  const resetCampaign = () => {
    setCampaign({
      name: '',
      description: '',
      slug: newUUID,
      messages: [{ text: '', optOut: false }],
      responsetype: '1',
      assignType: '1',
      followUpId: '',
      filterRule: [
        {
          or: [{ field: '', value: '' }],
        },
      ],
      active: true,
      schedule: '1',
      sendByApi: false,
      removeUndeliveredCustomers: false,
      recipients: 0,
      previousFilterRule: [],
    });
  };

  return (
    <CampaignContext.Provider value={{ campaign, setCampaign, updateCampaignField, resetCampaign }}>
      {children}
    </CampaignContext.Provider>
  );
};

export const useCampaign = () => {
  const context = useContext(CampaignContext);
  if (!context) {
    throw new Error('useCampaign must be used within a CampaignProvider');
  }
  return context;
};

// types.ts
export interface Campaign {
  name: string;
  description?: string;
  slug: string;
  messages?: any[];
  responsetype: '1' | '2' | '3';
  assignType: '1' | '2' | '3';
  followUpId?: string | undefined;
  filterRule?: any[];
  active: boolean;
  schedule: '1' | '2' | '3';
  sendByApi: boolean;
  removeUndeliveredCustomers: boolean;
  recipients: number;
  previousFilterRule: any[];
}
