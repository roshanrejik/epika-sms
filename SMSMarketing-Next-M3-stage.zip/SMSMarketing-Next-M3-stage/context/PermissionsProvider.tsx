import { getEntityType } from '@/constants/key';
import { isAccessFalseForName } from '@/utils';
import React from 'react';
import AccessDenied from '../components/common/AccessDenied/AccessDenied';

type PermissionsProviderProps = {
  children: React.ReactNode;
  name: string;
};

const PermissionsProvider: React.FC<PermissionsProviderProps> = ({ children, name }) => {
  if (isAccessFalseForName(getEntityType(name))) return <AccessDenied />;
  return <>{children}</>;
};

export default PermissionsProvider;
