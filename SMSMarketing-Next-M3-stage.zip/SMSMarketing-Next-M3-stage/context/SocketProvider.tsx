'use client';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import config from '@/config/index';
import { user } from '@/lib/features/userSlice';
import cookies from '@/utils/cookies';
import { usePathname } from 'next/navigation';
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import socketio from 'socket.io-client';

// Function to establish a socket connection with authorization token
const getSocket = () => {
  const token = cookies.get('accessToken'); // Example of getting a token from cookies
  return socketio(config.BASE_URL, {
    reconnection: true,
    auth: {
      token,
    },
  });
};

// Create a context to hold the socket instance
const SocketContext = createContext<{
  socket: ReturnType<typeof socketio> | null;
}>({
  socket: null,
});

// Custom hook to access the socket instance from the context
const useSocket = () => useContext(SocketContext);

// SocketProvider component to manage the socket instance and provide it through context
const SocketProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // State to store the socket instance
  const [socket, setSocket] = useState<ReturnType<typeof socketio> | null>(null);

  const { isAuthenticated } = useSelector(user);

  const pathName = usePathname();

  const handleAlerts = () => {
    if (pathName !== '/dashboard/') {
      showToast('info', ' New Message', {
        autoClose: 2000,
        position: 'bottom-right',
      });
    }
  };

  // Set up the socket connection when the component mounts
  useEffect(() => {
    const token = cookies.get('accessToken');
    if (!token) return;

    const socketInstance = getSocket();
    setSocket(socketInstance);

    if (!isAuthenticated) {
      socketInstance.disconnect();
    }
    // Cleanup function to disconnect the socket when the component unmounts
    return () => {
      socketInstance.disconnect();
    };
  }, [isAuthenticated]);

  useEffect(() => {
    if (socket) socket?.on('newMSGConversation', handleAlerts);
    return () => {
      socket?.off('newMSGConversation', handleAlerts);
    };
  }, [socket, pathName]);

  return (
    // Provide the socket instance through context to its children
    <SocketContext.Provider value={{ socket }}>{children}</SocketContext.Provider>
  );
};

// Export the SocketProvider component and the useSocket hook for other components to use
export { SocketProvider, useSocket };
