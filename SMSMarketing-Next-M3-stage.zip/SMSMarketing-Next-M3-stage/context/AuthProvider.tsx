'use client';
import React from 'react';
import EmailScreen from '@/components/Auth/EmailScreen';
import { useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { user } from '@/lib/features/userSlice';
import { usePathname, useRouter } from 'next/navigation';
import { checkPathnameWithoutToken, checkPathnameWithToken, routeToRoot } from '@/utils';
import LoadingScreen from '@/components/common/Loader/LoadingScreen';

const AuthProvider = ({ children }: any) => {
  const { isAuthenticated } = useSelector(user);
  const [accessToken, setAccessToken] = useState<boolean>(isAuthenticated);

  useEffect(() => {
    setAccessToken(isAuthenticated);
  }, [isAuthenticated]);

  return <AuthRouter accessToken={accessToken}>{children}</AuthRouter>;
};

const AuthRouter = ({ accessToken, children }: any) => {
  const { push } = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (accessToken) {
      if (checkPathnameWithToken(pathname)) push('/dashboard/');
    } else if (routeToRoot(accessToken, pathname)) push('/dashboard/');
  }, [accessToken, pathname]);

  if (typeof window === 'undefined') {
    return <LoadingScreen />;
  }

  return checkPathnameWithoutToken(accessToken, pathname) ? children : <EmailScreen />;
};

export default AuthProvider;
