'use client';
import { useWindowSize } from '@/utils/useWindowSize';
import { usePathname } from 'next/navigation';
import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';

interface ScreenHeightContextProps {
  availableHeight: number;
  search: {
    field: string;
    value: string;
  };
  setSearch: React.Dispatch<React.SetStateAction<{ field: string; value: string }>>;
  availableWidth: number;
}

const ScreenHeightContext = createContext<ScreenHeightContextProps | undefined>(undefined);

interface ScreenHeightProviderProps {
  children: ReactNode;
}

export const ScreenHeightProvider: React.FC<ScreenHeightProviderProps> = ({ children }) => {
  const [availableHeight, setAvailableHeight] = useState(0);
  const [availableWidth, setAvailableWidth] = useState(0);
  const pathname = usePathname();
  const [search, setSearch] = useState({
    field: 'all',
    value: '',
  });
  const { windowHeight, windowWidth } = useWindowSize();

  useEffect(() => {
    const calculateHeight = () => {
      const headerHeight = document.querySelector('.headerAppBar')?.clientHeight || 0;
      const footerHeight = document.querySelector('footer')?.clientHeight || 0;
      const outerBodyHeight = headerHeight + footerHeight + 10;
      setAvailableHeight(windowHeight - outerBodyHeight);
      setAvailableWidth(windowWidth);
    };

    // Initial calculation
    calculateHeight();
    // Recalculate on window resize
    window.addEventListener('resize', calculateHeight);
    return () => window.removeEventListener('resize', calculateHeight);
  }, [windowHeight, windowWidth, pathname]);

  return (
    <ScreenHeightContext.Provider value={{ availableHeight, search, setSearch, availableWidth }}>
      {children}
    </ScreenHeightContext.Provider>
  );
};

export const useScreenHeight = () => {
  const context = useContext(ScreenHeightContext);
  if (!context) {
    throw new Error('useScreenHeight must be used within a ScreenHeightProvider');
  }
  return context;
};
