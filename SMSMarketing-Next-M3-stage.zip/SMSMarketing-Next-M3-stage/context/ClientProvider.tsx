'use client';
import LoadingScreen from '@/components/common/Loader/LoadingScreen';
import React, { useEffect, useState } from 'react';

const ClientProvider = ({ children }: any) => {
  const [isClient, setClient] = useState(false);

  useEffect(() => {
    setClient(typeof window !== 'undefined');
  }, []);

  return isClient ? children : <LoadingScreen />;
};

export default ClientProvider;
