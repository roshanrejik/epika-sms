import * as Yup from 'yup';

export const CustomerSchema = Yup.object().shape({
  subscribed: Yup.boolean().nullable(),
  lastName: Yup.string().nullable(),
  firstName: Yup.string().nullable(),
  phone: Yup.string()
    .required('Phone Number is required')
    .matches(/^\+1\s\(\d{3}\)\s\d{3}-\d{4}$/, 'Invalid phone number format')
    .transform((value, originalValue) => {
      // Remove all non-numeric characters except for '+'
      const numericValue = originalValue.replace(/[^\d+]/g, '');
      // Ensure the number starts with '+1' and is followed by 10 digits
      if (numericValue.startsWith('+1') && numericValue.length === 12) {
        const cleanedValue = numericValue.slice(2); // Remove the '+1'
        return `+1 (${cleanedValue.slice(0, 3)}) ${cleanedValue.slice(3, 6)}-${cleanedValue.slice(6)}`;
      } else if (numericValue.length === 10) {
        return `+1 (${numericValue.slice(0, 3)}) ${numericValue.slice(3, 6)}-${numericValue.slice(6)}`;
      }
      return value;
    }),
  email: Yup.string()
    .test(
      'is-empty-or-valid',
      'Invalid Email Format',
      (value) => !value || /^[a-zA-Z0-9._%+-]+@(?:[a-zA-Z0-9]+\.)+[A-Za-z]+$/.test(value),
    )
    .nullable(),
});
