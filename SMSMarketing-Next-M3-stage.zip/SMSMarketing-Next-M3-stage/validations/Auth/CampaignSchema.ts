import * as Yup from 'yup';

export const SettingsEditFormSchema = Yup.object().shape({
  responsetype: Yup.string().nullable(),
  followUpId: Yup.string().required('Follow Up is required'),
});
export const SettingsAddFormSchema = Yup.object().shape({
  responsetype: Yup.string().nullable(),
  followUpId: Yup.string().required('Follow Up is required'),
});
