import * as Yup from 'yup';

export const AgentAddFormSchema = Yup.object().shape({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string(),
  jobTitle: Yup.string(),
  username: Yup.string().required('Username is required'),
  password: Yup.string().required('Password is required'),
  email: Yup.string()
    .required('Enter a valid email address')
    .matches(/^[a-zA-Z0-9._%+-]+@(?:[a-zA-Z0-9]+\.)+[A-Za-z]+$/, 'Invalid Email Format'),
  phone: Yup.string()
    .required('Phone Number is required')
    .matches(/^\+1\s\(\d{3}\)\s\d{3}-\d{4}$/, 'Invalid phone number format')
    .transform((value, originalValue) => {
      // Remove all non-numeric characters except for '+'
      const numericValue = originalValue.replace(/[^\d+]/g, '');
      // Ensure the number starts with '+1' and is followed by 10 digits
      if (numericValue.startsWith('+1') && numericValue.length === 12) {
        const cleanedValue = numericValue.slice(2); // Remove the '+1'
        return `+1 (${cleanedValue.slice(0, 3)}) ${cleanedValue.slice(3, 6)}-${cleanedValue.slice(6)}`;
      } else if (numericValue.length === 10) {
        return `+1 (${numericValue.slice(0, 3)}) ${numericValue.slice(3, 6)}-${numericValue.slice(6)}`;
      }
      return value;
    }),
  role: Yup.string().required('Role is required'),
  teams: Yup.array().of(Yup.string()).notRequired(),
});
export const AgentEditFormSchema = Yup.object().shape({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string(),
  jobTitle: Yup.string(),
  username: Yup.string().required('Username is required'),
  email: Yup.string()
    .required('Enter a valid email address')
    .matches(/^[a-zA-Z0-9._%+-]+@(?:[a-zA-Z0-9]+\.)+[A-Za-z]+$/, 'Invalid Email Format'),
  phone: Yup.string()
    .required('Phone Number is required')
    .matches(/^\+1\s\(\d{3}\)\s\d{3}-\d{4}$/, 'Invalid phone number format')
    .transform((value, originalValue) => {
      // Remove all non-numeric characters except for '+'
      const numericValue = originalValue.replace(/[^\d+]/g, '');
      // Ensure the number starts with '+1' and is followed by 10 digits
      if (numericValue.startsWith('+1') && numericValue.length === 12) {
        const cleanedValue = numericValue.slice(2); // Remove the '+1'
        return `+1 (${cleanedValue.slice(0, 3)}) ${cleanedValue.slice(3, 6)}-${cleanedValue.slice(6)}`;
      } else if (numericValue.length === 10) {
        return `+1 (${numericValue.slice(0, 3)}) ${numericValue.slice(3, 6)}-${numericValue.slice(6)}`;
      }
      return value;
    }),
  role: Yup.string().required('Role is required'),
  teams: Yup.array().of(Yup.string()).notRequired(),
});
export const TeamAddFormSchema = Yup.object().shape({
  name: Yup.string().required('Team Name is required'),
  members: Yup.array().of(Yup.string()).notRequired(),
});

export const TeamEditFormSchema = Yup.object().shape({
  name: Yup.string().required('Team Name is required'),
  members: Yup.array().of(Yup.string()).notRequired(),
});
