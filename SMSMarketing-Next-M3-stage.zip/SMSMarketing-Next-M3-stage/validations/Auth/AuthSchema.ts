import * as Yup from 'yup';
export const emailValidationSchema = {
  email: Yup.string()
    .required('Enter a valid email address')
    .matches(/^[a-zA-Z0-9._%+-]+@(?:[a-zA-Z0-9]+\.)+[A-Za-z]+$/, 'Invalid Email Format'),
};

export const passwordValidationSchema = {
  password: Yup.string().required('Password is required'),
};
