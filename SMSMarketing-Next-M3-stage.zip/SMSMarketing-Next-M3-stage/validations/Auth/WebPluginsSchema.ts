import * as yup from 'yup';

export const WebPluginSchema = yup.object().shape({
  text: yup.string().required('Text is required'),
  contactName: yup.string().required('Contact Name is required'),
});
