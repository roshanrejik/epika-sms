const config = {
  BASE_URL: process.env.NEXT_PUBLIC_BASE_URL || '',
  API_VERSION1: process.env.NEXT_PUBLIC_API_VERSION1 || '',
  COOKIE_TIME: process.env.NEXT_PUBLIC_COOKIE_TIME || undefined,
};

export default config;
