import { useRefreshToken } from '@/hooks/api/user.hooks';
import { logoutSession } from '@/utils';
import cookies from '@/utils/cookies';
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import config from './index';
let instance: AxiosInstance = axios.create();

//Axios Instance
export const Http = {
  createInstance: (baseUrl: string): AxiosInstance => {
    // Axios instance
    instance = axios.create({
      baseURL: baseUrl,
      headers: {
        'Content-Type': 'application/json',
      },
    });
    // Request interceptor
    instance.interceptors.request.use(
      async (config) => {
        const accessToken = await cookies.get('accessToken');
        if (accessToken) {
          config.headers['Authorization'] = `Bearer ${accessToken}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      },
    );

    instance.interceptors.response.use(
      (response) => {
        return response;
      },
      async (error) => {
        if (error.response && error.response.status === 401) {
          if (error.response.data.isTokenExpire) {
            try {
              if (error.response.data.message === 'refreshToken has expired') {
                logoutSession();
              } else {
                await useRefreshToken(); // Wait for token refresh
                return instance.request(error.config); // Retry original request
              }
            } catch (refreshError) {
              return Promise.reject(refreshError);
            }
          }
        }
        return Promise.reject(error);
      },
    );

    return instance;
  },

  /**
   * Set HTTP custom header
   *
   * @param name
   * @param value
   */
  setHeader: (name: string, value: string) => {
    instance.defaults.headers.common[name] = value;
  },
};

export const http = {
  /**
   * Send HTTP GET request
   *
   * @param url
   * @param config
   * @returns
   */
  get: (url: string, config?: AxiosRequestConfig) => instance.get(url, config),

  /**
   * Send HTTP POST request
   *
   * @param url
   * @param data
   * @param config
   * @returns
   */
  post: (url: string, data?: any, config?: AxiosRequestConfig) => instance.post(url, data, config),

  /**
   * Send HTTP PUT request
   *
   * @param url
   * @param data
   * @param config
   * @returns
   */
  put: (url: string, data?: any, config?: AxiosRequestConfig) => instance.put(url, data, config),

  /**
   * Send HTTP PATCH request
   *
   * @param url
   * @param data
   * @param config
   * @returns
   */
  patch: (url: string, data?: any, config?: AxiosRequestConfig) =>
    instance.patch(url, data, config),

  /**
   * Send HTTP DELETE request
   *
   * @param url
   * @param config
   * @returns
   */
  delete: (url: string, config?: AxiosRequestConfig) => instance.delete(url, config),
};

export const Api = Http.createInstance(config.BASE_URL);
