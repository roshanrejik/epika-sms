'use client';
import React, { useState, useEffect } from 'react';
import { Grid, Paper, Typography, Box } from '@mui/material';
import ChatDetails from '@/components/Dashboard/ChatDetails';
import ChatList from '@/components/Dashboard/ChatList';
import { useSearchParams } from 'next/navigation';
import CustomerDetails from '@/components/Dashboard/CustomerDetails';
import { useGetConversationDetails } from '@/hooks/api/conversation.hooks';
import { usePostCannedMessageList } from '@/hooks/api/canned.hooks';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import { CSSTransition } from 'react-transition-group';
import './MyComponent.css'; // Assuming you have CSS in this file for transitions

interface MessageData {
  id: number;
  text: string;
  direction: 'sent' | 'received';
  type: string;
  createdAt: string;
  createdBy: {
    _id: string;
    name: string;
  };
}

const MyComponent: React.FC = () => {
  const searchParams = useSearchParams();
  const conversationId = searchParams.get('cId');
  const searchMatchedMsg = searchParams.get('searchMatchedMsg');
  const { search, availableHeight, availableWidth } = useScreenHeight();
  const { data: conversationDetails, refetch } = useGetConversationDetails(conversationId);
  const [conversationListData, setConversationListData] = useState([]);
  const [postMessageListData, setPostMessageListData] = useState<MessageData[]>([]);
  const [postCannedMessageListData, setPostCannedMessageListData] = useState([]);
  const [showCustomerDetails, setShowCustomerDetails] = useState(false);
  const [isSubscribedLoading, setIsSubscribedLoading] = useState(false);
  const { mutate: postCannedMessageList } = usePostCannedMessageList();

  const [showSearch, setShowSearch] = useState(false);

  const [cannedListBody, setCannedListBody] = useState({
    page: 0,
    limit: 10,
    search: '',
    shared: '',
  });

  const [count, setCount] = useState({
    unassign: 0,
    assign: 0,
    all: 0,
  });
  const [tabValue, setTabValue] = useState(2);

  useEffect(() => {
    const payload = {
      ...cannedListBody,
      page: cannedListBody.page + 1,
      shared: true,
    };
    postCannedMessageList(payload, {
      onSuccess: (res) => {
        setPostCannedMessageListData(res.data.data);
      },
    });
  }, [cannedListBody, postCannedMessageList]);

  const toggleCustomerDetails = () => {
    setShowCustomerDetails((prev) => !prev);
  };

  return (
    <Box
      sx={{
        height: availableHeight,
        dissplay: 'flex',
        flexDirection: 'column',
      }}
    >
      <Grid
        // container
        sx={{
          height: '100%',
          width: availableWidth + 'px',
          border: '0.5px solid #f1f1f1',
          display: 'flex',

          padding: '13px 13px',
        }}
      >
        {/* <Grid item md={3} sx={{ height: '100%', overflowY: 'auto', border: '0.5px solid #f1f1f1' }}> */}
        <Grid
          sx={{
            height: '100%',
            overflowY: 'auto',
            border: '0.5px solid #f1f1f1',
            flexShrink: 0,
            width: '380px',
          }}
        >
          <ChatList
            setConversationListData={setConversationListData}
            conversationListData={conversationListData}
            setPostMessageListData={setPostMessageListData}
            count={count}
            setCount={setCount}
            setTabValue={setTabValue}
            tabValue={tabValue}
            setShowSearch={setShowSearch}
            showSearch={showSearch}
            chatListHeaderHeight={availableHeight + 400}
            refetch={refetch}
          />
        </Grid>
        {/* <Grid
          item
          md={showCustomerDetails && conversationId ? 7 : 9}
          sx={{
            height: '100%',
            border: '0.5px solid #f1f1f1',
            transition: 'width 0.3s',
          }}
        > */}
        <Grid
          sx={{
            height: '100%',
            border: '0.5px solid #f1f1f1',
            transition: 'width 0.3s',
            flexGrow: 1,
          }}
        >
          {conversationId ? (
            <ChatDetails
              conversationId={conversationId}
              search={search}
              searchMatchedMsg={searchMatchedMsg}
              refetch={refetch}
              customer={conversationDetails?.data?.customer}
              againstCompliance={conversationDetails?.data?.againstCompliance}
              currentAssignedTo={conversationDetails?.data?.data?.currentAssignedTo}
              toPhoneNumber={conversationDetails?.data?.data?.customerPhoneNumber}
              customerName={conversationDetails?.data?.data?.customerName}
              setConversationListData={setConversationListData}
              setCount={setCount}
              setTabValue={setTabValue}
              postMessageListData={postMessageListData}
              setPostMessageListData={setPostMessageListData}
              subscribed={conversationDetails?.data?.customer?.subscribed}
              postCannedMessageListData={postCannedMessageListData}
              cannedListBody={cannedListBody}
              setCannedListBody={setCannedListBody}
              toggleCustomerDetails={toggleCustomerDetails}
              showCustomerDetails={showCustomerDetails}
              isSubscribedLoading={isSubscribedLoading}
              complianceMessage={conversationDetails?.data?.complianceMessage}
            />
          ) : (
            <Paper>
              <Box
                p={2}
                display="flex"
                flexDirection="column"
                height={availableHeight}
                justifyContent="center"
                alignItems="center"
              >
                <Typography variant="h4" color="textSecondary" sx={{ fontWeight: 600 }}>
                  No Conversation Selected
                </Typography>
              </Box>
            </Paper>
          )}
        </Grid>
        {conversationId ? (
          <CSSTransition
            in={showCustomerDetails}
            timeout={300}
            classNames="customer-details"
            unmountOnExit
          >
            {/* <Grid
              item
              md={2}
              sx={{
                border: '0.5px solid #f1f1f1',
                height: availableHeight - 10 + 'px',
                overflowY: 'scroll',
              }}
            > */}
            <Grid
              sx={{
                border: '0.5px solid #f1f1f1',
                height: availableHeight - 10 + 'px',
                overflowY: 'scroll',
                minWidth: '250px',
              }}
            >
              <CustomerDetails
                customer={conversationDetails?.data?.customer}
                search={search}
                setIsSubscribedLoading={setIsSubscribedLoading}
                refetch={refetch}
                conversationId={conversationId}
                setPostMessageListData={setPostMessageListData}
              />
            </Grid>
          </CSSTransition>
        ) : null}
      </Grid>
    </Box>
  );
};

export default MyComponent;
