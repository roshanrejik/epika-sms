import LoadingScreen from '@/components/common/Loader/LoadingScreen';
import React from 'react';
export default function NotFound() {
  return <LoadingScreen />;
}
