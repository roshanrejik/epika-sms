'use client';
import TemplateScreen from '@/components/MsgTemplate/MsgTemplateScreen';
import PermissionsProvider from '@/context/PermissionsProvider';
import { usePathname } from 'next/navigation';
import React from 'react';

const MsgTemplate = () => {
  const pathName = usePathname();
  return (
    <PermissionsProvider name={pathName}>
      <TemplateScreen />
    </PermissionsProvider>
  );
};
export default MsgTemplate;
