'use client';
import Plugins from '@/components/Plugins/Plugins';
import PermissionsProvider from '@/context/PermissionsProvider';
import { usePathname } from 'next/navigation';
import React from 'react';

const PluginsPage = () => {
  const pathName = usePathname();
  return (
    <PermissionsProvider name={pathName}>
      <Plugins />
    </PermissionsProvider>
  );
};

export default PluginsPage;
