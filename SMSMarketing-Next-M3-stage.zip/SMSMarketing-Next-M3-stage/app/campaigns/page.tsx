'use client';
import Campaigns from '@/components/Campaigns/Campaigns';
import PermissionsProvider from '@/context/PermissionsProvider';
import { usePathname } from 'next/navigation';
import React from 'react';

const CampaignsPage = () => {
  const pathName = usePathname();

  return (
    <PermissionsProvider name={pathName}>
      <Campaigns />
    </PermissionsProvider>
  );
};

export default CampaignsPage;
