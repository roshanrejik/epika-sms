'use client';
import { useRouter } from 'next/navigation';

const Page = () => {
  const router = useRouter();
  router.push('/campaigns/create-campaign');
  return null;
};

export default Page;
