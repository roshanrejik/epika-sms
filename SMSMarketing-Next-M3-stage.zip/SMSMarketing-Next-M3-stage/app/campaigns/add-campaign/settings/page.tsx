import SettingsScreen from '@/components/Campaigns/AddCampaign/Settings/SettingsScreen';
import React from 'react';

const SettingsPage = () => {
  return <SettingsScreen />;
};

export default SettingsPage;
