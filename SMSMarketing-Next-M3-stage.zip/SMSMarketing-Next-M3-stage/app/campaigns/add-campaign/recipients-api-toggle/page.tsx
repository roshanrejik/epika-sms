import RecipientsApiToggleScreen from '@/components/Campaigns/AddCampaign/RecipientsApiToggle/RecipientsApiToggleScreen';
import React from 'react';

const RecipientsApiTogglePage = () => {
  return <RecipientsApiToggleScreen />;
};

export default RecipientsApiTogglePage;
