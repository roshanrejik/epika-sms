import CreateCampaignScreen from '@/components/Campaigns/AddCampaign/CreateCampaign/CreateCampaignScreen';
import React from 'react';

const CreateCampaignPage = () => {
  return <CreateCampaignScreen />;
};

export default CreateCampaignPage;
