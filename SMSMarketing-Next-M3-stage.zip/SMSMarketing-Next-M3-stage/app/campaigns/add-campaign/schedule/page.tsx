import ScheduleScreen from '@/components/Campaigns/AddCampaign/Schedule/ScheduleScreen';
import React from 'react';

const SchedulePage = () => {
  return <ScheduleScreen />;
};

export default SchedulePage;
