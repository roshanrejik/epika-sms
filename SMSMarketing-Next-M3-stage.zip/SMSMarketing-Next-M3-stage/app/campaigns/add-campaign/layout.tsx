'use client';
import AddCampaign from '@/components/Campaigns/AddCampaign/AddCampaign';
import PermissionsProvider from '@/context/PermissionsProvider';
import { getDefaultAddCampaignTab } from '@/utils/helpers';
import { AppBar, Box, styled, Tab, Tabs } from '@mui/material';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import React from 'react';
interface LayoutProps {
  children: React.ReactNode;
}
const Layout: React.FC<LayoutProps> = ({ children }) => {
  const router = useRouter();
  const pathName = usePathname();
  const searchParams = useSearchParams();
  const id = searchParams.get('id');
  const [value, setValue] = React.useState(0);

  React.useEffect(() => {
    setValue(getDefaultAddCampaignTab(pathName));
    return () => {
      pathName;
    };
  }, [pathName]);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };
  const handleTabClick = (index: number) => {
    setValue(index);
    switch (index) {
      case 0:
        router.push('/campaigns/add-campaign/create-campaign/?id=' + id);
        break;
      case 1:
        router.push('/campaigns/add-campaign/settings/?id=' + id);
        break;
      case 2:
        router.push('/campaigns/add-campaign/recipients-api-toggle/?id=' + id);
        break;
      case 3:
        router.push('/campaigns/add-campaign/schedule/?id=' + id);
        break;
      default:
        break;
    }
  };
  const IconWrapper = styled(Box)(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '50%',
    backgroundColor: 'var(--epika-primary-color)',
    color: theme.palette.common.white,
    width: 24,
    height: 24,
  }));

  return (
    <div>
      <Box sx={{ width: '100%' }} className="contentMarginTop">
        <AddCampaign />

        <AppBar position="static">
          <Tabs
            value={value}
            onChange={handleChange}
            indicatorColor="secondary"
            textColor="inherit"
            variant="fullWidth"
            aria-label="full width tabs example"
            sx={{
              bgcolor: 'white',
              color: 'black',
              '& .MuiTabs-indicator': {
                backgroundColor: 'var(--epika-primary-color)',
              },
            }}
          >
            <Tab
              label="CREATE CAMPAIGN"
              onClick={() => handleTabClick(0)}
              icon={<IconWrapper>1</IconWrapper>}
            />
            <Tab
              label="SETTING"
              onClick={() => handleTabClick(1)}
              icon={<IconWrapper>2</IconWrapper>}
            />
            <Tab
              label="RECIPIENTS/API TOGGLE"
              onClick={() => handleTabClick(2)}
              icon={<IconWrapper>3</IconWrapper>}
            />
            <Tab
              label="SCHEDULE"
              onClick={() => handleTabClick(3)}
              icon={<IconWrapper>4</IconWrapper>}
            />
          </Tabs>
        </AppBar>
        <PermissionsProvider name={pathName}>
          <Box sx={{ p: 3, maxHeight: '70vh', overflow: 'auto' }}>{children}</Box>
        </PermissionsProvider>
      </Box>
    </div>
  );
};

export default Layout;
