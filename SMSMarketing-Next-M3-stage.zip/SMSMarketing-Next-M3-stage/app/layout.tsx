'use client';
import React from 'react';
import './globals.css';
import 'react-toastify/ReactToastify.css';
import AuthProvider from '@/context/AuthProvider';
import StoreProvider from '@/context/StoreProvider';
import QueryProvider from '@/context/QueryProvider';
import ClientProvider from '@/context/ClientProvider';
import Header from '@/components/Layouts/Header';
import SiderBar from '@/components/Layouts/SiderBar';
import ToastProvider from '@/context/ToastProvider';
import EpikaLogo from '../public/cropped-Epika-A-01-192x192.png';
import IdleTimerContextProvider from '@/context/IdleTimerProvider';
import Footer from '@/components/Layouts/Footer';
import { SocketProvider } from '@/context/SocketProvider';
import { ScreenHeightProvider } from '@/context/ScreenHeightProvider';
import { useWindowSize } from '@/utils/useWindowSize';
import { CampaignProvider } from '@/context/CampaignContext';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const { windowHeight } = useWindowSize();
  return (
    <html lang="en">
      <head>
        <title>Epika SMS</title>
        <link rel="icon" href={EpikaLogo.src} />
      </head>
      <body style={{ height: windowHeight }}>
        <StoreProvider>
          <QueryProvider>
            <ClientProvider>
              <ToastProvider>
                <AuthProvider>
                  <CampaignProvider>
                    <SocketProvider>
                      <ScreenHeightProvider>
                        <Header />
                        <SiderBar />
                        <IdleTimerContextProvider>{children}</IdleTimerContextProvider>
                        <Footer />
                      </ScreenHeightProvider>
                    </SocketProvider>
                  </CampaignProvider>
                </AuthProvider>
              </ToastProvider>
            </ClientProvider>
          </QueryProvider>
        </StoreProvider>
      </body>
    </html>
  );
}
