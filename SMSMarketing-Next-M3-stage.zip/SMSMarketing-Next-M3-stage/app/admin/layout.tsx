'use client';
import React, { useEffect } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { getDefaultTeamsAndPermissionsTab } from '@/utils/helpers';
import PermissionsProvider from '@/context/PermissionsProvider';
interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const router = useRouter();
  const pathName = usePathname();
  const [value, setValue] = React.useState(getDefaultTeamsAndPermissionsTab(pathName));

  useEffect(() => {
    setValue(getDefaultTeamsAndPermissionsTab(pathName));
    return () => {
      pathName;
    };
  }, [pathName]);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  const handleTabClick = (index: number) => {
    setValue(index);
    switch (index) {
      case 0:
        router.push('/admin/agents/');
        break;
      case 1:
        router.push('/admin/teams/');
        break;
      case 2:
        router.push('/admin/roles-and-permissions/');
        break;
      default:
        break;
    }
  };

  return (
    <Box sx={{ width: '100%' }} className="contentMarginTop">
      <AppBar position="static">
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="secondary"
          textColor="inherit"
          variant="fullWidth"
          aria-label="full width tabs example"
          sx={{
            bgcolor: 'white',
            color: 'black',
            '& .MuiTabs-indicator': {
              backgroundColor: 'var(--epika-primary-color)',
            },
          }}
        >
          <Tab
            label="AGENTS"
            icon={<PersonOutlineOutlinedIcon />}
            onClick={() => handleTabClick(0)}
          />
          <Tab label="TEAMS" icon={<GroupOutlinedIcon />} onClick={() => handleTabClick(1)} />
          <Tab
            label="ROLES & PERMISSIONS"
            icon={<LockOutlinedIcon />}
            onClick={() => handleTabClick(2)}
          />
        </Tabs>
      </AppBar>
      <PermissionsProvider name={pathName}>{children}</PermissionsProvider>
    </Box>
  );
};

export default Layout;
