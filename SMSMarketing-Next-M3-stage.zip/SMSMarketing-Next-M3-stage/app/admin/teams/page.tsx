import Teams from '@/components/Admin/Teams/Teams';
import React from 'react';

const TeamsPage = () => {
  return <Teams />;
};

export default TeamsPage;
