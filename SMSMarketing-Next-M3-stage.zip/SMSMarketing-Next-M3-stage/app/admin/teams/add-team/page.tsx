import AddTeam from '@/components/Admin/Teams/AddTeam';
import React from 'react';

const AddTeamPage = () => {
  return <AddTeam />;
};

export default AddTeamPage;
