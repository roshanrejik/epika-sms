import EditTeam from '@/components/Admin/Teams/EditTeam';
import React from 'react';

const EditTeamPage = () => {
  return <EditTeam />;
};

export default EditTeamPage;
