import RolesAndPermissions from '@/components/Admin/Roles/RolesAndPermissions';
import React from 'react';

const RolesAndPermissionPage = () => {
  return <RolesAndPermissions />;
};

export default RolesAndPermissionPage;
