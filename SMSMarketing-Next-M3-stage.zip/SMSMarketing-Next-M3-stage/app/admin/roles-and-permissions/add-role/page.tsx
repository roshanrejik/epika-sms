import AddRolesAndPermissions from '@/components/Admin/Roles/AddRolesAndPermissions';
import React from 'react';

const AddRolesAndPermissionsPage = () => {
  return <AddRolesAndPermissions />;
};

export default AddRolesAndPermissionsPage;
