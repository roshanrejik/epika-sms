import Agents from '@/components/Admin/Agents/Agents';
import React from 'react';

const AgentPage = () => {
  return <Agents />;
};

export default AgentPage;
