import AddAgent from '@/components/Admin/Agents/AddAgents';
import React from 'react';

const AddAgentsPage = () => {
  return <AddAgent />;
};

export default AddAgentsPage;
