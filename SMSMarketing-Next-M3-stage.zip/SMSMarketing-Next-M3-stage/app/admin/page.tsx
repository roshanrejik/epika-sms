import Agents from '@/components/Admin/Agents/Agents';
import React from 'react';

const AdminPage = () => {
  return <Agents />;
};

export default AdminPage;
