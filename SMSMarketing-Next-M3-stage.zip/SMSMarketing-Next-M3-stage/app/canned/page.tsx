'use client';
import CannedScreen from '@/components/Canned/CannedScreen';
import PermissionsProvider from '@/context/PermissionsProvider';
import { usePathname } from 'next/navigation';
import React from 'react';

const Canned = () => {
  const pathName = usePathname();
  return (
    <PermissionsProvider name={pathName}>
      <CannedScreen />
    </PermissionsProvider>
  );
};
export default Canned;
