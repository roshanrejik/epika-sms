'use client';
import ImportExport from '@/components/ImportExport/ImportExport';
import PermissionsProvider from '@/context/PermissionsProvider';
import { usePathname } from 'next/navigation';
import React from 'react';

const MessagesPage = () => {
  const pathName = usePathname();
  return (
    <PermissionsProvider name={pathName}>
      <ImportExport />
    </PermissionsProvider>
  );
};

export default MessagesPage;
