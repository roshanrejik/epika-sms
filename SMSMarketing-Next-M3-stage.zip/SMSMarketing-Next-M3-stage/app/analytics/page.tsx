import AnalyticScreen from '@/components/Analytics/AnalyticScreen';
import React from 'react';

const AnalyticsPage = () => {
  return <AnalyticScreen />;
};

export default AnalyticsPage;
