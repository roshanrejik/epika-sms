'use client';
import FollowUpScreen from '@/components/FollowUps/FollowUpScreen';
import PermissionsProvider from '@/context/PermissionsProvider';
import { usePathname } from 'next/navigation';
import React from 'react';

const FollowUpsPage = () => {
  const pathName = usePathname();

  return (
    <PermissionsProvider name={pathName}>
      <FollowUpScreen />;
    </PermissionsProvider>
  );
};

export default FollowUpsPage;
