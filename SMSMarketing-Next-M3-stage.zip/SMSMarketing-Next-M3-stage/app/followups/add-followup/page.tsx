import AddFollowUpScreen from '@/components/FollowUps/AddFollowUps/AddFollowUpsScreen';
import React from 'react';

const AddFollowUpPage = () => {
  return <AddFollowUpScreen />;
};

export default AddFollowUpPage;
