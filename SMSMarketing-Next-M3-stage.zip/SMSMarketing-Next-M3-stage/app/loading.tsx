import React from 'react';
import LoadingScreen from '@/components/common/Loader/LoadingScreen';

export default function Loading() {
  return <LoadingScreen />;
}
