import AddCustomer from '@/components/Customers/AddCustomer';
import React from 'react';

const page = () => {
  return <AddCustomer />;
};

export default page;
