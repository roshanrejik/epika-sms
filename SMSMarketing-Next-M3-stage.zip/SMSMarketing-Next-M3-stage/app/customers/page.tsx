'use client';
import Customers from '@/components/Customers/Customers';
import PermissionsProvider from '@/context/PermissionsProvider';
import { usePathname } from 'next/navigation';
import React from 'react';

const CustomersPage = () => {
  const pathName = usePathname();

  return (
    <PermissionsProvider name={pathName}>
      <Customers />
    </PermissionsProvider>
  );
};
export default CustomersPage;
