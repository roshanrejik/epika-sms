import EmailScreen from '@/components/Auth/EmailScreen';
import React from 'react';

const Email = () => {
  return <EmailScreen />;
};

export default Email;
