import PasswordScreen from '@/components/Auth/PasswordScreen';
import React from 'react';

const Password = () => {
  return <PasswordScreen />;
};

export default Password;
