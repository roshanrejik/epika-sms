import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation } from '@tanstack/react-query';
import config from '../../config/index';

export const QueryKeyCanned = {
  GetCannedMessageList: 'getCannedMessageList',
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostCannedMessageList = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Canned.CannedMessageList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostCannedMessageSave = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Canned.CannedResponseSave}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const useDeleteCannedMessage = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Canned.CannedResponseDelete}`,
      {
        data: payload,
      },
    );
  return useMutation({ mutationFn: queryFn });
};
