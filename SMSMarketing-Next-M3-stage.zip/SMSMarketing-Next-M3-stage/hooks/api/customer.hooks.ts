import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation, useQuery } from '@tanstack/react-query';
import config from '../../config/index';

export const QueryKeyCustomer = {
  GetCustomerDetails: 'getCustomerDetails',
  Timezone: 'timezone',
};

/**
 * Get
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetCustomerDetails = (_id: string | null, options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomerDetails}?_id=${_id}`);
  return useQuery(
    {
      queryKey: [QueryKeyCustomer.GetCustomerDetails],
      queryFn,
      refetchOnWindowFocus: true,
      enabled: !!_id,
    },
    options,
  );
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostCustomerSave = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomerSave}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostCustomerList = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomerList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const useDeleteCustomer = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomerDelete}`,
      {
        data: payload,
      },
    );
  return useMutation({ mutationFn: queryFn });
};

export const useExportCustomers = () => {
  const queryFn = async () => {
    const response = await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomerExport}`,
      { responseType: 'blob' },
    );
    return response.data;
  };
  return useMutation({ mutationFn: queryFn });
};

export const useImportCustomers = () => {
  const queryFn = async (formData: FormData) => {
    const response = await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomerImport}`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return response.data;
  };
  return useMutation({ mutationFn: queryFn });
};

export const useDownloadTemplate = () => {
  const queryFn = async () => {
    const response = await Api.get(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomerDownloadTemplate}`,
      { responseType: 'blob' },
    );
    return response.data;
  };
  return useMutation({ mutationFn: queryFn });
};
export const useGetTimezoneList = (options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Customer.TimeZone}`);
  return useQuery(
    {
      queryKey: [QueryKeyCustomer.Timezone],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};

export const useGetCustomerPropertyKeys = (options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomPropertiesKeys}`);
  return useQuery(
    {
      queryKey: [QueryKeyCustomer.GetCustomerDetails, 'customerPropertyKeys'],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};

export const useGetCustomerPropertyValues = (key: string, options?: any) => {
  const queryFn = async () =>
    await Api.get(
      `${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomPropertiesValues}?key=${key}`,
    );
  return useQuery(
    {
      queryKey: [QueryKeyCustomer.GetCustomerDetails, 'customerPropertyValues', key],
      queryFn,
      refetchOnWindowFocus: true,
      enabled: !!key,
    },
    options,
  );
};
/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostCustomerSelectedAudience = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Customer.CustomerSelectedAudience}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};
