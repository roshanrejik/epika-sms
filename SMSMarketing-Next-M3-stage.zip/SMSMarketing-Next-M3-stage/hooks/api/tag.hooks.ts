import { Api } from '@/config/http';
import { useMutation, useQuery } from '@tanstack/react-query';
import config from '@/config/index';
import { API_ENDPOINTS } from '@/constants/api-endpoints';

export const useTagList = (search: string) => {
  return useQuery({
    queryKey: ['tagList', search],
    queryFn: async () => {
      const response = await Api.post(
        `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Tag.TagList}`,
        { page: 1, limit: 10, search },
      );
      return response.data; // Ensure that this data is an array or has an array property
    },
  });
};

export const useAddTag = () => {
  return useMutation({
    mutationFn: async (newTag: { name: string }) => {
      const response = await Api.post(
        `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Tag.TagSave}`,
        newTag,
      );
      return response.data;
    },
  });
};

export const useDeleteTag = () => {
  return useMutation({
    mutationFn: async (tagId: { _id: string[] }) => {
      const response = await Api.delete(
        `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Tag.TagDelete}`,
        { data: tagId },
      );
      return response.data;
    },
  });
};
