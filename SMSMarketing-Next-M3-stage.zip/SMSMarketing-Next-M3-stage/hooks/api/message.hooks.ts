import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation } from '@tanstack/react-query';
import config from '../../config/index';

export const QueryKeyMessage = {
  GetMessageList: 'getMessageList',
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostMessageList = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Message.MessageList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostSendMessage = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Message.MessageSend}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePutupdateMessage = () => {
  const queryFn = async (payload: any) =>
    await Api.put(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Message.MessageUpdate}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

export const useExportMessages = () => {
  const queryFn = async () => {
    const response = await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Message.MessageExport}`,
      { responseType: 'blob' },
    );
    return response.data;
  };
  return useMutation({ mutationFn: queryFn });
};

export const useImportMessages = () => {
  const queryFn = async (formData: FormData) => {
    const response = await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Message.MessageImport}`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return response.data;
  };
  return useMutation({ mutationFn: queryFn });
};

export const useDeleteMessage = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Message.MessageDelete}`,
      {
        data: payload,
      },
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostSendMessagePreview = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Message.MessagePreview}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};
