import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation, useQuery } from '@tanstack/react-query';
import config from '../../config';

export const queryKeyTeam = {
  teamList: 'teamList',
};

/**
 * Get Dashboard Details
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetTeamList = (options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Team.TeamList}`);
  return useQuery(
    {
      queryKey: [queryKeyTeam.teamList],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};

/**
 * POST Team List
 *
 * @param payload
 * @param options
 * @returns
 */

export const useTeamList = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Team.TeamDetailedList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * DELETE Team
 *
 * @param payload
 * @param options
 * @returns
 */

export const useTeamDelete = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(`${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Team.TeamDelete}`, {
      data: payload,
    });
  return useMutation({ mutationFn: queryFn });
};

/**
 * Get User Details
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetTeamDetails = (id: string, options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Team.TeamDetail}?_id=${id}`);
  return useQuery(
    {
      queryKey: [queryKeyTeam.teamList, id],
      queryFn,
      refetchOnWindowFocus: true,
      enabled: !!id,
    },
    options,
  );
};
/**
 * POST Team Save
 *
 * @param payload
 * @param options
 * @returns
 */

export const useTeamSave = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Team.TeamSave}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * DELETE Team
 *
 * @param payload
 * @param options
 * @returns
 */

export const useUserFromTeamDelete = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Team.MemberDeleteFromTeam}`,
      {
        data: payload,
      },
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * PATCH Team Save
 *
 * @param payload
 * @param options
 * @returns
 */

export const useTeamUpdate = () => {
  const queryFn = async (payload: any) =>
    await Api.patch(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Team.AddMembersToTeam}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};
