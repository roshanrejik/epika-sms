import { Api } from '@/config/http';
import config from '@/config/index';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation, useQuery } from '@tanstack/react-query';

export const useGetWebPluginDetails = (options?: any) => {
  const queryFn = async () =>
    await Api.get(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.WebPlugin.WebPluginDetail}`,
    );
  return useQuery(
    {
      queryKey: ['webPlugin', 'details'],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};

/**
 * POST Plugin Save
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostWebPluginSave = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.WebPlugin.WebPluginSave}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST Plugin Save
 *
 * @param payload
 * @param options
 * @returns
 */
export const usePostUploadWebPluginImage = () => {
  const queryFn = async (payload: any) => {
    const response = await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.WebPlugin.WebPluginUploadImage}`,
      payload,
      { headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return response.data;
  };

  return useMutation({ mutationFn: queryFn });
};
