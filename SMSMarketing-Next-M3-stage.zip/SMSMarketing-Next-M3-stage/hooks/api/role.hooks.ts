import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation, useQuery } from '@tanstack/react-query';
import config from '../../config';

export const queryKeyRole = {
  roleList: 'roleList',
  defaultAccessLevel: 'default-accessLevel',
  roleDetails: 'roleDetails',
};

/**
 * Get Dashboard Details
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetRoleList = (options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Role.RoleList}`);
  return useQuery(
    {
      queryKey: [queryKeyRole.roleList],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};

/**
 * POST Roles List
 *
 * @param payload
 * @param options
 * @returns
 */

export const useRolesList = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Role.RoleDetailList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * Get Default Access Level
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetDefaultAccessLevel = (options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Role.DefaultAccessLevel}`);
  return useQuery(
    {
      queryKey: [queryKeyRole.roleList],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};

/**
 * Get useGetRoleDetailsById Access Level
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetRoleDetailsById = (_id: string | null, options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Role.RoleDetails}?_id=${_id}`);
  return useQuery(
    {
      queryKey: [queryKeyRole.roleDetails],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};
/**
 * Post Save Role
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostRole = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Role.RoleSave}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * Delete Save Role
 *
 * @param payload
 * @param options
 * @returns
 */

export const useDeleteRole = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(`${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Role.RoleDelete}`, {
      data: payload,
    });
  return useMutation({ mutationFn: queryFn });
};
