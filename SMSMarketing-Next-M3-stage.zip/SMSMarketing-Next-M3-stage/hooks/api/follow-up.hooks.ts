import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation, useQuery } from '@tanstack/react-query';
import config from '../../config/index';
/**
 * POST Plugin Save
 *
 * @param payload
 * @param options
 * @returns
 */
export const QueryKeyFollowUp = {
  GetFollowUpDetails: 'GetFollowUpDetails',
};
export const usePostFollowUpList = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.FollowUp.FollowUpList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST Plugin Save
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetFollowUpDeatils = (id: string | null, options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.FollowUp.FollowUpDetail}?_id=${id}`);
  return useQuery(
    {
      queryKey: [QueryKeyFollowUp.GetFollowUpDetails],
      queryFn,
      refetchOnWindowFocus: true,
      enabled: !!id,
    },
    options,
  );
};

export const usePostFollowUpSave = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.FollowUp.FollowUpSave}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

export const usePostFollowUpAttach = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.FollowUp.FollowUpAttach}?followUpId=${payload.followUpId}&customerPhoneNumber=${payload.customerPhoneNumber}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

export const useFollowUpDelete = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.FollowUp.FollowUpDelete}`,
      {
        data: payload,
      },
    );
  return useMutation({ mutationFn: queryFn });
};
