import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation, useQuery } from '@tanstack/react-query';
import config from '../../config/index';

export const QueryKeyConversation = {
  GetConversationList: 'getConversationList',
  GetConversationDetails: 'getConversationDetails',
  GetConversationBySearchKey: 'getConversationBySearchKey',
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostConversationList = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Conversation.ConversationList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * Get Converstion Details
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetConversationDetails = (id: string | null, options?: any) => {
  const queryFn = async () => {
    if (!id) return;
    return await Api.get(
      `${config.API_VERSION1}/${API_ENDPOINTS.Conversation.ConversationDetail}?_id=${id}`,
    );
  };
  return useQuery(
    {
      queryKey: [QueryKeyConversation.GetConversationDetails, id],
      queryFn,
      refetchOnWindowFocus: true,
      enabled: !!id,
    },
    options,
  );
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostConversationSaveFind = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Conversation.ConversationSaveFind}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostConversationUpdate = () => {
  const queryFn = async (payload: any) =>
    await Api.put(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Conversation.ConversationUpdate}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetConversationBySearchKeyValue = (options?: any) => {
  const queryFn = async () =>
    await Api.get(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Conversation.ConversationSearchKeyValue}`,
    );

  return useQuery(
    {
      queryKey: [QueryKeyConversation.GetConversationBySearchKey],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};
export const useUpdateConversation = () => {
  const queryFn = async (payload: any) =>
    await Api.patch(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Conversation.ConversationMultiUpdate}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};



