import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation, useQuery } from '@tanstack/react-query';
import config from '../../config/index';

export const QueryKeyCampaign = {};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const usePostSaveCampaign = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Campaign.CampaignSave}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

export const usePostListCampaign = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Campaign.CampaignList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};
export const useCampaignDelete = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Campaign.CampaignDelete}`,
      {
        data: payload,
      },
    );
  return useMutation({ mutationFn: queryFn });
};

export const useGetCampaignDetails = (id: any, options?: any) => {
  const queryFn = async () =>
    await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.Campaign.CampaignDetail}?_id=` + id);
  return useQuery(
    {
      queryKey: ['CampaignDetail', id],
      queryFn,
      refetchOnWindowFocus: true,
      enabled: id == 'null' ? false : Boolean(id),
    },
    options,
  );
};

export const usePostCampaignAttach = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Campaign.CampaignAttach}?campaignId=${payload.campaignId}&customerPhoneNumber=${payload.customerPhoneNumber}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};
