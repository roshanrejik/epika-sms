import { Api } from '@/config/http';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import cookies from '@/utils/cookies';
import { useMutation, useQuery } from '@tanstack/react-query';
import config from '../../config/index';

export const QueryKeyUser = {
  GetUserDetails: 'getUserDetails',
  GetUserList: 'getUserList',
};

/**
 * POST User Email Verify
 *
 * @param payload
 * @param options
 * @returns
 */

export const useUserVerifyMailID = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.User.VerifyMailID}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User Login
 *
 * @param payload
 * @param options
 * @returns
 */

export const useUserLogin = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.User.Login}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User List
 *
 * @param payload
 * @param options
 * @returns
 */

export const useUserList = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.User.UserList}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * POST User List
 *
 * @param payload
 * @param options
 * @returns
 */

export const useRefreshToken = async () => {
  try {
    const payload = {
      refreshToken: cookies.get('refreshToken'),
    };
    const res = await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.User.RefreshToken}`,
      payload,
    );
    const { data } = res;
    cookies.set('accessToken', data.accessToken, { path: '/' });
    cookies.set('refreshToken', data.refreshToken, { path: '/' });
    return res;
  } catch (error) {
    console.error('Error refreshing token:', error);
    throw error;
  }
};

/**
 * POST User Save
 *
 * @param payload
 * @param options
 * @returns
 */

export const useUserSave = () => {
  const queryFn = async (payload: any) =>
    await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.User.UserSave}`,
      payload,
    );
  return useMutation({ mutationFn: queryFn });
};

/**
 * DELETE User
 *
 * @param payload
 * @param options
 * @returns
 */

export const useUserDelete = () => {
  const queryFn = async (payload: any) =>
    await Api.delete(`${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.User.UserDelete}`, {
      data: payload,
    });
  return useMutation({ mutationFn: queryFn });
};

/**
 * Get User Details
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetUserDetails = (id: string | null, options?: any) => {
  console.log(Boolean(id));
  const queryFn = async () => {
    if (!id) return;
    return await Api.get(`${config.API_VERSION1}/${API_ENDPOINTS.User.UserDetail}?_id=${id}`);
  };
  return useQuery(
    {
      queryKey: [QueryKeyUser.GetUserDetails, id],
      queryFn,
      refetchOnWindowFocus: true,
      enabled: !!id,
    },
    options,
  );
};

/**
 * Get User Name
 *
 * @param payload
 * @param options
 * @returns
 */

export const useGetUserListName = (
  search?: string,
  excludeUserTeamId?: string | null,
  options?: any,
) => {
  const queryFn = async () =>
    await Api.get(
      `${config.API_VERSION1}/${API_ENDPOINTS.User.UserListName}?search=${search}&excludeUserTeamId=${excludeUserTeamId}`,
    );
  return useQuery(
    {
      queryKey: [QueryKeyUser.GetUserDetails, QueryKeyUser.GetUserList, search],
      queryFn,
      refetchOnWindowFocus: true,
    },
    options,
  );
};
