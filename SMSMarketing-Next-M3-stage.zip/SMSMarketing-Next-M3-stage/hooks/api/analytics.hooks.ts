import { Api } from '@/config/http';
import config from '@/config/index';
import { API_ENDPOINTS } from '@/constants/api-endpoints';
import { useMutation } from '@tanstack/react-query';

/**
 * POST Plugin Save
 *
 * @param payload
 * @param options
 * @returns
 */
export const usePostAnalyticsCounter = () => {
  const queryFn = async (payload: any) => {
    const response = await Api.post(
      `${config.BASE_URL}/${config.API_VERSION1}/${API_ENDPOINTS.Analytics.AnalyticsCounter}`,
      payload,
    );
    return response.data;
  };

  return useMutation({ mutationFn: queryFn });
};
