import { useEffect } from 'react';
import { useSocket } from '@/context/SocketProvider';

type HandleMessage = (message: any) => void;

const useSocketEvent = (messageEvent: string, handleMessage: HandleMessage) => {
  const { socket } = useSocket();

  useEffect(() => {
    if (!socket) return;
    socket.on(messageEvent, handleMessage);
    return () => {
      socket.off(messageEvent, handleMessage);
    };
  }, [socket, messageEvent]);
};

export default useSocketEvent;
