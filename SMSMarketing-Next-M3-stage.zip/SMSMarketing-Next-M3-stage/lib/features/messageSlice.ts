import { createSlice } from '@reduxjs/toolkit';
import type { RootState } from '../store';

// Define a type for the slice state
export interface messageState {
  selectedMessage: any;
}
// Define the initial state using that type
const initialState: messageState = {
  selectedMessage: undefined,
};

export const messageSlice = createSlice({
  name: 'message',
  initialState,
  reducers: {
    setSelectedMessage: (state, action) => {
      state.selectedMessage = action.payload;
    },
  },
});

export const { setSelectedMessage } = messageSlice.actions;

export const user = (state: RootState) => state.user;

export default messageSlice.reducer;
