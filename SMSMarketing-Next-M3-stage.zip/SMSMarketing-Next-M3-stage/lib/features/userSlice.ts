import cookies from '@/utils/cookies';
import { createSlice } from '@reduxjs/toolkit';
import type { RootState } from '../store';

// Define a type for the slice state
export interface userState {
  isAuthenticated: boolean;
  menuOpen: boolean;
  data: userData;
}
export interface userData {
  _id: string;
  name: string;
  role: {
    _id: string;
    name: string;
  };
  accessToken: boolean | string;
}
// Define the initial state using that type
const initialState: userState = {
  isAuthenticated: typeof window !== 'undefined' ? cookies.get('accessToken') : '',
  menuOpen: false,
  data:
    typeof window !== 'undefined'
      ? cookies.get('user')
        ? JSON.parse(atob(cookies.get('user')))
        : ''
      : '',
};

export const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    login: (state) => {
      state.isAuthenticated = true;
    },
    logout: (state) => {
      state.isAuthenticated = false;
    },
    handleMenuOpen: (state) => {
      state.menuOpen = !state.menuOpen;
    },
    setUserData: (state, action) => {
      state.data = action.payload;
      if (state.data) {
        cookies.set('user', btoa(JSON.stringify(state.data)), { path: '/' });
      }
    },
  },
});

export const { login, logout, handleMenuOpen, setUserData } = userSlice.actions;

export const user = (state: RootState) => state.user;

export default userSlice.reducer;
