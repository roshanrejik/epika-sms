'use client';
import { usePostAnalyticsCounter } from '@/hooks/api/analytics.hooks';
import React, { useEffect, useState } from 'react';
import { DatePicker, LocalizationProvider, pickersLayoutClasses } from '@mui/x-date-pickers';
import { Typography, Box } from '@mui/material';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import 'dayjs/locale/de';
import { StyledTextField } from '@/constants/key';
import MessageBreakdownChart from './MessageBreakdownChart';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

const AnalyticScreen = () => {
  const { availableHeight } = useScreenHeight();
  const [analyticsData, setAnalyticsData] = useState([]);
  const [analyticBody, setAnalyticBody] = useState({
    startDate: dayjs(new Date()),
    endDate: dayjs(new Date()),
  });

  const { mutate: postAnalyticsCounter } = usePostAnalyticsCounter();

  useEffect(() => {
    postAnalyticsCounter(
      {
        startDate: analyticBody.startDate.toISOString(),
        endDate: analyticBody.endDate.toISOString(),
      },
      {
        onSuccess: (res) => setAnalyticsData(res.data),
      },
    );
  }, [analyticBody, postAnalyticsCounter]);

  const handleDateChange = (name) => (newValue) => {
    if (newValue && newValue.isValid()) {
      setAnalyticBody((prev) => ({ ...prev, [name]: newValue }));
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box
        p={3}
        sx={{ height: availableHeight, overflow: 'scroll' }}
        border="1px solid #e0e0e0"
        borderRadius={2}
        bgcolor="white"
      >
        <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
          <Box display="flex" alignItems="center">
            <DatePicker
              label="Start Date"
              value={analyticBody.startDate}
              onChange={handleDateChange('startDate')}
              renderInput={(params) => <StyledTextField {...params} />}
              sx={colorer}
            />
            <Box mx={2}>
              <Typography>to</Typography>
            </Box>
            <DatePicker
              label="End Date"
              value={analyticBody.endDate}
              onChange={handleDateChange('endDate')}
              renderInput={(params) => <StyledTextField {...params} />}
              sx={colorer}
            />
          </Box>
        </Box>

        <MessageBreakdownChart analyticsData={analyticsData} />
      </Box>
    </LocalizationProvider>
  );
};

export default AnalyticScreen;

const colorer = {
  '& .MuiOutlinedInput-root': {
    '&:focus-within fieldset': {
      borderColor: 'var(--epika-primary-color)',
    },
  },
  '& .MuiInputLabel-root.Mui-focused': { color: 'var(--epika-primary-color)' },
  '& .MuiInput-underline:after': {
    borderBottomColor: 'var(--epika-primary-color)',
  },
  [`.${pickersLayoutClasses.toolbar}`]: {
    color: 'white',
    backgroundColor: 'var(--epika-primary-color)',
    '& .MuiTypography-root ': {
      color: 'white',
    },
  },
  [`.${pickersLayoutClasses.actionBar}`]: {
    '& .MuiButton-text ': {
      color: 'var(--epika-primary-color)',
    },
  },
  [`.${pickersLayoutClasses.contentWrapper}`]: {
    '& .Mui-selected': {
      backgroundColor: 'var(--epika-primary-color)',
      color: 'white',
    },
    '& .Mui-selected:hover': {
      backgroundColor: 'var(--epika-primary-color)',
      color: 'white',
    },
    '& .Mui-selected:focus': {
      backgroundColor: 'var(--epika-primary-color)',
      color: 'white',
    },
  },
  '& .MuiPickersDay-dayWithMargin': {
    '&:hover': {
      backgroundColor: 'var(--epika-primary-color)',
      color: 'white',
    },
    '&.Mui-selected': {
      backgroundColor: 'var(--epika-primary-color)',
      color: 'white',
    },
    '&.Mui-selected:hover': {
      backgroundColor: 'var(--epika-primary-color)',
      color: 'white',
    },
  },
};
