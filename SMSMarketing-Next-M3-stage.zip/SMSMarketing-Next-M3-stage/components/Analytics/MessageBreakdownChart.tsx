'use strict';
import React from 'react';
import { Line } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';
import 'chartjs-adapter-date-fns';
import { Box, Paper, Typography } from '@mui/material';

// Register all necessary components
Chart.register(...registerables);

const processData = (responseData) => {
  return responseData.data.map((item) => ({
    label: item.date,
    sentCount: item.sentCount,
    receivedCount: item.receivedCount,
    failedCount: item.failedCount,
    cancelledCount: item.cancelledCount,
  }));
};

const MessageBreakdownChart = ({ analyticsData = [] }: any) => {
  const processedData = processData({ data: analyticsData });

  const data = {
    labels: processedData.map((item: any) => item.label),
    datasets: [
      {
        label: 'Sent',
        data: processedData.map((item: any) => item.sentCount),
        fill: false,
        borderColor: '#FFA726',
        backgroundColor: '#FFA726',
      },
      {
        label: 'Received',
        data: processedData.map((item: any) => item.receivedCount),
        fill: false,
        borderColor: '#EF5350',
        backgroundColor: '#EF5350',
      },
      {
        label: 'Failed',
        data: processedData.map((item: any) => item.failedCount),
        fill: false,
        borderColor: '#1111F5',
        backgroundColor: 'rgba(66, 165, 245, 0.5)',
      },
      {
        label: 'Cancelled',
        data: processedData.map((item: any) => item.cancelledCount),
        fill: false,
        borderColor: '#FF6384',
        backgroundColor: '#FF6384',
      },
    ],
  };

  const options = {
    scales: {
      x: {
        type: 'category',
        labels: processedData.map((item: any) => item.label),
      },
      y: {
        beginAtZero: true,
      },
    },
    plugins: {
      legend: {
        display: true,
        position: 'bottom',
      },
    },
  };

  return (
    <Paper elevation={3} sx={{ padding: 3 }}>
      <Typography variant="h6" gutterBottom>
        Message Breakdown by Type
      </Typography>
      <Box sx={{ width: '100%' }}>
        <Line data={data} sx={{ width: '100%' }} options={options} />
      </Box>
    </Paper>
  );
};

export default MessageBreakdownChart;
