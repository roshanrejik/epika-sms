'use client';
import { Box, Button, InputAdornment, Modal } from '@mui/material';
import React, { useEffect, useState } from 'react';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import styles from '../../styles/admin.module.css';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import { StyledTextField } from '@/constants/key';
import PeopleOutlineOutlinedIcon from '@mui/icons-material/PeopleOutlineOutlined';
import CreateCannedResponse from './CreateCannedResponse';
import { usePostCannedMessageList, usePostCannedMessageSave } from '@/hooks/api/canned.hooks';
import CannedTable from '../Tables/CannedTable';
import { showToast } from '../common/Toast/defaultToastOptions';

const CannedScreen = () => {
  const [openModal, setOpenModal] = useState(false);
  const { mutate: saveCannedMessage } = usePostCannedMessageSave();
  const { mutate: postCannedMessageList } = usePostCannedMessageList();
  const [cannedTableData, setCannedTableData] = useState([]);
  const [customerFields, setCustomerFields] = useState([]);
  const [totalCount, setTotalCount] = useState(0);

  const [cannedListBody, setCannedListBody] = useState({
    page: 0,
    limit: 10,
    search: '',
    shared: '',
  });
  const onError = (err: any) =>
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  useEffect(() => {
    const payload = {
      ...cannedListBody,
      page: cannedListBody.page + 1,
    };
    postCannedMessageList(payload, {
      onSuccess: (res) => {
        setCannedTableData(res.data.data);
        setTotalCount(res.data.totalCount);
        setCustomerFields(res.data.customerFields);
      },
      onError: onError,
    });
  }, [cannedListBody]);

  const handleAddMemberClick = () => {
    setOpenModal(true);
  };

  const handleClose = () => {
    postCannedMessageList(
      { ...cannedListBody, page: 1 },
      {
        onSuccess: (res) => {
          setCannedTableData(res.data.data);
          setCustomerFields(res.data.customerFields);
          setOpenModal(false);
        },
        onError: (err: any) => {
          onError(err);
          setOpenModal(false);
        },
      },
    );
  };

  const handleToggleProperty = (e: any, id: string, status: boolean) => {
    e.preventDefault();
    setCannedTableData((prevState: any) =>
      prevState.map((item: any) => (item._id === id ? { ...item, shared: !status } : item)),
    );
    saveCannedMessage({ _id: id, shared: !status }, { onError: onError });
  };

  return (
    <Box sx={{ margin: '0px 0px', width: '100%' }}>
      <Box sx={{ margin: '20px', display: 'flex', justifyContent: 'space-between' }}>
        <Box sx={{ display: 'flex', columnGap: '10px' }}>
          <Button
            startIcon={<AddOutlinedIcon />}
            size="small"
            onClick={handleAddMemberClick}
            className={styles.adminButton}
          >
            ADD Canned Response
          </Button>
          <Button
            startIcon={<PeopleOutlineOutlinedIcon />}
            size="small"
            disabled
            sx={{
              color: 'black',
              borderRadius: '30px',
              padding: '6px 20px',
              textTransform: 'none',
              '&:disabled': {
                bgcolor: 'white',
                color: 'black',
              },
            }}
          >
            {cannedTableData?.length + ' Canned Responses'}
          </Button>
        </Box>

        <StyledTextField
          id="outlined-basic"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchOutlinedIcon />
              </InputAdornment>
            ),
          }}
          placeholder="Search canned responses"
          value={cannedListBody.search}
          onChange={(e) => setCannedListBody({ ...cannedListBody, search: e.target.value })}
          variant="outlined"
        />

        <Modal
          open={openModal}
          onClose={() => setOpenModal(false)}
          aria-labelledby="modal-title"
          aria-describedby="modal-description"
        >
          <Box
            sx={{
              p: 2,
              maxWidth: '550px',
              maxHeight: '500px',
              borderRadius: '10px',
              margin: 'auto',
              mt: '10%',
              bgcolor: 'background.paper',
            }}
          >
            <CreateCannedResponse
              customerFields={customerFields}
              initialName={''}
              initialText={''}
              initialShared={false}
              onSave={() => {
                handleClose();
                setTotalCount((prev) => prev + 1);
              }}
              handleClose={handleClose}
              onError={onError}
            />
          </Box>
        </Modal>
      </Box>
      <Box sx={{ margin: '25px 25px' }}>
        <CannedTable
          data={cannedTableData}
          setData={setCannedTableData}
          handleToggleProperty={handleToggleProperty}
          totalCount={totalCount}
          setTotalCount={setTotalCount}
          cannedListBody={cannedListBody}
          customerFields={customerFields}
          setCannedListBody={setCannedListBody}
        />
      </Box>
    </Box>
  );
};

export default CannedScreen;
