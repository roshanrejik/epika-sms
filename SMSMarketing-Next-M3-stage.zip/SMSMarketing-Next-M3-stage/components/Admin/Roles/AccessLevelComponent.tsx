import React from 'react';
import { Box, Typography, Checkbox, FormControlLabel } from '@mui/material';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

interface AccessLevel {
  _id: number;
  parentId: number;
  name: string;
  access: boolean;
}

interface AccessLevelComponentProps {
  defaultAccessLevelValue: AccessLevel[];
  setDefaultAccessLevelValue: any;
  readOnly: string | null;
}

const AccessLevelComponent: React.FC<AccessLevelComponentProps> = ({
  defaultAccessLevelValue,
  setDefaultAccessLevelValue,
  readOnly,
}) => {
  const parentItems = defaultAccessLevelValue?.filter((item) => item.parentId === 0);
  const childItems = defaultAccessLevelValue?.filter((item) => item.parentId !== 0);
  const { availableHeight } = useScreenHeight();
  const getChildItems = (parentId: number) => {
    return childItems.filter((item) => item.parentId === parentId);
  };

  const handleCheckboxChange = (id: number, isParent: boolean) => {
    const updatedAccessLevels = defaultAccessLevelValue.map((item) => {
      if (item._id === id) {
        return { ...item, access: !item.access };
      } else if (isParent && item.parentId === id) {
        return { ...item, access: !defaultAccessLevelValue.find((i) => i._id === id)?.access };
      }
      return item;
    });

    setDefaultAccessLevelValue(updatedAccessLevels);
  };
  return (
    <Box
      sx={{
        margin: '25px 25px 25px 25px',
        overflow: 'scroll',
        height: availableHeight - 250 + 'px',
      }}
    >
      {parentItems?.map((parent) => (
        <Box key={parent._id} sx={{ marginBottom: 2 }}>
          <FormControlLabel
            control={
              <Checkbox
                checked={parent.access}
                disabled={readOnly ? true : false}
                sx={{
                  color: 'var(--epika-primary-color)',
                  '&.Mui-checked': {
                    color: 'var(--epika-primary-color)', // Set the color for the checked state
                  },
                }}
                onChange={() => handleCheckboxChange(parent._id, true)}
              />
            }
            label={
              <Typography variant="h5" sx={{ fontWeight: 700 }}>
                {parent.name}
              </Typography>
            }
          />
          <Box sx={{ marginLeft: 3 }}>
            {getChildItems(parent._id)?.map((child) => (
              <FormControlLabel
                key={child._id}
                control={
                  <Checkbox
                    checked={child.access}
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)', // Set the color for the checked state
                      },
                    }}
                    disabled={!parent.access || readOnly ? true : false}
                    onChange={() => handleCheckboxChange(child._id, false)}
                  />
                }
                label={<Typography sx={{ fontWeight: 400 }}>{child.name}</Typography>}
              />
            ))}
          </Box>
        </Box>
      ))}
    </Box>
  );
};

export default AccessLevelComponent;
