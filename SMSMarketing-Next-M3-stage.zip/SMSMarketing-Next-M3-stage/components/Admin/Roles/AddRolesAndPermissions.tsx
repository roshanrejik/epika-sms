'use client';
import {
  Box,
  Button,
  Grid,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import React, { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  useGetDefaultAccessLevel,
  useGetRoleDetailsById,
  usePostRole,
} from '@/hooks/api/role.hooks';
import AccessLevelComponent from '@/components/Admin/Roles/AccessLevelComponent';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import EditIcon from '@mui/icons-material/Edit';

const AddRolesAndPermissions = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const id = searchParams.get('id');
  const readOnly = searchParams.get('readOnly');
  const [roleName, setRoleName] = useState('');
  const [editName, setEditName] = useState(id ? false : true);
  const { data: defaultAccessLevel, isFetched } = useGetDefaultAccessLevel();
  const { data: roleAccessLevel, isFetched: isFetchedRole } = useGetRoleDetailsById(id);
  const { mutate: postRole } = usePostRole();
  const [defaultAccessLevelValue, setDefaultAccessLevelValue] = useState([]);

  useEffect(() => {
    if (id && isFetchedRole) {
      setDefaultAccessLevelValue(roleAccessLevel?.data?.data?.accessLevels);
      setRoleName(roleAccessLevel?.data?.data?.name);
    } else if (isFetched && !id) {
      setDefaultAccessLevelValue(defaultAccessLevel?.data?.data);
    }
  }, [isFetched, defaultAccessLevel, isFetchedRole, roleAccessLevel]);

  const handleNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    const capitalizedValue = value.charAt(0).toUpperCase() + value.slice(1);
    setRoleName(capitalizedValue);
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  };

  const handleSubmit = () => {
    const payload = id
      ? {
          _id: id,
          name: roleName,
          accessLevels: defaultAccessLevelValue,
        }
      : {
          name: roleName,
          accessLevels: defaultAccessLevelValue,
        };
    postRole(payload, {
      onSuccess: (res) => {
        showToast('success', res.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-success',
        });
        router.push('/admin/roles-and-permissions/');
      },
      onError: onError,
    });
  };

  return (
    <Box sx={{ margin: '25px 25px 25px 25px' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignContent: 'center' }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <IconButton onClick={() => router.push('/admin/roles-and-permissions/')}>
            <ArrowBackIcon />
          </IconButton>
          ROLE PAGE
        </Box>
        <Box
          sx={{
            fontSize: 'var(--epika-primary-font-size)',

            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {editName ? (
            <TextField
              value={roleName}
              placeholder={'Enter Role Name'}
              onChange={handleNameChange}
              variant="standard"
              InputProps={{
                sx: {
                  fontSize: 'var(--epika-primary-font-size)',
                  '&:before': {
                    borderBottom: '1px solid rgba(0, 0, 0, 0.42)',
                  },
                  '&:hover:not(.Mui-disabled):before': {
                    borderBottom: '1px solid rgba(0, 0, 0, 0.87)',
                  },
                  '&:after': {
                    borderBottom: '2px solid var(--epika-primary-color)',
                  },
                },
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => setEditName(!editName)}>
                      <CheckCircleOutlineIcon />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          ) : (
            <Box
              sx={{
                fontSize: 'var(--epika-primary-font-size)',
              }}
            >
              {roleName}{' '}
              <IconButton onClick={() => setEditName(!editName)}>
                <EditIcon />
              </IconButton>
            </Box>
          )}
        </Box>

        <Button
          size="large"
          onClick={handleSubmit}
          sx={{
            color: 'primary.contrastText',
            backgroundColor: 'var(--epika-primary-color)',
            borderRadius: '30px',
            minWidth: '150px',
            padding: '15px 20px',
            '&:hover': {
              bgcolor: 'var(--epika-primary-color)',
              color: 'white',
            },
          }}
        >
          SAVE ROLE
        </Button>
      </Box>
      <Grid item xs={12} sx={{ margin: '20px' }}>
        <Typography
          sx={{
            fontSize: 'var(--epika-primary-header-size)',
            fontWeight: '700',
          }}
        >
          {readOnly ? 'View Role' : id ? 'Edit Role' : 'Add New Role'}
        </Typography>
      </Grid>
      <AccessLevelComponent
        defaultAccessLevelValue={defaultAccessLevelValue}
        setDefaultAccessLevelValue={setDefaultAccessLevelValue}
        readOnly={readOnly}
      />
    </Box>
  );
};

export default AddRolesAndPermissions;
