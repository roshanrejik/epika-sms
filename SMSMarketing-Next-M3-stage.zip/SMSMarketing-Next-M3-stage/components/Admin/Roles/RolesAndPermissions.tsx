'use client';
import { StyledTextField } from '@/constants/key';
import { Box, Button, InputAdornment } from '@mui/material';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import SearchIcon from '@mui/icons-material/Search';
import React, { useEffect, useMemo, useState } from 'react';
import { RoleCard } from '@/components/Admin/Roles/RoleCard';
import { useRouter } from 'next/navigation';
import { useDeleteRole, useRolesList } from '@/hooks/api/role.hooks';
import debounce from 'lodash.debounce';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import styles from '../../../styles/admin.module.css';
import ModalDialoge from '@/components/common/ModalDialog/ModalDialoge';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

const RolesAndPermissions = () => {
  const [rolesList, setRolesList] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const { mutate: getRoles } = useRolesList();
  const { mutate: deleteRoleAPI } = useDeleteRole();
  const [showNonDeletableModel, setshowNonDeletableModel] = useState(false);
  const { availableHeight } = useScreenHeight();
  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    id: string | null;
    flag: boolean;
  }>({
    id: null,
    flag: false,
  });
  const router = useRouter();

  useEffect(() => {
    const rolesListRequestBody = {
      page: 1,
      limit: 100,
      search: searchTerm,
    };

    debouncedChangeHandler(rolesListRequestBody);
  }, [searchTerm]);

  const debouncedChangeHandler = useMemo(
    () =>
      debounce((rolesListRequestBody) => {
        getRoles(rolesListRequestBody, {
          onSuccess: (res: any) => {
            setRolesList(res.data.data);
          },
        });
      }, 200),
    [],
  );

  const deleteRole = () => {
    const payload = {
      _id: [showdeleteModelFlag.id],
    };

    deleteRoleAPI(payload, {
      onSuccess: (res) => {
        setRolesList((prev: any) => prev.filter((ele: any) => ele._id !== showdeleteModelFlag.id));
        showToast('success', res.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-success',
        });
      },
      onError: (err: any) => {
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });

    setShowdeleteModelFlag({ id: null, flag: false });
  };
  return (
    <div>
      <Box className={styles.adminContainer}>
        <Button
          startIcon={<AddOutlinedIcon />}
          size="small"
          onClick={() => router.push('/admin/roles-and-permissions/add-role')}
          className={styles.adminButton}
        >
          ADD ROLE
        </Button>
        <StyledTextField
          id="outlined-basic"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
          placeholder="Search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          variant="outlined"
        />
      </Box>
      <Box sx={{ padding: '20px 40px', overflow: 'scroll', height: availableHeight - 150 + 'px' }}>
        <Box
          sx={{
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {rolesList?.map((item: any) => (
            <RoleCard
              title={item.name}
              key={item._id}
              id={item._id}
              defaultRole={item.default}
              assignedUsers={item.userCount}
              setshowNonDeletableModel={setshowNonDeletableModel}
              deleteRole={(_id: string) => setShowdeleteModelFlag({ flag: true, id: _id })}
            />
          ))}
        </Box>
      </Box>
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Delete"
        dialogType={'delete'}
        contentText={'Are you sure you want to delete the role?'}
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
        onClickOK={() => deleteRole()}
      />
      <ModalDialoge
        open={showNonDeletableModel}
        onClose={() => setshowNonDeletableModel(false)}
        title="Alert"
        dialogType={'deletelastDealer'}
        contentText={
          'This role cannot be deleted because it is currently assigned to some users. To delete this role, you must first remove it from all assigned users.'
        }
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
      />
    </div>
  );
};

export default RolesAndPermissions;
