import React, { useState } from 'react';
import { Card, CardContent, Box, Typography, IconButton, Menu, MenuItem } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useRouter } from 'next/navigation';

export const RoleCard = ({
  title,
  assignedUsers,
  defaultRole,
  id,
  deleteRole,
  setshowNonDeletableModel,
}: any) => {
  const router = useRouter();
  const [anchorEl, setAnchorEl] = useState(null);

  const handleMenuOpen = (event: any) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleManageTeam = () => {
    router.push('/admin/roles-and-permissions/add-role?id=' + id);
    handleMenuClose();
  };
  const handleManageViewTeam = () => {
    router.push('/admin/roles-and-permissions/add-role?id=' + id + '&readOnly=true');
    handleMenuClose();
  };
  const handleDelete = () => {
    // Handle delete action
    if (assignedUsers > 0) {
      setshowNonDeletableModel(true);
    } else {
      deleteRole(id);
      handleMenuClose();
    }
  };

  return (
    <Card sx={{ minWidth: '300px', m: 1, borderRadius: '8px', boxShadow: 3 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6" sx={{ fontWeight: 700 }}>
            {title}{' '}
            <CheckCircleIcon sx={{ fontSize: 'small', color: 'var(--epika-primary-color)' }} />
          </Typography>
          <IconButton size="small" onClick={handleMenuOpen}>
            <MoreVertIcon />
          </IconButton>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
            anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            sx={{
              display: 'flex',
              flexDirection: 'column',
              padding: '1rem',
              alignItems: 'flex-start', // Align items to the start
            }}
          >
            <MenuItem onClick={handleManageViewTeam}>
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'flex-start', // Align content to the start
                  borderRadius: 2,
                  width: '100%', // Ensure full width for proper alignment
                }}
              >
                <VisibilityIcon sx={{ marginRight: '0.5rem' }} /> View Permissions
              </Box>
            </MenuItem>
            <MenuItem onClick={handleManageTeam} disabled={defaultRole}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <EditIcon sx={{ marginRight: '0.5rem' }} /> Edit Permissions
              </Box>
            </MenuItem>
            <MenuItem onClick={handleDelete}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <DeleteIcon sx={{ marginRight: '0.5rem' }} />
                Delete
              </Box>
            </MenuItem>
          </Menu>
        </Box>
        <Typography variant="body2" color="textSecondary">
          Assigned to:{' '}
          <Typography component="span" sx={{ color: 'var(--epika-primary-color)' }}>
            {assignedUsers} {assignedUsers <= 1 ? 'user' : 'users'}
          </Typography>
        </Typography>
      </CardContent>
    </Card>
  );
};
