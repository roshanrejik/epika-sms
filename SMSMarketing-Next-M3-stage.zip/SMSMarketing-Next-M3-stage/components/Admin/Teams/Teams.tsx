'use client';
import { Box, Button, InputAdornment } from '@mui/material';
import React, { useEffect, useMemo, useState } from 'react';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import SearchIcon from '@mui/icons-material/Search';
import { useRouter } from 'next/navigation';
import debounce from 'lodash.debounce';
import TeamsTable from '@/components/Tables/TeamsTable';
import { useTeamList } from '@/hooks/api/team.hooks';
import GlassLoader from '@/components/common/Loader/GlassLoader';
import { StyledTextField } from '@/constants/key';
import styles from '../../../styles/admin.module.css';

const Teams = () => {
  const router = useRouter();
  const { mutate: listTeams } = useTeamList();

  const [teamsTableData, setTeamsTableData] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [firstTimeFlag, setFirstTimeFlag] = useState(true);
  const [teamListBody, setTeamsListBody] = useState({
    page: 0,
    limit: 10,
    search: '',
  });

  useEffect(() => {
    const teamsListRequestBody = {
      ...teamListBody,
      page: teamListBody.page + 1,
    };
    debouncedChangeHandler(teamsListRequestBody);
  }, [teamListBody.page, teamListBody.limit, teamListBody.search]);

  const onSuccess = (res: any) => {
    setTeamsTableData(res.data.data);
    setTotalCount(res.data.totalCount);
    setFirstTimeFlag(false);
  };

  const onError = () => {};

  const debouncedChangeHandler = useMemo(
    () =>
      debounce(
        (teamListRequestBody) =>
          listTeams(teamListRequestBody, { onSuccess: onSuccess, onError: onError }),
        200,
      ),
    [],
  );

  const navToAddTeam = () => {
    router.push('/admin/teams/add-team');
  };

  return (
    <Box>
      <Box className={styles.adminContainer}>
        <Button
          startIcon={<AddOutlinedIcon />}
          size="small"
          onClick={navToAddTeam}
          className={styles.adminButton}
        >
          ADD TEAM
        </Button>
        <StyledTextField
          id="outlined-basic"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
          placeholder="Search"
          value={teamListBody.search}
          onChange={(e) => setTeamsListBody({ ...teamListBody, search: e.target.value, page: 0 })}
          variant="outlined"
        />
      </Box>
      <Box sx={{ margin: '25px 25px 25px 25px' }}>
        {teamsTableData.length == 0 && firstTimeFlag ? (
          <GlassLoader />
        ) : (
          <TeamsTable
            data={teamsTableData}
            setData={setTeamsTableData}
            teamListBody={teamListBody}
            setTeamsListBody={setTeamsListBody}
            totalCount={totalCount}
            setTotalCount={setTotalCount}
            debouncedChangeHandler={debouncedChangeHandler}
          />
        )}
      </Box>
    </Box>
  );
};

export default Teams;
