'use client';
import UsersTable from '@/components/Tables/UsersTable';
import {
  useGetTeamDetails,
  useTeamSave,
  useTeamUpdate,
  useUserFromTeamDelete,
} from '@/hooks/api/team.hooks';
import { useGetUserListName, useUserList } from '@/hooks/api/user.hooks';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import PeopleOutlineOutlinedIcon from '@mui/icons-material/PeopleOutlineOutlined';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import { Box, Button, IconButton, InputAdornment, Popover, TextField } from '@mui/material';
import { useRouter, useSearchParams } from 'next/navigation';
import React, { useEffect, useMemo, useState } from 'react';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SettingsIcon from '@mui/icons-material/Settings';
import debounce from 'lodash.debounce';
import GlassLoader from '@/components/common/Loader/GlassLoader';
import AddTeamMember from '@/components/Admin/Teams/AddTeamMember';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import { StyledTextField } from '@/constants/key';
import EditIcon from '@mui/icons-material/Edit';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import styles from '../../../styles/admin.module.css';
import ModalDialoge from '@/components/common/ModalDialog/ModalDialoge';

const EditTeam = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const id = searchParams.get('id');
  const [userTableData, setUserTableData] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [firstTimeFlag, setFirstTimeFlag] = useState(true);
  const [userListByTeamBody, setUserListByTeamBody] = useState({
    page: 0,
    limit: 10,
    search: '',
    roleId: '',
    teamId: [id],
    active: '',
    sortField: '',
    sortOrder: -1,
  });
  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    id: string | null;
    flag: boolean;
  }>({
    id: null,
    flag: false,
  });
  const [anchorEl, setAnchorEl] = useState(null);

  const handleAddMemberClick = (event: any) => {
    setAnchorEl(event.currentTarget);
  };

  const { mutate: deleteMemberFromTeam } = useUserFromTeamDelete();

  const open = Boolean(anchorEl);
  const ids = open ? 'simple-popover' : undefined;
  const { mutate: updateTeam, isPending } = useTeamUpdate();
  const { mutate: saveTeam } = useTeamSave();
  const [search, setSearch] = useState('');
  const { data: teamDetails, isSuccess, refetch: refetchDetails } = useGetTeamDetails(id || '');
  const { mutate: listUsers } = useUserList();
  const { data: userList, isSuccess: isUserListSuccess, refetch } = useGetUserListName(search, id);
  const [userListForSelect, setUserListForSelect] = useState([]);
  const [teamName, setTeamName] = useState('');
  const [editName, setEditName] = useState(false);
  const [addMembers, setAddMembers] = useState([]);

  const handleClose = () => {
    setSearch('');
    setAddMembers([]);
    setAnchorEl(null);
  };

  useEffect(() => {
    if (isUserListSuccess) {
      const updatedUserList = userList?.data?.data.map((user: any) => ({
        ...user,
        // Check if the user is already in addMembers and set `checked` accordingly
        checked: addMembers.some((member: any) => member._id === user._id),
      }));
      setUserListForSelect(updatedUserList);
    }
  }, [isUserListSuccess, userList?.data, addMembers]);

  useEffect(() => {
    if (isSuccess) {
      setTeamName(teamDetails?.data?.data?.name);
    }
  }, [isSuccess, teamDetails?.data?.data?.name]);

  useEffect(() => {
    const userListRequestBody = {
      ...userListByTeamBody,
      page: userListByTeamBody.page + 1,
      teamId: [id],
    };
    debouncedChangeHandler(userListRequestBody);
  }, [
    userListByTeamBody.page,
    userListByTeamBody.search,
    userListByTeamBody.roleId,
    userListByTeamBody.teamId,
    userListByTeamBody.active,
    userListByTeamBody.sortField,
    userListByTeamBody.limit,
    userListByTeamBody.sortOrder,
  ]);

  const debouncedChangeHandler = useMemo(
    () =>
      debounce(
        (userListRequestBody) =>
          listUsers(userListRequestBody, { onSuccess: onSuccess, onError: onError }),
        200,
      ),
    [],
  );

  const handleAddMember = (user: any) => {
    setAddMembers((prev: any) => {
      // Check if the user is already in the list
      const isUserPresent = prev.some((member: any) => member._id === user._id);

      if (isUserPresent) {
        // Remove the user from the list if they are already present
        return prev.filter((member: any) => member._id !== user._id);
      } else {
        // Add the user to the list if they are not present
        return [...prev, { ...user, checked: !user.checked }];
      }
    });

    setUserListForSelect((prev: any) =>
      // Update the checked status of the user in userListForSelect
      prev.map((ele: any) => (ele._id === user._id ? { ...ele, checked: !ele.checked } : ele)),
    );
  };

  const onSuccess = (res: any) => {
    setUserTableData(res.data.data);
    setTotalCount(res.data.totalCount);
    setFirstTimeFlag(false);
  };
  const onSuccessRemoveMember = (res: any) => {
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
    refetch();
  };
  const handleDeleteFromTeam = () => {
    setUserTableData((prev: any) => prev.filter((ele: any) => ele._id !== showdeleteModelFlag.id));
    const payload = {
      teamId: id,
      userId: showdeleteModelFlag.id,
    };
    deleteMemberFromTeam(payload, { onSuccess: onSuccessRemoveMember, onError });
    setShowdeleteModelFlag({ flag: false, id: null });
  };
  const handleNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    const capitalizedValue = value.charAt(0).toUpperCase() + value.slice(1);
    setTeamName(capitalizedValue);
  };
  const handleSubmit = () => {
    const memberId = addMembers
      .filter((ele: any) => ele.checked) // Filter elements where 'checked' is true
      .map((ele: any) => {
        return {
          _id: ele._id,
        };
      });
    const payload = {
      teamId: id,
      members: [...memberId],
    };
    updateTeam(payload, {
      onSuccess: (res) => {
        showToast('success', res.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-success',
        });
        handleClose();
        refetch();
        debouncedChangeHandler({ ...userListByTeamBody, page: userListByTeamBody.page + 1 });
      },
      onError: onError,
    });
  };
  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
    debouncedChangeHandler({ ...userListByTeamBody, page: userListByTeamBody.page + 1 });
  };
  const callSaveNameAPI = () => {
    setEditName(false);
    saveTeam(
      {
        name: teamName,
        _id: id,
      },
      {
        onSuccess: () => refetchDetails(),
        onError: onError,
      },
    );
  };
  return (
    <div>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          height: '50px',
          margin: '10px 30px',
        }}
      >
        <Box>
          <IconButton onClick={() => router.back()}>
            <ArrowBackIcon />
          </IconButton>
          TEAM PAGE
        </Box>
        <Box
          sx={{
            fontSize: 'var(--epika-primary-font-size)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {editName ? (
            <TextField
              value={teamName}
              onChange={handleNameChange}
              variant="standard"
              InputProps={{
                sx: {
                  fontSize: 'var(--epika-primary-font-size)',
                  '&:before': {
                    borderBottom: '1px solid rgba(0, 0, 0, 0.42)',
                  },
                  '&:hover:not(.Mui-disabled):before': {
                    borderBottom: '1px solid rgba(0, 0, 0, 0.87)',
                  },
                  '&:after': {
                    borderBottom: '2px solid var(--epika-primary-color)',
                  },
                },
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={callSaveNameAPI}>
                      <CheckCircleOutlineIcon />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          ) : (
            <Box
              sx={{
                fontSize: 'var(--epika-primary-font-size)',
              }}
            >
              {teamName}{' '}
              <IconButton onClick={() => setEditName(!editName)}>
                <EditIcon />
              </IconButton>
            </Box>
          )}
        </Box>
        <Box sx={{ color: 'white' }}>
          <IconButton sx={{ color: 'white' }}>
            <SettingsIcon />
          </IconButton>
          ADVANCED SETTINGS
        </Box>
      </Box>{' '}
      <Box sx={{ margin: '20px', display: 'flex', justifyContent: 'space-between' }}>
        <Box sx={{ display: 'flex', columnGap: '10px' }}>
          <Button
            startIcon={<AddOutlinedIcon />}
            size="small"
            onClick={handleAddMemberClick}
            className={styles.adminButton}
          >
            ADD MEMBER
          </Button>
          <Button
            startIcon={<PeopleOutlineOutlinedIcon />}
            size="small"
            disabled
            sx={{
              color: 'black',
              borderRadius: '30px',
              padding: '6px 20px',
              textTransform: 'none',
              '&:disabled': {
                bgcolor: 'white',
                color: 'black',
              },
            }}
          >
            {userTableData?.length + ' Members'}
          </Button>
        </Box>

        <StyledTextField
          id="outlined-basic"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchOutlinedIcon />
              </InputAdornment>
            ),
          }}
          placeholder="Search"
          value={userListByTeamBody.search}
          onChange={(e) => setUserListByTeamBody({ ...userListByTeamBody, search: e.target.value })}
          variant="outlined"
        />

        <Popover
          id={ids}
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: 'center',
            horizontal: 'right',
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'left',
          }}
          sx={{ marginLeft: '20px' }}
        >
          <Box
            sx={{
              p: 2,
              maxWidth: '350px',
              maxHeight: '400px',
              borderRadius: '10px',
            }}
          >
            <AddTeamMember
              userList={userListForSelect}
              addMembers={addMembers}
              isPending={isPending}
              setSearch={setSearch}
              search={search}
              handleClose={handleClose}
              handleAddMember={handleAddMember}
              handleSubmit={handleSubmit}
            />
          </Box>
        </Popover>
      </Box>
      {id && !firstTimeFlag ? (
        <Box sx={{ padding: '20px' }}>
          <UsersTable
            data={userTableData}
            refetch={refetch}
            setData={setUserTableData}
            fromScreen={'team'}
            userListBody={userListByTeamBody}
            setUserListBody={setUserListByTeamBody}
            handleDeleteFromTeam={(data: any) =>
              setShowdeleteModelFlag({ flag: true, id: data._id })
            }
            totalCount={totalCount}
            setTotalCount={setTotalCount}
            debouncedChangeHandler={debouncedChangeHandler}
          />
        </Box>
      ) : id ? (
        <GlassLoader />
      ) : null}
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Remove Agent"
        dialogType={'delete'}
        contentText={'Are you sure you want to remove the agent from team?'}
        actionButtonText={'Remove'}
        cancelText={'Cancel'}
        onClickOK={() => handleDeleteFromTeam()}
      />{' '}
    </div>
  );
};

export default EditTeam;
