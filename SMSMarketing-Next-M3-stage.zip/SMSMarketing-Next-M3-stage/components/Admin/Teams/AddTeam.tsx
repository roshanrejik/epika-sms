'use client';
import RHFSelect from '@/components/common/Select/RHFSelect';
import RHFTextField from '@/components/common/TextField/RHFTextField';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import FormProvider from '@/context/FormProvider';
import { useTeamSave } from '@/hooks/api/team.hooks';
import { useGetUserListName } from '@/hooks/api/user.hooks';
import { userListForSelection } from '@/utils/helpers';
import { TeamAddFormSchema } from '@/validations/Auth/AgentSchema';
import { yupResolver } from '@hookform/resolvers/yup';
import { Box, Button, CircularProgress, Grid, IconButton, Typography } from '@mui/material';
import { useRouter } from 'next/navigation';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import React from 'react';
import { useForm } from 'react-hook-form';
import styles from '../../../styles/admin.module.css';

const AddTeam = () => {
  const router = useRouter();
  const defaultValues = {
    name: '',
    members: [],
  };
  const { mutate: saveTeam, isPending } = useTeamSave();
  const { data: userList } = useGetUserListName('');
  const btnstyle = { margin: '20px 0', backgroundColor: 'var(--epika-primary-color)' };
  const methods = useForm({
    resolver: yupResolver(TeamAddFormSchema),
    defaultValues,
  });

  const onSuccess = (res: any) => {
    router.push('/admin/teams/');
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
  };
  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  };

  const onSubmit = (data: any) => {
    const payload = {
      ...data,
      members: data.members.map((member: any) => ({ _id: member, teamOwner: false })),
    };
    console.log(payload);
    saveTeam(payload, { onSuccess: onSuccess, onError: onError });
  };

  return (
    <FormProvider methods={methods} onSubmit={methods.handleSubmit((data) => onSubmit(data))}>
      <Box className={styles.adminAgentsContainer}>
        <Box>
          <IconButton onClick={() => router.back()}>
            <ArrowBackIcon />
          </IconButton>
          TEAMS PAGE
        </Box>
      </Box>
      <Grid container spacing={3} className={styles.adminAgentsTable}>
        <Grid item xs={12} className={styles.adminAgentsTableHeader}>
          <Typography
            sx={{
              fontSize: 'var(--epika-primary-header-size)',
              fontWeight: '700',
            }}
          >
            Add New Team
          </Typography>
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <RHFTextField name="name" label="Team Name" type="capitalize" />
        </Grid>
        <Grid item xs={12} md={6} lg={4}>
          <RHFSelect
            name="members"
            label="Members"
            multiple={true}
            options={userListForSelection(userList?.data?.data) || []}
          />
        </Grid>
        <Grid item xs={12} className={styles.adminButtonSpacing}>
          <Button
            type="submit"
            color="primary"
            variant="contained"
            style={btnstyle}
            className={styles.adminButtonBottom}
            disabled={isPending}
            fullWidth
          >
            {isPending ? <CircularProgress size={24} sx={{ color: 'white' }} /> : 'Submit'}
          </Button>
        </Grid>
      </Grid>
    </FormProvider>
  );
};

export default AddTeam;
