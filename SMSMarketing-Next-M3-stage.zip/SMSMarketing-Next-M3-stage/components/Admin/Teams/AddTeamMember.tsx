import React from 'react';
import {
  Box,
  Typography,
  IconButton,
  InputAdornment,
  List,
  ListItem,
  ListItemText,
  Checkbox,
  Button,
  CircularProgress,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import { btnstyle, StyledTextField } from '@/constants/key';
import AccountCircleRoundedIcon from '@mui/icons-material/AccountCircleRounded';

const AddTeamMember = ({
  userList,
  handleClose,
  isPending,
  handleAddMember,
  handleSubmit,
  search,
  setSearch,
  addMembers,
}: any) => {
  return (
    <Box>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 2,
        }}
      >
        <Typography variant="h6">Add Team Member</Typography>
        <IconButton size="small" onClick={handleClose}>
          <CloseIcon />
        </IconButton>
      </Box>
      <StyledTextField
        placeholder="Search by name or email"
        fullWidth
        variant="outlined"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        id="outlined-basic"
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchOutlinedIcon />
            </InputAdornment>
          ),
        }}
      />

      <List>
        {userList.map((user: any, index: any) => (
          <ListItem
            key={index}
            secondaryAction={
              <Checkbox
                edge="end"
                checked={user.checked}
                onChange={() => handleAddMember(user)}
                sx={{
                  color: 'var(--epika-primary-color)',
                  '&.Mui-checked': {
                    color: 'var(--epika-primary-color)', // Set the color for the checked state
                  },
                }}
              />
            }
          >
            <AccountCircleRoundedIcon
              sx={{
                fontSize: 'var(--epika-primary-icon-size)',
                color: 'gray',
              }}
            />

            <ListItemText primary={user.name} secondary={user.email} />
          </ListItem>
        ))}
      </List>
      <Button
        type="submit"
        color="primary"
        variant="contained"
        style={btnstyle}
        disabled={isPending || addMembers.length === 0}
        sx={{ minHeight: '35px', minWidth: '100px' }}
        onClick={handleSubmit}
        fullWidth
      >
        {isPending ? (
          <CircularProgress size={22} sx={{ color: 'white' }} />
        ) : (
          `ADD ${addMembers.length ? addMembers.length : ''} MEMBER(S)`
        )}
      </Button>
    </Box>
  );
};

export default AddTeamMember;
