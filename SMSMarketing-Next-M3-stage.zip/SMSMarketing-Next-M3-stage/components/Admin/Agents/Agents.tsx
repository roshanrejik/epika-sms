'use client';
import { Box, Button, InputAdornment } from '@mui/material';
import React, { useEffect, useMemo, useState } from 'react';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import SearchIcon from '@mui/icons-material/Search';
import UsersTable from '@/components/Tables/UsersTable';
import { useRouter } from 'next/navigation';
import { useUserList } from '@/hooks/api/user.hooks';
import debounce from 'lodash.debounce';
import GlassLoader from '@/components/common/Loader/GlassLoader';
import { StyledTextField } from '@/constants/key';
import styles from '../../../styles/admin.module.css';

const Agents = () => {
  const router = useRouter();
  const { mutate: listUsers } = useUserList();
  const [userTableData, setUserTableData] = useState([]); // agent table data
  const [totalCount, setTotalCount] = useState(0); // total agent count
  const [firstTimeFlag, setFirstTimeFlag] = useState(true); // to show loader on first render
  const [userListBody, setUserListBody] = useState({
    page: 0,
    limit: 10,
    search: '',
    roleId: '',
    teamId: '',
    active: '',
    sortField: '',
    sortOrder: -1,
  }); // agent list request body

  useEffect(() => {
    const userListRequestBody = {
      ...userListBody,
      page: userListBody.page + 1,
    };
    debouncedChangeHandler(userListRequestBody);
  }, [
    userListBody.page,
    userListBody.limit,
    userListBody.search,
    userListBody.roleId,
    userListBody.teamId,
    userListBody.active,
    userListBody.sortField,
    userListBody.sortOrder,
  ]); // change handler for agent list request body for filtering and pagination

  const debouncedChangeHandler = useMemo(
    () =>
      debounce(
        (userListRequestBody) =>
          listUsers(userListRequestBody, { onSuccess: onSuccess, onError: onError }),
        200,
      ),
    [],
  ); // debounced change handler for agent list
  const onSuccess = (res: any) => {
    setUserTableData(res.data.data);
    setTotalCount(res.data.totalCount);
    setFirstTimeFlag(false);
  };
  const onError = () => {
    setFirstTimeFlag(false);
  };
  const navToAddAgent = () => {
    router.push('/admin/agents/add-agent');
  }; // navigate to add agent page

  return (
    <Box>
      <Box className={styles.adminContainer}>
        <Button
          startIcon={<AddOutlinedIcon />}
          size="small"
          onClick={navToAddAgent}
          className={styles.adminButton}
        >
          ADD AGENT
        </Button>

        <StyledTextField
          id="outlined-basic"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
          placeholder="Search"
          value={userListBody.search}
          onChange={(e) => setUserListBody({ ...userListBody, search: e.target.value, page: 0 })}
          variant="outlined"
        />
      </Box>
      <Box sx={{ margin: '25px 25px 25px 25px' }}>
        {userTableData.length == 0 && firstTimeFlag ? (
          <GlassLoader />
        ) : (
          <UsersTable
            data={userTableData}
            setData={setUserTableData}
            userListBody={userListBody}
            setUserListBody={setUserListBody}
            totalCount={totalCount}
            setTotalCount={setTotalCount}
            debouncedChangeHandler={debouncedChangeHandler}
          />
        )}
      </Box>
    </Box>
  );
};

export default Agents;
