'use client';
import { AgentAddFormValuesProps, AgentEditFormValuesProps } from '@/@types/FormTypes';
import RHFSelect from '@/components/common/Select/RHFSelect';
import RHFPhoneNumber from '@/components/common/TextField/RHFPhoneNumber';
import RHFTextField from '@/components/common/TextField/RHFTextField';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import FormProvider from '@/context/FormProvider';
import { useGetRoleList } from '@/hooks/api/role.hooks';
import { useGetTeamList } from '@/hooks/api/team.hooks';
import { useGetUserDetails, useUserSave } from '@/hooks/api/user.hooks';
import { findById } from '@/utils/helpers';
import { AgentAddFormSchema, AgentEditFormSchema } from '@/validations/Auth/AgentSchema';
import { yupResolver } from '@hookform/resolvers/yup';
import { Box, Button, CircularProgress, Grid, IconButton, Typography } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useRouter, useSearchParams } from 'next/navigation';
import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import styles from '../../../styles/admin.module.css';
import { useDispatch, useSelector } from 'react-redux';
import { setUserData, user } from '@/lib/features/userSlice';
import ResetPassWord from '@/components/common/ModalDialog/ResetPassWord';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

const AddAgent = () => {
  const router = useRouter();
  type idType = string | undefined;
  const searchParams = useSearchParams();
  const dispatch = useDispatch();
  const id = searchParams.get('id');
  const { mutate: saveAgent, isPending } = useUserSave(); // api to save user
  const { data: roleList } = useGetRoleList(); // api to get role list
  const { data: teamList } = useGetTeamList(); // api to get team list
  const { data: userDetails, isSuccess } = useGetUserDetails(id);
  const { data: userData } = useSelector(user);
  const [showResetPasswordModel, setShowResetPasswordModel] = React.useState(false);
  const btnstyle = { margin: '20px 0', backgroundColor: 'var(--epika-primary-color)' };
  const { availableHeight } = useScreenHeight();
  const defaultValues = id
    ? {
        firstName: '',
        lastName: '',
        jobTitle: '',
        username: '',
        password: '',
        email: '',
        phone: '',
        role: '',
        teams: [],
      }
    : {
        _id: '',
        firstName: '',
        lastName: '',
        jobTitle: '',
        username: '',
        email: '',
        phone: '',
        role: '',
        teams: [],
      };

  const methods = useForm<
    idType extends string ? AgentEditFormValuesProps : AgentAddFormValuesProps,
    any
  >({
    resolver: yupResolver(id ? AgentEditFormSchema : AgentAddFormSchema),
    defaultValues,
  });

  useEffect(() => {
    if (isSuccess && userDetails && id) {
      const userDetailsData = userDetails?.data?.data;
      const formattedPhone = userDetailsData?.phone?.replace(
        /^(\d{3})(\d{3})(\d{4})$/,
        '+1 ($1) $2-$3',
      );
      const data = {
        _id: userDetailsData?._id,
        firstName: userDetailsData?.firstName,
        lastName: userDetailsData?.lastName,
        jobTitle: userDetailsData?.jobTitle,
        username: userDetailsData?.username,
        email: userDetailsData?.email,
        phone: formattedPhone,
        role: userDetailsData?.role?._id,
        teams: userDetailsData?.teams?.map((team: any) => team._id),
      };
      methods.reset(data);
    }
  }, [isSuccess, userDetails, id, methods]);

  const onSuccess = (id: string | null, name: string, res: any) => {
    if (id == userData._id) {
      dispatch(setUserData({ ...userData, name }));
    }
    router.push('/admin/agents/');
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
  };
  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  };

  const onSubmit = (data: any) => {
    const foundRole = findById(data.role, roleList?.data?.data);
    const payload = {
      ...data,
      teams: data.teams
        .map((teamId: any) => {
          const foundTeam = findById(teamId, teamList?.data?.data);
          return foundTeam ? { _id: foundTeam._id, name: foundTeam.name } : null;
        })
        .filter(Boolean),
      role: foundRole ? { _id: foundRole._id, name: foundRole.name } : null,
      phone: '+' + data.phone.replace(/\D/g, ''),
      password: id ? data.password : btoa(data.password),
    };
    const name = data.username || '';
    saveAgent(payload, { onSuccess: (res) => onSuccess(id, name, res), onError: onError });
  };
  const onSubmitPassword = (data: any) => {
    const payload = {
      _id: id,
      password: btoa(data.password),
    };
    saveAgent(payload, {
      onSuccess: (res) => {
        setShowResetPasswordModel(false);
        showToast('success', res.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-success',
        });
      },
      onError: onError,
    });
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={methods.handleSubmit((data) => onSubmit(data))}>
        <Box className={styles.adminAgentsContainer}>
          <Box>
            <IconButton onClick={() => router.back()}>
              <ArrowBackIcon />
            </IconButton>
            AGENTS PAGE
          </Box>
        </Box>
        <Grid
          container
          spacing={3}
          className={styles.adminAgentsTable}
          sx={{ overflow: 'scroll', height: availableHeight - 150 + 'px' }}
        >
          <Grid item xs={12} className={styles.adminAgentsTableHeader}>
            <Typography
              sx={{
                fontSize: 'var(--epika-primary-header-size)',
                fontWeight: 'bold',
              }}
            >
              {id ? 'Edit Agent' : 'Add New Agent'}
            </Typography>
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="firstName" label="First Name" type="capitalize" />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="lastName" label="Last Name" type="capitalize" />
          </Grid>

          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="jobTitle" label="Title" type="text" />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="username" label="Username" type="text" />
          </Grid>
          {!id && (
            <Grid item xs={12} md={6} lg={4}>
              <RHFTextField name="password" label="Password" type="password" />
            </Grid>
          )}

          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="email" label="Email" type="text" />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFPhoneNumber name="phone" label="Phone Number" type="text" />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFSelect
              name="role"
              label="Role"
              multiple={false}
              options={roleList?.data?.data || []}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFSelect
              name="teams"
              label="Teams"
              multiple={true}
              options={teamList?.data?.data || []}
            />
          </Grid>

          <Grid item xs={12} className={styles.adminButtonSpacing} gap={2}>
            {id && (
              <Button
                color="primary"
                variant="contained"
                style={{ ...btnstyle, backgroundColor: 'white' }}
                className={styles.adminButtonRevert}
                fullWidth
                onClick={() => setShowResetPasswordModel(true)}
              >
                Reset Password
              </Button>
            )}
            <Button
              type="submit"
              color="primary"
              variant="contained"
              style={btnstyle}
              className={styles.adminButtonBottom}
              disabled={isPending}
              fullWidth
            >
              {isPending ? <CircularProgress size={24} sx={{ color: 'white' }} /> : 'Submit'}
            </Button>
          </Grid>
        </Grid>
      </FormProvider>
      <ResetPassWord
        open={showResetPasswordModel}
        onClose={() => setShowResetPasswordModel(false)}
        title="Reset Password"
        actionButtonText={'Reset'}
        cancelText={'Cancel'}
        onClickOK={onSubmitPassword}
      />
    </>
  );
};

export default AddAgent;
