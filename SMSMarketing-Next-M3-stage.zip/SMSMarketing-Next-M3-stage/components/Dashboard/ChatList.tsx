import React, { useCallback, useEffect, useState, useRef } from 'react';
import { Paper, List, Typography } from '@mui/material';
import ChatItem from './ChatItem';
import useSocketEvent from '@/hooks/socket/useSocketEvent';
import {
  useGetConversationBySearchKeyValue,
  usePostConversationList,
  useUpdateConversation,
  usePostConversationSaveFind,
} from '@/hooks/api/conversation.hooks';
import { useGetUserListName } from '@/hooks/api/user.hooks';
import { usePostMessageList } from '@/hooks/api/message.hooks';
import { useTagList } from '@/hooks/api/tag.hooks';
import { useGetTeamList } from '@/hooks/api/team.hooks';
import { useRouter, useSearchParams } from 'next/navigation';
import { debounce } from 'lodash';
import { showToast } from '../common/Toast/defaultToastOptions';
import { formatPhoneNumber, userListForSelection } from '@/utils/helpers';
import ChatListHeader from './ChatListHeader';
import SearchSection from './SearchSection';
import ChatListTabs from './ChatListTabs';
import ChatListFooter from './ChatListFooter';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

const ChatList: React.FC<ChatListProps> = ({
  setConversationListData,
  conversationListData,
  setPostMessageListData,
  count,
  setCount,
  setTabValue,
  tabValue,
  setShowSearch,
  showSearch,
  chatListHeaderHeight,
  refetch,
}) => {
  const router = useRouter();
  const { search, setSearch } = useScreenHeight();
  const { mutate: conversationList, isPending } = usePostConversationList();
  const { mutate: updateConversation } = useUpdateConversation();
  const { data: searchFieldsData } = useGetConversationBySearchKeyValue();
  const { data: userList } = useGetUserListName('');
  const observerRef = useRef<IntersectionObserver | null>(null);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  const searchParams = useSearchParams();
  const conversationId = searchParams.get('cId');
  const { mutate: postMessageList } = usePostMessageList();
  const [phoneError, setPhoneError] = useState('');
  const { data: teamList } = useGetTeamList(); // Use the team list hook

  const [conversationListPayLoad, setConversationListPayLoad] = useState<ConversationPayload>({
    page: 1,
    limit: 20,
    type: 'all',
    search: {
      field: '',
      value: '',
    },
    sortField: 'updatedAt',
    sortOrder: -1, // Default sort order to new to old
  });

  const { data: tagsData, refetch: fetchTags, isLoading: isTagLoading } = useTagList('');
  const [searchPlaceholder, setSearchPlaceholder] = useState('Search conversations...');
  const [sortOrder, setSortOrder] = useState<number>(-1); // State for sort order
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [filterOpen, setFilterOpen] = useState<string>(''); // State to manage open filter section

  const debouncedSearch = useCallback(
    debounce((searchValue: { field: string; value: string }) => {
      setConversationListPayLoad((prev: any) => ({
        ...prev,
        search: searchValue,
        page: 1,
      }));
    }, 300),
    [],
  );

  useEffect(() => {
    if (conversationListPayLoad.page) {
      conversationList(conversationListPayLoad, {
        onSuccess: (res: any) => {
          setConversationListData((prev: any) =>
            conversationListPayLoad.page === 1 ? res.data.data : [...prev, ...res.data.data],
          );
          setCount({
            unassign: res.data.unassign,
            assign: res.data.assign,
            all: res.data.all,
          });
        },
        onError: (err: any) => {
          console.error(err);
        },
      });
    }
  }, [conversationListPayLoad]);

  const handleMessage = useCallback(
    (data: any) => {
      setConversationListData((prev: any) => {
        const filtered = prev.filter((ele: any) => ele._id !== data._id);
        if (filtered.length == 0) {
          setCount((prev: any) => ({
            ...prev,
            all:1,
            unassign: 1,
          }));
        }
        return [data, ...filtered];
      });
    },
    [],
  );

  useSocketEvent('newMSGConversation', handleMessage);

  const handleClickChatsDetails = (conversationId: any) => {
    setConversationListData((prev: any) =>
      prev.map((ele: any) => (ele._id === conversationId ? { ...ele, seen: true } : ele)),
    );
    setSearch(conversationListPayLoad.search);
    router.push(`/dashboard/?cId=${conversationId}`);
  };

  useEffect(() => {
    if (observerRef.current) observerRef.current.disconnect();

    observerRef.current = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        setConversationListPayLoad((prev) => ({
          ...prev,
          page: prev.page + 1,
        }));
      }
    });

    if (loadMoreRef.current) {
      observerRef.current.observe(loadMoreRef.current);
    }

    return () => observerRef.current && observerRef.current.disconnect();
  }, []);

  const handleSearchChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      let searchValue = e.target.value;
      const field = conversationListPayLoad?.search?.field;

      if (field === 'all' || field === 'phone') {
        // Check if the search value matches the phone number pattern
        if (/^\+?(\d[\d-() ]{7,}\d)$/.test(searchValue)) {
          // Format the phone number to remove non-numeric characters except +
          searchValue = searchValue.replace(/[^+\d]/g, '');
        }
      }
      setSearch({ ...search, value: searchValue });
      debouncedSearch({ ...search, value: searchValue });
    },
    [setSearch, search, debouncedSearch],
  );

  const handleClearSearch = () => {
    setSearch({ field: 'all', value: '' });
    debouncedSearch({ field: 'all', value: '' });
  };

  const handleSelectChange = (e: React.ChangeEvent<{ value: unknown }>) => {
    const selectedField = e.target.value as string;
    setSearch({ ...search, field: selectedField, value: '' });
    setConversationListPayLoad((prev) => ({
      ...prev,
      search: { ...prev.search, field: selectedField },
      page: 1,
    }));
    const selectedFieldVisible = searchFieldsData?.data?.data.find(
      (field: any) => field.field === selectedField,
    )?.visible;
    setSearchPlaceholder(
      `Search ${selectedField == 'customProperties' ? 'key : value' : selectedFieldVisible}`,
    );
    if (selectedField === 'tag') {
      fetchTags();
    }
  };

  const handlePhoneNumberChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setPhoneNumber(event.target.value);
    setPhoneError('');
  };

  const handleTagSelectChange = (e: React.ChangeEvent<{ value: unknown }>) => {
    const selectedTagId = e.target.value as string;
    setConversationListPayLoad((prev) => ({
      ...prev,
      search: { ...prev.search, value: selectedTagId },
      page: 1,
    }));
  };

  const [selectedConversations, setSelectedConversations] = useState<any>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [actionMenuAnchor, setActionMenuAnchor] = useState<null | HTMLElement>(null);
  const [conversationActionsOpen, setConversationActionsOpen] = useState(false);
  const [assignActionsOpen, setAssignActionsOpen] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const { mutate: postConversationSaveFind } = usePostConversationSaveFind();

  const handleSelectAll = (event: any) => {
    setSelectAll(event.target.checked);
    if (event.target.checked) {
      setSelectedConversations(conversationListData.map((item: any) => item._id));
    } else {
      setSelectedConversations([]);
    }
  };

  const handleSelectConversation = (id: any) => {
    setSelectedConversations((prev) => {
      const updatedSelections = prev.includes(id)
        ? prev.filter((cid: any) => cid !== id)
        : [...prev, id];

      // Check if all conversations are selected
      if (updatedSelections.length === conversationListData.length) {
        setSelectAll(true);
      } else {
        setSelectAll(false);
      }

      return updatedSelections;
    });
  };

  const handleActionClick = (event: any) => {
    setActionMenuAnchor(event.currentTarget);
  };

  const handleActionClose = () => {
    setActionMenuAnchor(null);
    setAssignActionsOpen(false);
    setConversationActionsOpen(false);
  };

  const handleAssignClick = () => {};

  const handleAssignClose = () => {};

  const handleAction = (action: string) => {
    if (action === 'assign') {
      handleAssignClick(actionMenuAnchor);
    } else {
      updateConversation(
        {
          conversationIds: selectedConversations,
          action: action,
        },
        {
          onSuccess: () => {
            setSelectedConversations([]);
            handleActionClose();
            showToast('success', 'Conversation ' + action + ' successfully', {
              autoClose: 2000,
              position: 'bottom-right',
              className: 'custom-toast-success',
            });
            reloadConversationList();
            setSelectAll(false);
          },
          onError: (err: any) => {
            console.error(err);
          },
        },
      );
    }
  };

  const handleAssignToUser = (user: any) => {
    updateConversation(
      {
        conversationIds: selectedConversations,
        action: 'assign',
        assignedTo: user,
      },
      {
        onSuccess: () => {
          setSelectedConversations([]);
          handleAssignClose();
          handleActionClose();
          reloadConversationList();
        },
        onError: (err: any) => {
          console.error(err);
        },
      },
    );
  };

  const handleFilterChange = (event: React.ChangeEvent<{ value: unknown }>, filterType: string) => {
    const selectedFilter = event.target.value as string;
    setFilterOpen('');
    setConversationListPayLoad((prev) => {
      let newPayload = { ...prev, page: 1 };
      if (filterType === 'status') {
        newPayload = { ...newPayload, status: selectedFilter };
      } else if (filterType === 'assignedToId') {
        newPayload = { ...newPayload, assignedToId: selectedFilter };
      } else if (filterType === 'teamId') {
        newPayload = { ...newPayload, teamId: selectedFilter };
      }
      return newPayload;
    });
  };

  const reloadConversationList = () => {
    const customerListRequestBody = {
      ...conversationListPayLoad,
      page: 1, // Reset to the first page
    };
    if (conversationListPayLoad.page)
      conversationList(customerListRequestBody, {
        onSuccess: (res) => {
          setConversationListData(res.data.data.reverse());
          refetch();
        },
      });
    if (conversationId) {
      postMessageList(
        { conversationId, page: 1, limit: 20 },
        {
          onSuccess: (res) => setPostMessageListData(res.data.data),
          onError: (err) => console.error('Error fetching messages:', err),
        },
      );
    }
  };

  const handleClose = () => {
    setAnchorEl(null);
    setPhoneNumber('');
  };

  const addCustomModel = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const transformedUserList = userListForSelection(userList?.data?.data);

  const handleSortOrderChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const newSortOrder = event.target.value as number;
    setSortOrder(newSortOrder);
    setConversationListPayLoad((prev) => ({
      ...prev,
      sortOrder: newSortOrder,
      page: 1,
    }));
  };

  const validatePhoneNumber = (phone: string) => {
    const formattedPhone = formatPhoneNumber(phone);
    const phoneRegex = /^\+1\s\(\d{3}\)\s\d{3}-\d{4}$/;
    if (!phone) {
      setPhoneError('Phone number is required');
      return false;
    } else if (!phoneRegex.test(formattedPhone)) {
      setPhoneError('Invalid phone number format');
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (validatePhoneNumber(phoneNumber)) {
      postConversationSaveFind(
        { customerPhoneNumber: '+' + phoneNumber.replace(/\D/g, '') },
        {
          onSuccess: (res) => {
            router.push('/dashboard/?cId=' + res.data.conversationId);
            handleClose();
            conversationList(
              {
                page: '1',
                limit: 10,
                type: 'all',
                search: '',
                sortField: '',
                sortOrder: '',
              },
              {
                onSuccess: (res: any) => {
                  setConversationListData(res.data.data);
                  setTabValue(2);
                  setCount({
                    unassign: res.data.unassign,
                    assign: res.data.assign,
                    all: res.data.all,
                  });
                },
                onError: () => {},
              },
            );
          },
          onError: (err: any) => {
            showToast('error', err.response.data.message, {
              autoClose: 2000,
              position: 'bottom-right',
              className: 'custom-toast-error',
            });
          },
        },
      );
    }
  };

  const handleFilterOpen = (filter: string) => {
    setFilterOpen(filterOpen === filter ? '' : filter);
  };

  const handleFilterCancel = () => {
    setFilterOpen('');
    setConversationListPayLoad((prev) => ({
      ...prev,
      status: undefined,
      assignedToId: undefined,
      teamId: undefined,
      page: 1,
    }));
    reloadConversationList();
  };

  const headerRef = useRef<HTMLDivElement>(null);
  const tabsRef = useRef<HTMLDivElement>(null);
  const searchSectionRef = useRef<HTMLDivElement>(null);

  const calculateAvailableHeight = () => {
    const headerHeight = headerRef.current?.clientHeight || 0;
    const tabsHeight = tabsRef.current?.clientHeight || 0;
    const searchSectionHeight = searchSectionRef.current?.clientHeight || 0;
    return `calc(100vh - ${headerHeight + tabsHeight + searchSectionHeight + 300}px)`;
  };

  return (
    <Paper
      sx={{
        borderRadius: '8px 0px 0px 8px !important',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div ref={headerRef}>
        <ChatListHeader
          isPending={isPending}
          phoneNumber={phoneNumber}
          phoneError={phoneError}
          anchorEl={anchorEl}
          showSearch={showSearch}
          handlePhoneNumberChange={handlePhoneNumberChange}
          handleSubmit={handleSubmit}
          handleClose={handleClose}
          addCustomModel={addCustomModel}
          setShowSearch={setShowSearch}
          setConversationListPayLoad={setConversationListPayLoad}
        />
      </div>
      {showSearch && (
        <div ref={searchSectionRef}>
          <SearchSection
            searchFieldsData={searchFieldsData}
            conversationListPayLoad={conversationListPayLoad}
            searchPlaceholder={searchPlaceholder}
            searchValue={search?.value}
            isTagLoading={isTagLoading}
            tagsData={tagsData}
            fetchTags={fetchTags}
            handleSelectChange={handleSelectChange}
            handleSearchChange={handleSearchChange}
            handleClearSearch={handleClearSearch}
            handleTagSelectChange={handleTagSelectChange}
          />
        </div>
      )}
      <div ref={tabsRef}>
        <ChatListTabs
          count={count}
          tabValue={tabValue}
          setTabValue={setTabValue}
          setConversationListData={setConversationListData}
          setConversationListPayLoad={setConversationListPayLoad}
        />
      </div>
      <ChatListFooter
        tabValue={tabValue}
        count={count}
        selectAll={selectAll}
        selectedConversations={selectedConversations}
        sortOrder={sortOrder}
        transformedUserList={transformedUserList}
        teamList={teamList}
        filterOpen={filterOpen}
        anchorEl={anchorEl}
        actionMenuAnchor={actionMenuAnchor}
        setConversationActionsOpen={setConversationActionsOpen}
        conversationActionsOpen={conversationActionsOpen}
        setAssignActionsOpen={setAssignActionsOpen}
        assignActionsOpen={assignActionsOpen}
        chatListHeaderHeight={chatListHeaderHeight}
        handleSelectAll={handleSelectAll}
        handleSortOrderChange={handleSortOrderChange}
        handleFilterOpen={handleFilterOpen}
        handleFilterChange={handleFilterChange}
        handleActionClick={handleActionClick}
        handleActionClose={handleActionClose}
        handleAction={handleAction}
        handleAssignToUser={handleAssignToUser}
        handleAssignClose={handleAssignClose}
        handleFilterCancel={handleFilterCancel}
        conversationListPayLoad={conversationListPayLoad}
      />

      {(tabValue === 0 && count.unassign > 0) ||
      (tabValue === 1 && count.assign > 0) ||
      (tabValue === 2 && count.all > 0) ? (
        conversationListData?.length > 0 ? (
          <List sx={{ overflowY: 'auto', height: calculateAvailableHeight(), flexGrow: 1 }}>
            {conversationListData.map((ele: any, index: any) => (
              <ChatItem
                key={index}
                {...ele}
                handleClickChatsDetails={handleClickChatsDetails}
                isSelected={selectedConversations.includes(ele._id)}
                handleSelectConversation={handleSelectConversation}
              />
            ))}
            <div ref={loadMoreRef} />
          </List>
        ) : (
          <Typography
            variant="h6"
            color="textSecondary"
            sx={{
              overflow: 'auto',
              height: chatListHeaderHeight + 60 + 'px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            No More Conversation
          </Typography>
        )
      ) : null}
    </Paper>
  );
};

export default ChatList;
