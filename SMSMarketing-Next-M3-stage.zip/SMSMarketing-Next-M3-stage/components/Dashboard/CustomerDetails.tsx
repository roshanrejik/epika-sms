import React, { useState, useCallback, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Switch,
  Grid,
  Button,
  Modal,
  IconButton,
  Avatar,
} from '@mui/material';
import { capitalizeFirstChar, formatPhoneNumber } from '@/utils/helpers';
import TagLine1 from '@/assets/avator/woman.png';
import TagLine2 from '@/assets/avator/doctor.png';
import TagLine3 from '@/assets/avator/plumber.png';
import TagLine4 from '@/assets/avator/police-officer.png';
import TagLine5 from '@/assets/avator/businessman.png';
import TagLine6 from '@/assets/avator/buddhist-monk.png';
import TagLine7 from '@/assets/avator/old-man.png';
import TagLine8 from '@/assets/avator/sportsman.png';
import { Edit, Delete, Check, Close } from '@mui/icons-material';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import { usePostCustomerSave } from '@/hooks/api/customer.hooks';
import { usePostMessageList } from '@/hooks/api/message.hooks';
import useSocketEvent from '@/hooks/socket/useSocketEvent';
import { socketKeys } from '@/constants/socket-keys';
import { useRouter } from 'next/navigation';
import { showToast } from '../common/Toast/defaultToastOptions';
import { StyledTextField } from '@/constants/key';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import CampaignActions from './CampaignActions';

const AVATARS = [TagLine1, TagLine2, TagLine4, TagLine3, TagLine6, TagLine5, TagLine7, TagLine8];
const EXCLUDED_FIELDS = [
  '_id',
  'createdAt',
  'updatedAt',
  'firstName',
  'lastName',
  'active',
  'isDelete',
  'unsubscribedAt',
  'image',
  'utcOffset',
];
const ORDERED_FIELDS = ['phone', 'location', 'timezone', 'subscribed', 'email', 'zipcode'];
interface Customer {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  subscribed?: boolean;
  timezone?: string;
  initialEntryPoint?: string;
  customProperties?: { [key: string]: any }; // Allow any other properties in customProperties
  [key: string]: any; // Allow any other properties
}

interface CustomerDetailsProps {
  customer: Customer;
  refetch: () => void;
  conversationId: string;
  setPostMessageListData: any;
  search: {
    field: string;
    value: string;
  };
  setIsSubscribedLoading: any;
}

const AvatarSelectionModal: React.FC<{
  open: boolean;
  onClose: () => void;
  onSelect: (avatar: string) => void;
}> = ({ open, onClose, onSelect }) => (
  <Modal open={open} onClose={onClose}>
    <Box
      sx={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 350,
        bgcolor: 'background.paper',
        borderRadius: '10px',
        boxShadow: 24,
        p: 4,
      }}
    >
      <Typography variant="h6" component="h2">
        Select Avatar
      </Typography>
      <Grid container spacing={2} sx={{ mt: 2 }}>
        {AVATARS.map((av, index) => (
          <Grid item xs={3} key={index}>
            <Avatar
              src={av.src}
              sx={{ width: 60, height: 60, cursor: 'pointer' }}
              onClick={() => onSelect(av.src)}
            />
          </Grid>
        ))}
      </Grid>
      <Box display="flex" justifyContent="flex-end" mt={2}>
        <Button onClick={onClose}>Cancel</Button>
      </Box>
    </Box>
  </Modal>
);

const CustomerDetails: React.FC<CustomerDetailsProps> = ({
  customer,
  search,
  refetch,
  conversationId,
  setPostMessageListData,
  setIsSubscribedLoading,
}) => {
  const router = useRouter();
  const [customerData, setCustomerData] = useState<Customer | null>(customer);
  const [avatar, setAvatar] = useState<string>(customer?.image || 'https://via.placeholder.com/80');
  const [open, setOpen] = useState<boolean>(false);
  const [isAdding, setIsAdding] = useState<boolean>(false);
  const [newKey, setNewKey] = useState<string>('');
  const [newValue, setNewValue] = useState<string>('');
  const [editKey, setEditKey] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [editOriginalKey, setEditOriginalKey] = useState<string | null>(null);
  const { mutate: postCustomer } = usePostCustomerSave();
  const { mutate: postMessageList } = usePostMessageList();
  const { availableHeight } = useScreenHeight();

  const messageEvent = `${socketKeys.conversationId}:${conversationId}`;
  console.log(customer, 'customer');
  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    flag: boolean;
    id: string | null;
  }>({ flag: false, id: null }); // State to control the deletion modal

  useEffect(() => {
    setCustomerData(customer);
    setAvatar(
      customer?.image ||
        'https://media.istockphoto.com/id/1223671392/vector/default-profile-picture-avatar-photo-placeholder-vector-illustration.jpg?s=612x612&w=0&k=20&c=s0aTdmT5aU6b8ot7VKm11DeID6NctRCpB755rA1BIP0=',
    );
  }, [customer]);

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleAvatarSelect = (selectedAvatar: string) => {
    setAvatar(selectedAvatar);
    postCustomer({ ...customer, image: selectedAvatar, conversationId });
    handleClose();
  };

  const handleAddProperty = () => {
    setIsAdding(true);
  };

  const handleToggleProperty = (key: string, value: any) => {
    setCustomerData((prevData) => {
      if (prevData) {
        return {
          ...prevData,
          [key]: !value,
        };
      }
      return prevData;
    });
    setIsSubscribedLoading(true);
    postCustomer(
      {
        ...customerData,
        conversationId,
        [key]: !value,
      },
      {
        onSuccess: () => {
          refetch();
          const postMessageListPayload = {
            conversationId,
            page: 1,
            limit: 20,
          };
          postMessageList(postMessageListPayload, {
            onSuccess: (res) => {
              setPostMessageListData(() => [...res.data.data]);
              setIsSubscribedLoading(false);
              refetch();
            },
            onError: (err) => {
              console.error('Error fetching messages:', err);
            },
          });
        },
        onError: (err: any) => {
          showToast('error', err.response.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
          setIsSubscribedLoading(false);
          setCustomerData((prevData) => {
            if (prevData) {
              return {
                ...prevData,
                subscribed: false,
              };
            }
            return prevData;
          });
        },
      },
    );
  };

  const handleSaveNewProperty = () => {
    if (newKey && newValue) {
      setCustomerData((prevData) => {
        if (prevData) {
          return {
            ...prevData,
            customProperties: {
              ...prevData.customProperties,
              [newKey]: newValue,
            },
          };
        }
        return null;
      });
      setNewKey('');
      setNewValue('');
      setIsAdding(false);
      postCustomer({
        ...customerData,
        conversationId,
        customProperties: { ...customerData?.customProperties, [newKey]: newValue },
      });
    }
  };

  const handleMessage = useCallback((data: any) => {
    if (data.actionStatus === 'subscribed') {
      setCustomerData((prevData) => {
        if (prevData) {
          return {
            ...prevData,
            subscribed: true,
          };
        }
        return prevData;
      });
      refetch();
    } else if (data.actionStatus === 'unsubscribed') {
      setCustomerData((prevData) => {
        if (prevData) {
          return {
            ...prevData,
            subscribed: false,
          };
        }
        return prevData;
      });
      refetch();
    } else if (data.actionStatus === 'assigned') {
      setCustomerData((prevData) => {
        if (prevData) {
          return {
            ...prevData,
          };
        }
        return prevData;
      });
      refetch();
    }
  }, []);

  useSocketEvent(messageEvent, handleMessage);

  const handleEditProperty = (key: string, value: any) => {
    setEditOriginalKey(key);
    setEditKey(key);
    setEditValue(value);
  };

  const handleSaveEditProperty = () => {
    if (editKey && editOriginalKey) {
      setCustomerData((prevData) => {
        if (prevData) {
          const customProperties = { ...prevData.customProperties };
          delete customProperties[editOriginalKey];
          customProperties[editKey] = editValue;
          const updatedData = {
            ...prevData,
            customProperties,
          };
          postCustomer({
            ...updatedData,
            conversationId,
          });
          return updatedData;
        }
        return null;
      });
      setEditKey(null);
      setEditValue('');
      setEditOriginalKey(null);
    }
  };

  const handleDeleteProperty = (key: string) => {
    setCustomerData((prevData) => {
      if (prevData) {
        const customProperties = { ...prevData.customProperties };
        delete customProperties[key];
        const updatedData = {
          ...prevData,
          customProperties,
        };
        postCustomer({
          ...updatedData,
          conversationId,
        });
        return updatedData;
      }
      return null;
    });
  };

  const handleDeletePropertyWithConfirmation = (key: string) => {
    setShowdeleteModelFlag({ flag: true, id: key });
  };

  const deleteRole = () => {
    if (showdeleteModelFlag.id) {
      handleDeleteProperty(showdeleteModelFlag.id);
    }
    setShowdeleteModelFlag({ flag: false, id: null });
  };
  const escapeRegExp = (string: string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
  };
  const renderHighlightedText = (text: string, highlight: string) => {
    if (!highlight) {
      return text; // If highlight is not provided, return the original text
    }

    const escapedHighlight = escapeRegExp(highlight);
    const parts = text.split(new RegExp(`(${escapedHighlight})`, 'gi'));
    return (
      <span>
        {parts.map((part, index) =>
          part.toLowerCase() === highlight.toLowerCase() ? (
            <span key={index} style={{ background: 'yellow', color: 'black' }}>
              {part}
            </span>
          ) : (
            part
          ),
        )}
      </span>
    );
  };

  return (
    <Paper
      sx={{
        borderRadius: '0px 8px 8px 0px',
        padding: 2,
        height: availableHeight - 30 + 'px',
        overflowY: 'scroll',
      }}
    >
      <div style={{ overflow: 'scroll' }}>
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'end',
            alignItems: 'baseline',
          }}
        >
          <Typography
            onClick={() => router.push(`/customers/add-customer/?id=${customer._id || ''}`)}
            sx={{ cursor: 'pointer' }}
          >
            Edit
          </Typography>
        </Box>
        <Box display="flex" flexDirection="column" alignItems="center" mb={2}>
          <Avatar src={avatar} sx={{ width: 80, height: 80, mb: 2 }} onClick={handleOpen} />
          {customer?.firstName && (
            <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
              {search && (search.field === 'all' || search.field === 'name') && search.value ? (
                <>
                  {renderHighlightedText(
                    `${capitalizeFirstChar(customer.firstName)} ${customer.lastName}`,
                    search.value,
                  )}
                </>
              ) : (
                <>
                  {capitalizeFirstChar(customer.firstName)} {customer.lastName}
                </>
              )}
            </Typography>
          )}
          <AvatarSelectionModal open={open} onClose={handleClose} onSelect={handleAvatarSelect} />
        </Box>

        {customerData && (
          <Box>
            <Grid container spacing={1} direction="column">
              {Object.entries(customerData)
                .filter(
                  ([key, value]) => !EXCLUDED_FIELDS.includes(key) && typeof value !== 'object',
                )
                .sort(([keyA], [keyB]) => {
                  const indexA = ORDERED_FIELDS.indexOf(keyA);
                  const indexB = ORDERED_FIELDS.indexOf(keyB);
                  return (
                    (indexA === -1 ? ORDERED_FIELDS.length : indexA) -
                    (indexB === -1 ? ORDERED_FIELDS.length : indexB)
                  );
                })
                .map(([key, value]) => (
                  <Grid item key={key}>
                    <Box display="flex" flexDirection="column">
                      <Typography variant="body2" sx={{ minWidth: 120 }}>
                        {`${key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}`}
                        {key === 'subscribed' ? '?' : null}
                      </Typography>
                      {key === 'subscribed' || key === 'active' ? (
                        <Switch
                          checked={!!value}
                          sx={{
                            '& .MuiSwitch-switchBase.Mui-checked': {
                              color: 'var(--epika-primary-color)',
                            },
                            '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                              backgroundColor: 'var(--epika-primary-color)',
                            },
                          }}
                          onChange={() => handleToggleProperty(key, value)}
                        />
                      ) : (
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>
                          {search &&
                          (search.field === 'all' ||
                            (search.field !== 'messageContent' && search.field !== 'tags')) &&
                          search.value
                            ? renderHighlightedText(
                                key === 'phone' ? formatPhoneNumber(value) : value,
                                search.value,
                              )
                            : key === 'phone'
                              ? formatPhoneNumber(value)
                              : value}
                        </Typography>
                      )}
                    </Box>
                  </Grid>
                ))}
              <CampaignActions
                customerPhoneNumber={customer?.phone}
                setPostMessageListData={setPostMessageListData}
              />
              {Object.entries(customerData.customProperties || {})
                .filter(
                  ([key, value]: any) =>
                    !EXCLUDED_FIELDS.includes(key) && typeof value !== 'object',
                )
                .map(([key, value]: any) => {
                  let searchKey = null;
                  let searchValue = null;

                  if (search && search.value && search.value.includes(':')) {
                    [searchKey, searchValue] = search.value.split(':').map((str) => str.trim());
                  }

                  return (
                    <Grid item key={key}>
                      <Box display="flex" flexDirection="column">
                        {editOriginalKey === key ? (
                          <>
                            <StyledTextField
                              value={editKey}
                              onChange={(e) => setEditKey(e.target.value)}
                              size="small"
                            />
                            <StyledTextField
                              value={editValue}
                              onChange={(e) => setEditValue(e.target.value)}
                              size="small"
                              sx={{ mt: 1 }}
                            />
                            <Box display="flex" flexDirection="row-reverse" sx={{ mt: 1 }}>
                              <IconButton
                                onClick={() => {
                                  setEditOriginalKey(null);
                                  setEditKey(null);
                                  setEditValue('');
                                }}
                              >
                                <Close />
                              </IconButton>
                              <IconButton onClick={handleSaveEditProperty}>
                                <Check />
                              </IconButton>
                            </Box>
                          </>
                        ) : (
                          <>
                            <Typography variant="body2" sx={{ minWidth: 120 }}>
                              {searchKey && searchValue
                                ? renderHighlightedText(key, searchKey)
                                : search &&
                                    (search.field === 'all' ||
                                      search.field === 'customProperties') &&
                                    search.value
                                  ? renderHighlightedText(key, search.value)
                                  : key}
                            </Typography>
                            <Box
                              display="flex"
                              flexDirection="row"
                              alignItems="center"
                              justifyContent="space-between"
                            >
                              <Typography variant="body2" sx={{ flexGrow: 1, fontWeight: 700 }}>
                                {searchKey && searchValue
                                  ? renderHighlightedText(value, searchValue)
                                  : search &&
                                      (search.field === 'all' ||
                                        search.field !== 'messageContent') &&
                                      search.value
                                    ? renderHighlightedText(value, search.value)
                                    : value}
                              </Typography>
                              <Box>
                                <IconButton
                                  onClick={() => handleEditProperty(key, value)}
                                  style={{ padding: 0, fontSize: '1rem' }}
                                >
                                  <Edit />
                                </IconButton>
                                <IconButton
                                  onClick={() => handleDeletePropertyWithConfirmation(key)}
                                  style={{ padding: 0, fontSize: '1rem' }}
                                >
                                  <Delete sx={{ padding: 0 }} />
                                </IconButton>
                              </Box>
                            </Box>
                          </>
                        )}
                      </Box>
                    </Grid>
                  );
                })}
            </Grid>
          </Box>
        )}
      </div>
      <Box sx={{ position: 'relative', bottom: 0 }}>
        {isAdding ? (
          <Box display="flex" flexDirection="column" gap={1}>
            <StyledTextField
              placeholder="Key"
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              size="small"
            />
            <StyledTextField
              placeholder="Value"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              size="small"
            />
            <Box display="flex" flexDirection="row-reverse" sx={{ mt: 1 }}>
              <IconButton
                onClick={() => {
                  setNewKey('');
                  setNewValue('');
                  setIsAdding(false);
                }}
              >
                <Close />
              </IconButton>
              <IconButton onClick={handleSaveNewProperty}>
                <Check />
              </IconButton>
            </Box>
          </Box>
        ) : (
          <Button
            size="large"
            onClick={handleAddProperty}
            sx={{
              color: 'primary.contrastText',
              backgroundColor: 'var(--epika-primary-color)',
              borderRadius: '30px',
              minWidth: '150px',
              marginTop: '30px',
              '&:hover': {
                bgcolor: 'var(--epika-primary-color)',
                color: 'white',
              },
            }}
          >
            Add Property
          </Button>
        )}
      </Box>
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Delete"
        dialogType={'delete'}
        contentText={'Are you sure you want to delete the property?'}
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
        onClickOK={() => deleteRole()}
      />
    </Paper>
  );
};

export default CustomerDetails;
