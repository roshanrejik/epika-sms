import React from 'react';
import { Box, IconButton, Popover, Tooltip } from '@mui/material';
import AddReactionIcon from '@mui/icons-material/AddReaction';
import DifferenceIcon from '@mui/icons-material/Difference';
import EmojiPicker from 'emoji-picker-react';
import { StyledTextField } from '@/constants/key';
import CannedResponses from '../Canned/CannedResponsePopup';
import SendIcon from '@mui/icons-material/Send';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
interface ChatInputProps {
  typeMsg: string;
  setTypeMsg: React.Dispatch<React.SetStateAction<string>>;
  handleEmojiClick: (event: React.MouseEvent<HTMLElement>) => void;
  handleCannedClick: (event: React.MouseEvent<HTMLElement>) => void;
  showEmoji: boolean;
  anchorElEmoji: HTMLElement | null;
  onEmojiClick: (emojiData: any) => void;
  showCanned: boolean;
  anchorElCanned: HTMLElement | null;
  setCannedListBody: any;
  cannedListBody: any;
  customer: any;
  postCannedMessageListData: any;
  sendMsg: () => void;
  disabled: boolean;
  againstCompliance: boolean;
  complianceMessage: string;
}

const ChatInput: React.FC<ChatInputProps> = ({
  typeMsg,
  setTypeMsg,
  handleEmojiClick,
  handleCannedClick,
  showEmoji,
  anchorElEmoji,
  onEmojiClick,
  showCanned,
  anchorElCanned,
  setCannedListBody,
  cannedListBody,
  customer,
  postCannedMessageListData,
  sendMsg,
  disabled,
  againstCompliance,
  complianceMessage,
}) => {
  const handleKeyPress = (event: any) => {
    if (event.key === 'Enter') {
      sendMsg();
    }
  };
  const handleCustomKeyPress = (event: any) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      // Prevent the default behavior of the Enter key
      event.preventDefault();
      // Call your custom handleKeyPress function if you have additional actions
      handleKeyPress(event);
    }
  };
  return (
    <Box mt={2} display="flex" sx={{ position: 'relative', bottom: 0 }} alignItems="center">
      <StyledTextField
        variant="outlined"
        fullWidth
        placeholder="Type a message"
        value={typeMsg}
        multiline
        maxRows={4}
        onKeyPress={handleCustomKeyPress}
        onChange={(e) => setTypeMsg(e.target.value)}
        disabled={disabled}
      />
      <Popover
        open={showEmoji}
        anchorEl={anchorElEmoji}
        onClose={handleEmojiClick}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
      >
        <EmojiPicker onEmojiClick={onEmojiClick} />
      </Popover>
      <Popover
        open={showCanned}
        anchorEl={anchorElCanned}
        onClose={handleCannedClick}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
      >
        <Box>
          <CannedResponses
            setCannedListBody={setCannedListBody}
            cannedListBody={cannedListBody}
            customer={customer}
            postCannedMessageListData={postCannedMessageListData}
            handleMessage={setTypeMsg}
            handleCannedClick={handleCannedClick}
          />
        </Box>
      </Popover>
      <IconButton onClick={handleCannedClick} disabled={disabled}>
        <DifferenceIcon />
      </IconButton>
      <IconButton onClick={handleEmojiClick} disabled={disabled}>
        <AddReactionIcon />
      </IconButton>
      <IconButton style={{ margin: '0px 10px' }} onClick={sendMsg} disabled={disabled}>
        <Tooltip
          title={complianceMessage}
          sx={{
            '& .MuiTooltip-tooltip': {
              backgroundColor: 'red',
              color: 'white',
            },
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <SendIcon sx={{ color: againstCompliance ? 'red' : '' }} />
            {againstCompliance ? (
              <PriorityHighIcon sx={{ color: 'red', margin: ' 0 0px 20px 0' }} />
            ) : null}
          </div>
        </Tooltip>
      </IconButton>
    </Box>
  );
};

export default ChatInput;
