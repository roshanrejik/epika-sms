import React, { useState } from 'react';
import {
  Box,
  CircularProgress,
  Typography,
  IconButton,
  Chip,
  Tooltip,
  Menu,
  Grid,
  Button,
} from '@mui/material';
import TimerIcon from '@mui/icons-material/Timer';
import {
  capitalizeFirstChar,
  convertUTCToLocal,
  formatUSDate,
  formatUSDateTimeZone,
} from '@/utils/helpers';
import { MessageData } from './ChatDetails.types';
import TagPopup from './TagPopup';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import CloseIcon from '@mui/icons-material/Close';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import DoneIcon from '@mui/icons-material/Done';
import ReplayIcon from '@mui/icons-material/Replay';
import { usePutupdateMessage, useDeleteMessage } from '@/hooks/api/message.hooks';
import { showToast } from '../common/Toast/defaultToastOptions';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import { useSelector } from 'react-redux';
import { user } from '@/lib/features/userSlice';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import EventIcon from '@mui/icons-material/Event';
import CancelIcon from '@mui/icons-material/Cancel';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

const ChatMessages: React.FC<ChatMessagesProps> = ({
  loading,
  page,
  postMessageListData,
  bufferedMessages,
  renderBufferedMessages,
  messageEndRef,
  messageContainerRef,
  messageRefs,
  handleScroll,
  putupdateMessageData,
  setPostMessageListData,
  search,
  customer,
  conversationId,
  postMessageList,
}) => {
  const { data: userData } = useSelector(user);
  const [selectedMessage, setSelectedMessage] = useState<any>(null);
  const [isTagPopupOpen, setIsTagPopupOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [tagToRemove, setTagToRemove] = useState<any>(null);
  const [isDeleteConfirmationOpen, setIsDeleteConfirmationOpen] = useState(false);
  const [isTagRemoveConfirmationOpen, setIsTagRemoveConfirmationOpen] = useState(false);
  const [menuAnchorEl, setMenuAnchorEl] = useState<null | HTMLElement>(null);
  const [actionMenuAnchorEl, setActionMenuAnchorEl] = useState<null | HTMLElement>(null); // Add this line

  const [isCancelConfirmationOpen, setIsCancelConfirmationOpen] = useState(false);
  const [isSendNowConfirmationOpen, setIsSendNowConfirmationOpen] = useState(false);
  const [actionMessage, setActionMessage] = useState<MessageData | null>(null);

  const { mutate: retryUpdateMessage } = usePutupdateMessage();
  const { mutate: deleteMessage } = useDeleteMessage();
  const messagesToRender = renderBufferedMessages
    ? [...bufferedMessages, ...postMessageListData]
    : postMessageListData;

  const handleTagClick = (event: React.MouseEvent<HTMLElement>, message: MessageData) => {
    setSelectedMessage(message);
    setAnchorEl(event.currentTarget);
    setIsTagPopupOpen(true);
  };

  const handleTagPopupClose = () => {
    setIsTagPopupOpen(false);
    setSelectedMessage(null);
    setAnchorEl(null);
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>, message: MessageData) => {
    setSelectedMessage(message);
    setMenuAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setMenuAnchorEl(null);
  };

  const handleDeleteMessage = () => {
    if (selectedMessage) {
      const userId = userData._id;
      const userRole = userData.role?.name?.toLowerCase();

      if (selectedMessage.createdBy._id === userId || userRole === 'admin') {
        deleteMessage(
          { _id: [selectedMessage._id] },
          {
            onSuccess: () => {
              setPostMessageListData((prev: any) => {
                const updatedList = prev.filter((item: any) => item._id !== selectedMessage._id);
                return updatedList;
              });
              showToast('success', 'Message deleted successfully', {
                autoClose: 2000,
                position: 'bottom-right',
                className: 'custom-toast-success',
              });
            },
            onError: (err: any) => {
              showToast('error', err.response.data.message, {
                autoClose: 2000,
                position: 'bottom-right',
                className: 'custom-toast-error',
              });
            },
          },
        );
      } else {
        showToast('error', 'You do not have permission to delete this message', {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      }
    }
    handleMenuClose();
    setIsDeleteConfirmationOpen(false);
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  };

  const handleSelectedTag = (tag: any) => {
    delete tag['createdAt'];
    delete tag['updatedAt'];

    const updatedMessageTagsSet = new Set(selectedMessage.messageTags.map((item: any) => item._id));
    updatedMessageTagsSet.add(tag._id);

    const updatedMessageTags = Array.from(updatedMessageTagsSet).map((_id) => {
      return selectedMessage.messageTags.find((item: any) => item._id === _id) || tag;
    });

    putupdateMessageData(
      {
        _id: selectedMessage._id,
        messageTags: updatedMessageTags,
      },
      {
        onSuccess: () => {
          setPostMessageListData((prev: any) => {
            const updatedList = Array.isArray(prev)
              ? prev.map((item: any) =>
                  item._id === selectedMessage._id
                    ? { ...item, messageTags: updatedMessageTags }
                    : item,
                )
              : [];
            return updatedList;
          });
        },
      },
    );

    setIsTagPopupOpen(false);
    setSelectedMessage(null);
    setAnchorEl(null);
  };

  const handleTagRemove = (tag: any, message: MessageData) => {
    setTagToRemove({ tag, message });
    setIsTagRemoveConfirmationOpen(true);
  };

  const confirmTagRemove = () => {
    if (!tagToRemove) return;

    const { tag, message } = tagToRemove;

    const updatedMessageTags = message.messageTags.filter((item: any) => item._id !== tag._id);

    putupdateMessageData(
      {
        _id: message._id,
        messageTags: updatedMessageTags,
      },
      {
        onSuccess: () => {
          setPostMessageListData((prev: any) => {
            const updatedList = Array.isArray(prev)
              ? prev.map((item: any) =>
                  item._id === message._id ? { ...item, messageTags: updatedMessageTags } : item,
                )
              : [];
            return updatedList;
          });
        },
      },
    );

    setIsTagRemoveConfirmationOpen(false);
    setTagToRemove(null);
  };

  const retryMessage = (message: MessageData) => {
    retryUpdateMessage(
      { _id: message._id, status: 'retry' },
      {
        onSuccess: () => {
          setPostMessageListData((prev: any) => {
            const updatedList = prev.map((item: any) =>
              item._id === message._id ? { ...item, status: 'sent' } : item,
            );
            return updatedList;
          });
        },
        onError: onError,
      },
    );
  };

  const escapeRegExp = (string: string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
  };
  const renderHighlightedText = (text: string, highlight: string) => {
    if (!highlight) {
      return text; // If highlight is not provided, return the original text
    }

    const escapedHighlight = escapeRegExp(highlight);
    const parts = text.split(new RegExp(`(${escapedHighlight})`, 'gi'));
    return (
      <span>
        {parts.map((part, index) =>
          part.toLowerCase() === highlight.toLowerCase() ? (
            <span key={index} style={{ background: 'yellow', color: 'black' }}>
              {part}
            </span>
          ) : (
            part
          ),
        )}
      </span>
    );
  };

  const renderTags = (tags: any[], message: MessageData) => {
    return tags.map((tag, index) => (
      <Chip
        style={{ background: message.direction === 'sent' ? '#97b8cd' : '#97cdb5' }}
        key={index}
        label={
          search && search.field === 'tag' && tag._id === search.value ? (
            <span style={{ background: 'yellow', color: 'black' }}>{tag.name}</span>
          ) : (
            <span style={{ fontWeight: 'bold', color: 'black' }}>{tag.name}</span>
          )
        }
        size="small"
        sx={{ margin: '2px' }}
        onDelete={() => handleTagRemove(tag, message)}
        deleteIcon={<CloseIcon />}
      />
    ));
  };

  const handleOption = (message: MessageData, status: string) => {
    setActionMessage(message);
    if (status === 'cancelled') {
      setIsCancelConfirmationOpen(true);
    } else if (status === 'send-now') {
      setIsSendNowConfirmationOpen(true);
    }
  };

  const confirmAction = (status: string) => {
    if (!actionMessage) return;

    retryUpdateMessage(
      { _id: actionMessage._id, status },
      {
        onSuccess: () =>
          postMessageList(
            { conversationId, page: 1, limit: 20 },
            {
              onSuccess: (res: any) => setPostMessageListData(res.data.data as MessageData[]),
              onError: (err: any) =>
                showToast('error', err.response.data.message, {
                  autoClose: 2000,
                  position: 'bottom-right',
                  className: 'custom-toast-error',
                }),
            },
          ),
      },
    );

    setIsCancelConfirmationOpen(false);
    setIsSendNowConfirmationOpen(false);
    setActionMessage(null);
  };

  const renderFollowUpMessage = (message: MessageData) => (
    <Box
      mb={2}
      key={message._id}
      sx={{
        border: '1px solid #ddd',
        borderRadius: '8px',
        padding: '16px',
        backgroundColor: '#f5f5f5',
        minWidth: '200px',
        wordBreak: 'break-word',
        display: 'flex',
        alignItems: 'center',
      }}
    >
      <Grid container alignItems="center" sx={{ display: 'flex', flexDirection: 'column' }}>
        <Grid item xs>
          <Typography variant="body2" sx={{ fontSize: '12px', color: 'grey' }} align="left">
            {capitalizeFirstChar(message.createdBy?.name)}{' '}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <IconButton sx={{ padding: '0px 4px 0px 0px' }}>
                {message?.type == 'followup' ? (
                  message?.status == 'completed' ? (
                    <Tooltip title="Follow up Completed">
                      <TaskAltIcon />
                    </Tooltip>
                  ) : (
                    <Tooltip title="Schedule Time">
                      <TimerIcon />
                    </Tooltip>
                  )
                ) : (
                  <EventIcon sx={{ color: 'gray' }} />
                )}
              </IconButton>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Typography sx={{ fontWeight: 'bold' }} component="div">
                  {message?.type == 'followup'
                    ? message?.status == 'completed'
                      ? 'Follow up Completed'
                      : 'Follow up Scheduled:'
                    : 'Message Scheduled : '}
                </Typography>
                {message?.status != 'completed' && (
                  <Typography component="div" sx={{ marginLeft: 1 }}>
                    {formatUSDate(message?.scheduleAt)}
                  </Typography>
                )}
              </Box>
            </Box>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: '' }}>
            <Typography variant="body1" component="div">
              {message.type !== 'followup' && message.text}
            </Typography>
          </Box>
          <Box>
            <Box>
              {message?.type !== 'followup' && (
                <>
                  <Typography sx={{ fontWeight: 'bold' }} component="div">
                    From Timezone Compliance:
                  </Typography>
                  <Typography variant="body1" component="div">
                    Your message has been scheduled for sending at{' '}
                    {formatUSDateTimeZone(
                      convertUTCToLocal(message?.scheduleAt, customer?.utcOffset).toISOString(),
                    )}{' '}
                    in this customers timezone, because the original attempt to send was made
                    outside of compliant hours. Please contact your Epika administrator for more
                    information.
                  </Typography>
                </>
              )}
            </Box>
            {
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'end' }}>
                {message.status === 'cancelled' ? (
                  <Tooltip title="Cancelled">
                    <CancelIcon fontSize="small" sx={{ color: 'red' }} />
                  </Tooltip>
                ) : message.status !== 'completed' ? (
                  <Box>
                    <Button
                      sx={{ color: 'gray', border: '1px solid ' }}
                      onClick={(event) => {
                        setActionMessage(message);
                        setActionMenuAnchorEl(event.currentTarget);
                      }}
                    >
                      Actions <KeyboardArrowDownIcon />
                    </Button>
                    <Menu
                      anchorEl={actionMenuAnchorEl}
                      open={Boolean(actionMenuAnchorEl)}
                      onClose={() => setActionMenuAnchorEl(null)}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'right',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                      }}
                      sx={{
                        '& .MuiPaper-root': {
                          backgroundColor: '#fff',
                          color: '#000',
                          boxShadow: '0 2px 3px rgba(0, 0, 0, 0.1)',
                          borderRadius: '8px',
                          minWidth: '100px',
                          marginTop: '5px', // Add some margin to prevent overlapping with the button
                        },
                        '& .MuiMenuItem-root': {
                          '&:hover': {
                            backgroundColor: '#f5f5f5',
                          },
                        },
                      }}
                    >
                      <Box
                        onClick={() => {
                          handleOption(actionMessage, 'cancelled');
                          setActionMenuAnchorEl(null);
                        }}
                        sx={{
                          fontSize: '0.875rem',
                          padding: '8px 16px',
                          cursor: 'pointer',
                          '&:hover': {
                            backgroundColor: '#f5f5f5',
                          },
                        }}
                      >
                        Cancel
                      </Box>
                      {actionMessage?.type !== 'followup' && (
                        <Box
                          onClick={() => {
                            handleOption(actionMessage, 'send-now');
                            setActionMenuAnchorEl(null);
                          }}
                          sx={{
                            fontSize: '0.875rem',
                            padding: '8px 16px',
                            cursor: 'pointer',
                            '&:hover': {
                              backgroundColor: '#f5f5f5',
                            },
                          }}
                        >
                          Send Now
                        </Box>
                      )}
                    </Menu>
                  </Box>
                ) : null}
              </Box>
            }
          </Box>

          {message.type == 'followup' && message?.status == 'completed' && (
            <Typography
              variant="body1"
              component="div"
              gutterBottom
              sx={{ display: 'flex', alignItems: 'end', justifyContent: 'end' }}
            >
              {formatUSDate(message?.scheduleAt)}
            </Typography>
          )}
        </Grid>
        <Typography
          variant="body1"
          align={'right'}
          color="textSecondary"
          style={{
            fontSize: '13px',
            borderBottom: '0px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'end',
            gap: '2px',
          }}
        ></Typography>
      </Grid>
    </Box>
  );

  const renderMessage = (message: MessageData, index: number) => {
    const isLog = message.type === 'log';
    const isSend = message.direction === 'sent';
    const status = message.status;
    if (message.type === 'followup' || status == 'queue') {
      return (
        <Box sx={{ display: 'flex', justifyContent: 'end', marginRight: '16px' }}>
          {renderFollowUpMessage(message)}
        </Box>
      );
    }

    const containerStyles = {
      textAlign: isLog ? 'center' : isSend ? 'right' : 'left',
      padding: isSend ? '10px' : undefined,
      borderRadius: isSend ? '10px' : undefined,
      fontSize: !isSend ? '13px' : undefined,
      borderBottom: '0px',
      display: 'flex',
      justifyContent: isSend ? 'end' : 'start',
    };

    const messageStyles = isSend
      ? {
          backgroundColor: '#e3f2fd',
          borderRadius: '10px 10px 0px 10px',
          padding: '10px',
          minWidth: '200px',
          maxWidth: '500px',
          position: 'relative',
          display: 'inline-block',
          justifyContent: 'end',
        }
      : isLog
        ? { fontSize: '13px' }
        : {
            backgroundColor: '#52fddb36',
            borderRadius: '0px 10px 10px 10px',
            padding: '10px',
            display: 'inline-block',
            minWidth: '200px',
            maxWidth: '500px',
            position: 'relative',
            justifyContent: 'start',
          };

    return (
      <Box mb={2} key={index} ref={(el) => (messageRefs.current[index] = el)} sx={containerStyles}>
        <Grid
          sx={{
            width: isLog ? '100%' : 'fit-content',
            justifyContent: isLog ? 'center' : message.direction === 'sent' ? 'end' : 'start ',
            display: 'flex',
            gap: '2px',
          }}
        >
          <Box style={{ display: 'inline-flex', alignItems: 'center', flexDirection: 'column' }}>
            {message.type === 'sms' && message.direction === 'sent' && (
              <IconButton onClick={(event) => handleMenuClick(event, message)} size="small">
                <Tooltip title="Options">
                  <MoreVertIcon fontSize="small" />
                </Tooltip>
              </IconButton>
            )}
            {message.type === 'sms' && message.direction === 'sent' && (
              <IconButton
                onClick={(event) => handleTagClick(event, message)}
                size="small"
                sx={{ ml: 0, opacity: 0.5, fontSize: '1rem' }}
              >
                <Tooltip title="Tags">
                  <LocalOfferIcon fontSize="inherit" sx={{ transform: 'rotate(90deg)' }} />
                </Tooltip>
              </IconButton>
            )}
          </Box>
          <Grid sx={messageStyles}>
            {!isLog && (
              <Typography variant="body2" sx={{ fontSize: '12px', color: 'grey' }} align="left">
                {capitalizeFirstChar(message.createdBy?.name)}{' '}
              </Typography>
            )}
            <Typography
              align={isLog ? 'center' : 'left'}
              variant="h6"
              style={{
                fontSize: isLog ? '15px' : '18px',
                justifyContent: 'center',
                // wordWrap: 'break-word', // Ensures long words are wrapped
                overflowWrap: 'break-word', // Breaks words when necessary
                // whiteSpace: 'pre-wrap', // Allows wrapping
              }}
            >
              {search && (search.field === 'all' || search.field === 'messages') && search.value
                ? renderHighlightedText(message.text, search.value)
                : message.text}
            </Typography>
            <Box mt={1} display="flex" justifyContent={isLog ? 'center' : 'left'}>
              {renderTags(message.messageTags, message)}
            </Box>
            <Typography
              variant="body1"
              align={isLog ? 'center' : 'right'}
              color="textSecondary"
              style={{
                fontSize: '13px',
                borderBottom: '0px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: isLog ? 'center' : 'end',
                gap: '2px',
              }}
            >
              {formatUSDate(message.createdAt)}

              {isSend && message.status === 'sent' && (
                <Tooltip title="Sent">
                  <DoneIcon fontSize="small" />
                </Tooltip>
              )}
              {isSend && message.status === 'cancelled' && (
                <Tooltip title="Cancelled">
                  <CancelIcon fontSize="small" sx={{ color: 'red' }} />
                </Tooltip>
              )}
              {isSend && message.status === 'undelivered' && (
                <Box display="flex" alignItems="center">
                  <Typography
                    variant="body1"
                    style={{
                      color: 'red',
                      fontSize: '13px',
                      borderBottom: '0px',
                    }}
                  >
                    {' Failed'}
                  </Typography>
                  <Tooltip title="Retry" arrow>
                    <IconButton
                      onClick={() => retryMessage(message)}
                      size="small"
                      sx={{ ml: 1, color: 'red' }}
                    >
                      <ReplayIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Box>
              )}
            </Typography>
          </Grid>

          <Box style={{ display: 'inline-flex', alignItems: 'center', flexDirection: 'column' }}>
            {message.type === 'sms' && message.direction === 'received' && (
              <IconButton onClick={(event) => handleMenuClick(event, message)} size="small">
                <Tooltip title="Options">
                  <MoreVertIcon fontSize="small" />
                </Tooltip>
              </IconButton>
            )}
            {message.type === 'sms' && message.direction === 'received' && (
              <IconButton
                onClick={(event) => handleTagClick(event, message)}
                size="small"
                sx={{ ml: 0, opacity: 0.5, fontSize: '1rem' }}
              >
                <Tooltip title="Tags">
                  <LocalOfferIcon fontSize="inherit" />
                </Tooltip>
              </IconButton>
            )}
          </Box>
        </Grid>

        <Menu
          anchorEl={menuAnchorEl}
          open={Boolean(menuAnchorEl)}
          onClose={handleMenuClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
          transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          sx={{
            '& .MuiPaper-root': {
              backgroundColor: '#fff',
              color: '#000',
              boxShadow: '0 2px 3px rgba(0, 0, 0, 0.1)',
              borderRadius: '8px',
              minWidth: '50px',
            },
            '& .MuiMenuItem-root': {
              '&:hover': {
                backgroundColor: '#f5f5f5',
              },
            },
          }}
        >
          <Box
            onClick={() => {
              setIsDeleteConfirmationOpen(true);
              handleMenuClose();
            }}
            sx={{
              fontSize: '0.875rem',
              padding: '8px 16px',
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: '#f5f5f5',
              },
            }}
          >
            Delete
          </Box>
        </Menu>
      </Box>
    );
  };

  return (
    <Box
      my={2}
      flexGrow={1}
      overflow="hidden"
      sx={{ overflowY: 'auto' }}
      onScroll={handleScroll}
      ref={messageContainerRef}
    >
      {loading && page > 1 && (
        <Box display="flex" justifyContent="center" alignItems="center">
          <CircularProgress />
        </Box>
      )}
      {messagesToRender.length === 0 && search.value ? (
        <Box
          p={2}
          display="flex"
          flexDirection="column"
          justifyContent="center"
          height={'100%'}
          alignItems="center"
        >
          <Typography variant="h4" color="textSecondary" sx={{ fontWeight: 600 }}>
            No search results in this chat
          </Typography>
        </Box>
      ) : (
        messagesToRender.map(renderMessage)
      )}
      <div ref={messageEndRef} />

      {selectedMessage && (
        <TagPopup
          handleSeletedTag={handleSelectedTag}
          open={isTagPopupOpen}
          anchorEl={anchorEl}
          onClose={handleTagPopupClose}
        />
      )}

      <ModalDialoge
        open={isDeleteConfirmationOpen}
        onClose={() => setIsDeleteConfirmationOpen(false)}
        title="Delete Message"
        dialogType={'delete'}
        contentText={'Are you sure you want to delete the message?'}
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
        onClickOK={handleDeleteMessage}
      />

      <ModalDialoge
        open={isTagRemoveConfirmationOpen}
        onClose={() => setIsTagRemoveConfirmationOpen(false)}
        title="Remove Tag"
        dialogType={'delete'}
        contentText={'Are you sure you want to remove the tag?'}
        actionButtonText={'Remove'}
        cancelText={'Cancel'}
        onClickOK={confirmTagRemove}
      />

      <ModalDialoge
        open={isCancelConfirmationOpen}
        onClose={() => setIsCancelConfirmationOpen(false)}
        title="Cancel Message"
        dialogType={'delete'}
        contentText={'Are you sure you want to cancel the message?'}
        actionButtonText={'Cancel'}
        cancelText={'Close'}
        onClickOK={() => confirmAction('cancelled')}
      />

      <ModalDialoge
        open={isSendNowConfirmationOpen}
        onClose={() => setIsSendNowConfirmationOpen(false)}
        title="Send Message Now"
        dialogType={'delete'}
        contentText={'Are you sure you want to send the message now?'}
        actionButtonText={'Send'}
        cancelText={'Close'}
        onClickOK={() => confirmAction('send-now')}
      />
    </Box>
  );
};

export default ChatMessages;
