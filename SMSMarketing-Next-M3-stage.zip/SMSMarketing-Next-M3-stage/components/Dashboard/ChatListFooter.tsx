import React, { useState } from 'react';
import {
  Box,
  Checkbox,
  Button,
  Menu,
  MenuItem,
  Select,
  InputLabel,
  Typography,
  Divider,
  Collapse,
} from '@mui/material';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import { CustomFormControl } from '@/constants/key';
import styles from '../../styles/admin.module.css';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';

const ChatListFooter = ({
  tabValue,
  count,
  selectAll,
  selectedConversations,
  sortOrder,
  transformedUserList,
  teamList,
  actionMenuAnchor,
  conversationActionsOpen,
  assignActionsOpen,
  chatListHeaderHeight,
  setAssignActionsOpen,
  setConversationActionsOpen,
  handleSelectAll,
  handleSortOrderChange,
  handleFilterChange,
  handleActionClick,
  handleActionClose,
  handleAction,
  handleAssignToUser,
}: any) => {
  const [anchorFilter, setAnchorFilter] = useState<null | HTMLElement>(null);
  const [selectedFilter, setSelectedFilter] = useState<string>('');
  const [selectedFilterValues, setSelectedFilterValues] = useState<{ [key: string]: string }>({});
  const [showModal, setShowModal] = useState<{
    flag: boolean;
    title: string;
    contentText: string;
    actionButtonText: string;
    action: () => void;
  }>({
    flag: false,
    title: '',
    contentText: '',
    actionButtonText: '',
    action: () => {},
  });

  const handleFilterClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorFilter(event.currentTarget);
    setSelectedFilter('');
  };

  const handleFilterClose = () => {
    setAnchorFilter(null);
    setSelectedFilter('');
  };

  const handleFilterItemClick = (filterType: string) => {
    setSelectedFilter(filterType === selectedFilter ? '' : filterType);
  };

  const handleMenuItemClick = (
    event: React.MouseEvent<HTMLElement>,
    filterType: string,
    value: string,
    label: string,
  ) => {
    const newValue = selectedFilterValues[filterType] === label ? '' : value;
    handleFilterChange({ target: { value: newValue } }, filterType);
    setSelectedFilterValues((prev) => ({
      ...prev,
      [filterType]: newValue ? label : '',
    }));
    handleFilterClose();
  };

  const handleClearFilters = () => {
    setSelectedFilterValues({});
    handleFilterChange({ target: { value: '' } }, 'status');
    handleFilterChange({ target: { value: '' } }, 'assignedToId');
    handleFilterChange({ target: { value: '' } }, 'teamId');
  };

  const handleActionWithConfirmation = (
    title: string,
    contentText: string,
    actionButtonText: string,
    action: () => void,
  ) => {
    setShowModal({
      flag: true,
      title,
      contentText,
      actionButtonText,
      action,
    });
  };

  const filters = [
    {
      label: 'Status',
      apiKey: 'status',
      options: [
        { value: 'unreplied', label: 'Unreplied' },
        { value: 'replied', label: 'Replied' },
        { value: 'closed', label: 'Closed' },
      ],
    },
    {
      label: 'Assignment',
      apiKey: 'assignedToId',
      options:
        transformedUserList?.map((user: any) => ({ value: user._id, label: user.name })) || [],
    },
    {
      label: 'Team',
      apiKey: 'teamId',
      options:
        teamList?.data?.data.map((team: any) => ({ value: team._id, label: team.name })) || [],
    },
  ];

  const selectedFiltersText = Object.values(selectedFilterValues).filter(Boolean).join(', ');

  return (
    <>
      <Box
        display="flex"
        justifyContent="start"
        alignItems="center"
        p={2}
        style={{ borderBottom: '1px solid #b3cec936' }}
      >
        {(tabValue === 0 && count.unassign > 0) ||
        (tabValue === 1 && count.assign > 0) ||
        (tabValue === 2 && count.all > 0) ? (
          <Checkbox
            checked={selectAll}
            sx={{
              color: 'var(--epika-primary-color)',
              '&.Mui-checked': {
                color: 'var(--epika-primary-color)', // Set the color for the checked state
              },
            }}
            onChange={handleSelectAll}
          />
        ) : null}
        {selectedConversations.length === 0 && (
          <Box display="flex" alignItems="center" flexGrow={1} gap={2}>
            <Button
              onClick={handleFilterClick}
              endIcon={anchorFilter ? <ExpandLess /> : <ExpandMore />}
              sx={{ color: 'black', flexGrow: 1 }}
            >
              {selectedFiltersText ? `Filters: ${selectedFiltersText}` : 'Filters'}
            </Button>
            <Menu
              anchorEl={anchorFilter}
              open={Boolean(anchorFilter)}
              onClose={handleFilterClose}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
            >
              {filters.map((filter) => (
                <Box key={filter.label}>
                  <MenuItem
                    onClick={() => handleFilterItemClick(filter.label.toLowerCase())}
                    sx={{ display: 'flex', justifyContent: 'space-between' }}
                  >
                    {filter.label}
                    {selectedFilter === filter.label.toLowerCase() ? (
                      <ExpandLess />
                    ) : (
                      <ExpandMore />
                    )}
                  </MenuItem>
                  <Collapse
                    in={selectedFilter === filter.label.toLowerCase()}
                    timeout="auto"
                    unmountOnExit
                  >
                    {filter.options.map((option: any) => (
                      <MenuItem
                        key={option.value}
                        onClick={(event) =>
                          handleMenuItemClick(event, filter.apiKey, option.value, option.label)
                        }
                        sx={{
                          paddingLeft: '15%',
                          backgroundColor:
                            selectedFilterValues[filter.apiKey] === option.label
                              ? 'rgba(0, 0, 0, 0.08)'
                              : 'inherit',
                        }}
                      >
                        <Typography
                          style={{
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >
                          {option.label}
                        </Typography>
                      </MenuItem>
                    ))}
                  </Collapse>
                </Box>
              ))}
              <Divider />
              <MenuItem onClick={handleClearFilters}>Clear Filters</MenuItem>
            </Menu>
            <CustomFormControl variant="outlined">
              <InputLabel>Sort Order</InputLabel>
              <Select value={sortOrder} onChange={handleSortOrderChange} label="Sort Order">
                <MenuItem value={-1}>New to Old</MenuItem>
                <MenuItem value={1}>Old to New</MenuItem>
              </Select>
            </CustomFormControl>
          </Box>
        )}
        {selectedConversations.length > 0 && (
          <Button
            onClick={handleActionClick}
            variant="contained"
            className={styles.adminButton}
            endIcon={<ArrowDropDownIcon />}
          >
            Actions
          </Button>
        )}
      </Box>
      {(tabValue === 0 && count.unassign > 0) ||
      (tabValue === 1 && count.assign > 0) ||
      (tabValue === 2 && count.all > 0) ? null : (
        <Typography
          variant="h6"
          color="textSecondary"
          sx={{
            overflow: 'auto',
            height: chatListHeaderHeight + 60 + 'px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          No More Conversation
        </Typography>
      )}
      <Menu
        anchorEl={actionMenuAnchor}
        open={Boolean(actionMenuAnchor)}
        onClose={handleActionClose}
      >
        <MenuItem
          onClick={() => setConversationActionsOpen(!conversationActionsOpen)}
          sx={{ display: 'flex', justifyContent: 'space-between' }}
        >
          Conversation Actions
          {conversationActionsOpen ? <ExpandLess /> : <ExpandMore />}
        </MenuItem>
        <Collapse in={conversationActionsOpen} timeout="auto" unmountOnExit>
          <MenuItem
            onClick={() =>
              handleActionWithConfirmation(
                'Close Conversation',
                'Are you sure you want to close the conversation?',
                'Close',
                () => {
                  handleAction('closed');
                  setShowModal({ ...showModal, flag: false });
                },
              )
            }
            sx={{ paddingLeft: '15%' }}
          >
            Close
          </MenuItem>
          <MenuItem
            onClick={() =>
              handleActionWithConfirmation(
                'Unassign Conversation',
                'Are you sure you want to unassign the conversation?',
                'Unassign',
                () => {
                  handleAction('unassign');
                  setShowModal({ ...showModal, flag: false });
                },
              )
            }
            sx={{ paddingLeft: '15%' }}
          >
            Unassign
          </MenuItem>
          <MenuItem
            onClick={() =>
              handleActionWithConfirmation(
                'Mark as Replied',
                'Are you sure you want to mark the conversation as replied?',
                'Mark as Replied',
                () => {
                  handleAction('replied');
                  setShowModal({ ...showModal, flag: false });
                },
              )
            }
            sx={{ paddingLeft: '15%' }}
          >
            Mark as Replied
          </MenuItem>
          <MenuItem
            onClick={() =>
              handleActionWithConfirmation(
                'Mark as Unreplied',
                'Are you sure you want to mark the conversation as unreplied?',
                'Mark as Unreplied',
                () => {
                  handleAction('unreplied');
                  setShowModal({ ...showModal, flag: false });
                },
              )
            }
            sx={{ paddingLeft: '15%' }}
          >
            Mark as Unreplied
          </MenuItem>
        </Collapse>
        <Divider />
        <MenuItem
          onClick={() => setAssignActionsOpen(!assignActionsOpen)}
          sx={{ display: 'flex', justifyContent: 'space-between' }}
        >
          Assign to Team Member
          {assignActionsOpen ? <ExpandLess /> : <ExpandMore />}
        </MenuItem>
        <Collapse in={assignActionsOpen} timeout="auto" unmountOnExit>
          {transformedUserList?.length > 0 ? (
            transformedUserList.map((user: any) => (
              <MenuItem
                key={user._id}
                onClick={() =>
                  handleActionWithConfirmation(
                    'Assign to User',
                    `Are you sure you want to assign to ${user.name}?`,
                    'Assign',
                    () => {
                      handleAssignToUser(user);
                      setShowModal({ ...showModal, flag: false });
                    },
                  )
                }
                sx={{ paddingLeft: '15%' }}
              >
                {user.name}
              </MenuItem>
            ))
          ) : (
            <MenuItem disabled>No users available</MenuItem>
          )}
        </Collapse>
      </Menu>
      <ModalDialoge
        open={showModal.flag}
        onClose={() => setShowModal({ ...showModal, flag: false })}
        title={showModal.title}
        dialogType={'delete'}
        contentText={showModal.contentText}
        actionButtonText={showModal.actionButtonText}
        cancelText={'Cancel'}
        onClickOK={() => {
          showModal.action();
          setShowModal({ ...showModal, flag: false });
        }}
      />
    </>
  );
};

export default ChatListFooter;
