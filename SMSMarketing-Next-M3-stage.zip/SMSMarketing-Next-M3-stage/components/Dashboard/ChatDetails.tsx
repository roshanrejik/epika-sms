import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Grid } from '@mui/material';
import { socketKeys } from '@/constants/socket-keys';
import useSocketEvent from '@/hooks/socket/useSocketEvent';
import { useGetUserListName } from '@/hooks/api/user.hooks';
import ChatHeader from './ChatHeader';
import ChatMessages from './ChatMessages';
import ChatInput from './ChatInput';
import { ChatDetailsProps, MessageData } from './ChatDetails.types';
import {
  usePostMessageList,
  usePostSendMessage,
  usePutupdateMessage,
} from '@/hooks/api/message.hooks';
import { usePostConversationList, usePostConversationUpdate } from '@/hooks/api/conversation.hooks';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import { showToast } from '../common/Toast/defaultToastOptions';
const ChatDetails: React.FC<ChatDetailsProps> = ({
  conversationId,
  currentAssignedTo,
  toPhoneNumber,
  customerName,
  postMessageListData,
  setPostMessageListData,
  refetch,
  setConversationListData,
  setCount,
  setTabValue,
  subscribed,
  customer,
  postCannedMessageListData,
  setCannedListBody,
  cannedListBody,
  toggleCustomerDetails,
  showCustomerDetails,
  isSubscribedLoading,
  againstCompliance,
  complianceMessage,
}) => {
  const [typeMsg, setTypeMsg] = useState<string>('');
  const { mutate: postMessageList } = usePostMessageList();
  const { mutate: updateConversation } = usePostConversationUpdate();
  const { mutate: sendMsgApi } = usePostSendMessage();
  const [selectedAgent, setSelectedAgent] = useState<string | null>(currentAssignedTo?.name || '');
  const { data: agentList } = useGetUserListName('');
  const messageEvent = `${socketKeys.conversationId}:${conversationId}`;
  const messageEndRef = useRef<HTMLDivElement>(null);
  const messageContainerRef = useRef<HTMLDivElement>(null);
  const messageRefs = useRef<(HTMLDivElement | null)[]>([]);
  const { mutate: conversationList } = usePostConversationList();
  const { mutate: putupdateMessageData } = usePutupdateMessage();

  const [showEmoji, setShowEmoji] = useState<boolean>(false);
  const [anchorElEmoji, setAnchorElEmoji] = useState<HTMLElement | null>(null);
  const [showCanned, setShowCanned] = useState<boolean>(false);
  const [anchorElCanned, setAnchorElCanned] = useState<HTMLElement | null>(null);
  const [page, setPage] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [isSubscribed, setIsSubscribed] = useState<boolean>(subscribed);
  const [noMoreMessages, setNoMoreMessages] = useState<boolean>(false);
  const [bufferedMessages, setBufferedMessages] = useState<MessageData[]>([]);
  const [renderBufferedMessages, setRenderBufferedMessages] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState(0);
  const { search } = useScreenHeight();

  const handleEmojiClick = (event: React.MouseEvent<HTMLElement>) => {
    setShowEmoji((prev) => !prev);
    setAnchorElEmoji(anchorElEmoji ? null : event.currentTarget);
  };

  const handleCannedClick = (event: React.MouseEvent<HTMLElement>) => {
    setShowCanned((prev) => !prev);
    setAnchorElCanned(anchorElCanned ? null : event.currentTarget);
  };

  useEffect(() => {
    setSelectedAgent(currentAssignedTo?._id);
  }, [currentAssignedTo]);

  useEffect(() => {
    setBufferedMessages([]);
    setTypeMsg('');
  }, [conversationId]);

  useEffect(() => {
    if (conversationId) {
      setIsSubscribed(subscribed);
      setLoading(true);
      setPage(1);
      setPostMessageListData([]);
      postMessageList(
        {
          conversationId,
          page: 1,
          limit: 20,
          search: search,
        },
        {
          onSuccess: (res: any) => {
            if (res.data.data.length === 0 || res.data.data.length < 20) {
              setNoMoreMessages(true);
            } else {
              setNoMoreMessages(false);
            }
            setPostMessageListData(res.data.data);
            setCurrentPage(res.data.currentPage ?? 0);
            setLoading(false);
            setTimeout(() => {
              messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          },
          onError: (err) => {
            console.error('Error fetching messages:', err);
            setLoading(false);
          },
        },
      );
    }
  }, [conversationId, postMessageList, setPostMessageListData, subscribed, search]); // Add searchMatchedMsg to dependency array
  useEffect(() => {
    if (page > 1 && !noMoreMessages && conversationId) {
      const prevScrollHeight = messageContainerRef.current?.scrollHeight || 0;
      const prevScrollTop = messageContainerRef.current?.scrollTop || 0;

      setLoading(true);
      postMessageList(
        { conversationId, page, limit: 20, search: search }, // Add searchMatchedMsg here
        {
          onSuccess: (res) => {
            if (res.data.data.length === 0 || res.data.data.length < 20) {
              setNoMoreMessages(true);
            } else {
              setNoMoreMessages(false);
            }
            setBufferedMessages((prevData: any) => [...res.data.data, ...prevData]);
            setLoading(false);

            setTimeout(() => {
              const newScrollHeight = messageContainerRef.current?.scrollHeight || 0;
              if (messageContainerRef.current) {
                messageContainerRef.current.scrollTop =
                  newScrollHeight - prevScrollHeight + prevScrollTop;
              }
            }, 100);
          },
          onError: (err) => {
            console.error('Error fetching messages:', err);
            setLoading(false);
          },
        },
      );
    }
  }, [page, conversationId, postMessageList, noMoreMessages]); // Add searchMatchedMsg to dependency array

  const handleMessage = useCallback(
    (data: MessageData) => {
      if (data.actionStatus === 'subscribed') setIsSubscribed(true);
      if (data.actionStatus === 'unsubscribed') setIsSubscribed(false);

      setPostMessageListData((prev: any) => {
        const updatedPrev = [...prev];
        if (data.status === 'undelivered' && data.isTwilioError && updatedPrev.length > 0) {
          updatedPrev[updatedPrev.length - 1] = data;
          return updatedPrev;
        } else {
          return [...updatedPrev, data];
        }
      });
      messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    },
    [setPostMessageListData],
  );

  useSocketEvent(messageEvent, handleMessage);

  const sendMsg = useCallback(() => {
    if (typeMsg.trim()) {
      const payload = {
        conversationId,
        text: typeMsg,
        toPhoneNumber,
        currentAssignedTo,
        customerName,
        customerData: customer,
      };
      setShowEmoji(false);
      setTypeMsg('');
      sendMsgApi(payload, {
        onSuccess: () => {
          setTypeMsg('');
          messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        },
        onError: (err: any) => {
          if (!err.response.data.success) {
            showToast('error', err.response.data.message, {
              autoClose: 2000,
              position: 'bottom-right',
              className: 'custom-toast-error',
            });
          }
        },
      });
    }
  }, [typeMsg, conversationId, sendMsgApi, toPhoneNumber, currentAssignedTo, customerName]);

  const handleSelectAgent = (event: any) => {
    const newValue = event.target.value as string;
    const matchingAgent = agentList?.data.data.find((agent: any) => agent._id === newValue);
    setSelectedAgent(matchingAgent?._id || '');

    const payload = matchingAgent
      ? {
          _id: conversationId,
          type: 'assign',
          assignedTo: matchingAgent,
        }
      : {
          _id: conversationId,
          type: 'unassign',
          assignedTo: currentAssignedTo,
        };

    updateConversation(payload, {
      onSuccess: () => {
        setShowEmoji(false);
        setTabValue(matchingAgent ? 2 : 0);
        conversationList(
          {
            page: '1',
            limit: 10,
            type: matchingAgent ? '' : 'unassign',
            search: {
              field: 'all',
              value: '',
            },
            sortField: '',
            sortOrder: '',
          },
          {
            onSuccess: (res: any) => {
              refetch();
              setConversationListData(res.data.data);
              setCount({
                unassign: res.data.unassign,
                assign: res.data.assign,
                all: res.data.all,
              });
              postMessageList(
                { conversationId, page: 1, limit: 20 },
                {
                  onSuccess: (res) => setPostMessageListData(res.data.data as MessageData[]),
                  onError: (err) => console.error('Error fetching messages:', err),
                },
              );
            },
            onError: (err: any) => {
              console.error(err);
            },
          },
        );
      },
      onError: (err) => {
        console.error('Error updating conversation:', err);
      },
    });
  };

  const onEmojiClick = (emojiData: any) => {
    setTypeMsg((prevMessage) => prevMessage + emojiData.emoji);
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (e.currentTarget.scrollTop === 0 && !loading && !noMoreMessages) {
      if (currentPage) {
        setPage(currentPage + 1);
      } else {
        setPostMessageListData((prevData: any) => [...bufferedMessages, ...prevData]);
        setBufferedMessages([]);
        setRenderBufferedMessages(true);
        setPage((prevPage) => prevPage + 1);
      }
    }
  };
  return (
    <Grid p={2} pt={0} display="flex" flexDirection="column" height="100%">
      <ChatHeader
        customerName={customerName}
        selectedAgent={selectedAgent}
        agentList={agentList}
        handleSelectAgent={handleSelectAgent}
        toggleCustomerDetails={toggleCustomerDetails}
        showCustomerDetails={showCustomerDetails}
      />
      <ChatMessages
        loading={loading}
        page={page}
        noMoreMessages={noMoreMessages}
        postMessageListData={postMessageListData}
        bufferedMessages={bufferedMessages}
        renderBufferedMessages={renderBufferedMessages}
        messageEndRef={messageEndRef}
        messageContainerRef={messageContainerRef}
        messageRefs={messageRefs}
        handleScroll={handleScroll}
        putupdateMessageData={putupdateMessageData}
        setPostMessageListData={setPostMessageListData}
        search={search}
        conversationId={conversationId}
        customer={customer}
        postMessageList={postMessageList}
      />
      <ChatInput
        typeMsg={typeMsg}
        setTypeMsg={setTypeMsg}
        handleEmojiClick={handleEmojiClick}
        handleCannedClick={handleCannedClick}
        showEmoji={showEmoji}
        anchorElEmoji={anchorElEmoji}
        onEmojiClick={onEmojiClick}
        showCanned={showCanned}
        anchorElCanned={anchorElCanned}
        setCannedListBody={setCannedListBody}
        cannedListBody={cannedListBody}
        customer={customer}
        postCannedMessageListData={postCannedMessageListData}
        sendMsg={sendMsg}
        disabled={!isSubscribed || isSubscribedLoading}
        againstCompliance={againstCompliance}
        complianceMessage={complianceMessage}
      />
    </Grid>
  );
};

export default ChatDetails;
