import { Box, IconButton, InputAdornment, Select, MenuItem, InputLabel } from '@mui/material';
import { StyledTextField, CustomFormControl } from '@/constants/key';
import ClearIcon from '@mui/icons-material/Clear';
import React from 'react';
interface SearchSectionProps {
  searchFieldsData: any;
  conversationListPayLoad: any;
  searchPlaceholder: string;
  searchValue: string;
  isTagLoading: boolean;
  tagsData: any;
  fetchTags: () => void;
  handleSelectChange: (event: React.ChangeEvent<{ value: unknown }>) => void;
  handleSearchChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  handleClearSearch: () => void;
  handleTagSelectChange: (event: React.ChangeEvent<{ value: unknown }>) => void;
}

const SearchSection: React.FC<SearchSectionProps> = ({
  searchFieldsData,
  conversationListPayLoad,
  searchPlaceholder,
  searchValue,
  isTagLoading,
  tagsData,
  handleSelectChange,
  handleSearchChange,
  handleClearSearch,
  handleTagSelectChange,
}) => {
  return (
    <Box p={2} display="flex" alignItems="center" gap={2}>
      <CustomFormControl variant="outlined" sx={{ minWidth: 150 }}>
        <InputLabel>Search Field</InputLabel>
        <Select
          value={conversationListPayLoad?.search?.field}
          onChange={handleSelectChange}
          label="Search Field"
        >
          {searchFieldsData?.data?.data.map((field: any) => (
            <MenuItem key={field.field} value={field.field}>
              {field.visible}
            </MenuItem>
          ))}
        </Select>
      </CustomFormControl>
      {conversationListPayLoad?.search?.field === 'tag' ? (
        <CustomFormControl variant="outlined">
          <InputLabel>Tag</InputLabel>
          <Select
            value={conversationListPayLoad?.search?.value || ''}
            onChange={handleTagSelectChange}
            label="Tag"
            disabled={isTagLoading}
            sx={{ minWidth: 150 }}
          >
            {tagsData?.data.map((tag: any) => (
              <MenuItem
                key={tag._id}
                value={tag._id}
                sx={{
                  '&:hover': {
                    backgroundColor: 'var(--epika-primary-color)',
                  },
                  '&.Mui-selected': {
                    backgroundColor: 'var(--epika-primary-color)',
                  },
                }}
              >
                {tag.name}
              </MenuItem>
            ))}
          </Select>
        </CustomFormControl>
      ) : (
        <StyledTextField
          variant="outlined"
          placeholder={searchPlaceholder}
          value={searchValue || ''} // Set the value of the text field
          onChange={handleSearchChange}
          fullWidth
          InputProps={{
            endAdornment: searchValue ? (
              <InputAdornment position="end">
                <IconButton onClick={handleClearSearch}>
                  <ClearIcon />
                </IconButton>
              </InputAdornment>
            ) : null,
          }}
        />
      )}
    </Box>
  );
};

export default SearchSection;
