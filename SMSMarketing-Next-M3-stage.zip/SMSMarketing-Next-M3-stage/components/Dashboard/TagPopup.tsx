import React, { useState } from 'react';
import {
  Box,
  Popover,
  List,
  ListItem,
  ListItemText,
  IconButton,
  CircularProgress,
  Typography,
  InputAdornment,
  Button,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import SearchIcon from '@mui/icons-material/Search';
import { useTagList, useAddTag, useDeleteTag } from '@/hooks/api/tag.hooks';
import { StyledTextField } from '@/constants/key';
import { showToast } from '../common/Toast/defaultToastOptions';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import DoneIcon from '@mui/icons-material/Done';
import CloseIcon from '@mui/icons-material/Close';
interface TagPopupProps {
  handleSeletedTag: any;
  open: boolean;
  anchorEl: null | HTMLElement;
  onClose: () => void;
}

const TagPopup: React.FC<TagPopupProps> = ({ open, anchorEl, onClose, handleSeletedTag }) => {
  const [search, setSearch] = useState('');
  const [error, setError] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [tagToDelete, setTagToDelete] = useState(null);
  const [isAdding, setIsAdding] = useState(false);

  const { data: tagsData, refetch: fetchTags, isLoading } = useTagList(search);
  const { mutate: addTagMutation } = useAddTag();
  const { mutate: deleteTagMutation } = useDeleteTag();

  const handleAddTag = () => {
    if (!search.trim()) {
      setError('Tag name cannot be empty');
      return;
    }
    setError('');
    addTagMutation(
      { name: search },
      {
        onSuccess: () => {
          showToast('success', 'Tag added successfully', {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-success',
          });
          fetchTags();
          setSearch('');
          setIsAdding(false);
        },
        onError: (err: any) => {
          showToast('error', err.response?.data?.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
        },
      },
    );
  };

  const handleDeleteTag = (tagId: string) => {
    setTagToDelete(tagId);
    setShowDeleteModal(true);
  };

  const confirmDeleteTag = (e: any) => {
    e.stopPropagation();
    if (tagToDelete) {
      deleteTagMutation(
        { _id: [tagToDelete] },
        {
          onSuccess: (res) => {
            showToast('success', res.data.message, {
              autoClose: 2000,
              position: 'bottom-right',
              className: 'custom-toast-success',
            });
            fetchTags();
          },
          onError: (err: any) => {
            showToast('error', err.response?.data?.message, {
              autoClose: 2000,
              position: 'bottom-right',
              className: 'custom-toast-error',
            });
            fetchTags();
          },
        },
      );
      setShowDeleteModal(false);
      setTagToDelete(null);
    }
  };

  return (
    <Popover
      open={open}
      anchorEl={anchorEl}
      onClose={onClose}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'center',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      PaperProps={{
        sx: {
          p: 2,
          width: 300,
          boxShadow: 3,
          borderRadius: 2,
        },
      }}
    >
      <Box>
        <Typography variant="h6" mb={2}>
          Manage Tags
        </Typography>
        <Box display="flex" mb={2}>
          <StyledTextField
            fullWidth
            variant="outlined"
            size="small"
            placeholder={isAdding ? 'Add New Tag' : 'Search tags'}
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setError('');
            }}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                if (isAdding) {
                  handleAddTag();
                } else {
                  fetchTags();
                }
              }
            }}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={isAdding ? null : fetchTags} size="small">
                    {isAdding ? null : <SearchIcon />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          {isAdding && (
            <IconButton onClick={handleAddTag} size="small">
              <DoneIcon />
            </IconButton>
          )}
          {isAdding ? (
            <IconButton
              onClick={() => {
                setIsAdding(!isAdding);
                isAdding && setSearch('');
                isAdding && setError('');
              }}
              size="small"
            >
              <CloseIcon />
            </IconButton>
          ) : (
            <Button
              variant="contained"
              onClick={() => {
                setIsAdding(!isAdding);
                isAdding && setSearch('');
                isAdding && setError('');
              }}
              sx={{
                ml: 1,
                backgroundColor: 'var(--epika-primary-color)',
                '&:hover': {
                  backgroundColor: 'var(--epika-primary-color)', // Ensures the hover color remains the same
                },
              }}
            >
              {isAdding ? 'Cancel' : 'Add'}
            </Button>
          )}
        </Box>
        {error && (
          <Typography color="error" variant="body2" mb={2}>
            {error}
          </Typography>
        )}
        {isLoading ? (
          <Box display="flex" justifyContent="center" alignItems="center">
            <CircularProgress sx={{ color: 'var(--epika-primary-color)' }} />
          </Box>
        ) : (
          <>
            {tagsData?.data?.length === 0 ? (
              <Typography variant="body2" color="textSecondary">
                No tags found
              </Typography>
            ) : (
              <List sx={{ maxHeight: 200, overflow: 'auto' }}>
                {tagsData?.data?.map((tag: any) => (
                  <ListItem
                    key={tag._id}
                    secondaryAction={
                      <IconButton
                        edge="end"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteTag(tag._id);
                        }}
                        size="small"
                      >
                        <DeleteIcon />
                      </IconButton>
                    }
                    sx={{
                      '&:hover': {
                        backgroundColor: '#f5f5f5',
                      },
                      borderRadius: 1,
                      mb: 1,
                    }}
                    onClick={() => handleSeletedTag(tag)}
                  >
                    <ListItemText primary={tag.name} />
                  </ListItem>
                ))}
              </List>
            )}
          </>
        )}
      </Box>
      <ModalDialoge
        open={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete"
        dialogType={'delete'}
        contentText={'Are you sure you want to delete the tag?'}
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
        onClickOK={(e: any) => confirmDeleteTag(e)}
      />
    </Popover>
  );
};

export default TagPopup;
