import { ListItem, Typography, Checkbox, Grid } from '@mui/material';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { useSearchParams } from 'next/navigation';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import React from 'react';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import { capitalizeFirstChar, formatPhoneNumber } from '@/utils/helpers';

const ChatItem = ({
  customerName,
  text,
  _id,
  handleClickChatsDetails,
  seen,
  direction,
  currentAssignedTo,
  isSelected,
  handleSelectConversation,
  messages,
}: any) => {
  const searchParams = useSearchParams();
  const cId = searchParams.get('cId');
  return (
    <ListItem
      button
      onClick={() => {
        handleClickChatsDetails(_id, messages);
      }}
      sx={
        cId === _id
          ? { backgroundColor: '#b3cec936', borderRadius: '8px', display: 'flex' }
          : { border: '1px solid #b3cec936', display: 'flex' }
      }
      key={_id}
    >
      <Checkbox
        checked={isSelected}
        sx={{
          opacity: isSelected ? 1 : 0.4,
          color: 'var(--epika-primary-color)',
          '&.Mui-checked': {
            color: 'var(--epika-primary-color)', // Set the color for the checked state
          },
        }}
        onChange={() => handleSelectConversation(_id)}
      />
      <div style={{ flexGrow: 1 }}>
        <Typography
          style={{
            fontWeight: !seen ? '700' : '400',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}
        >
          {customerName.includes('+')
            ? formatPhoneNumber(customerName)
            : capitalizeFirstChar(customerName)}
        </Typography>
        <Grid display="flex" alignItems="center">
          {direction === 'received' ? (
            <ArrowDownwardIcon sx={{ color: 'gray', fontSize: '1rem' }} />
          ) : direction === 'sent' ? (
            <ArrowUpwardIcon sx={{ color: 'gray', fontSize: '1rem' }} />
          ) : null}
          <Typography
            style={{
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              marginLeft: '4px',
              fontWeight: seen ? '400' : '700',
              width: '250px',
            }}
          >
            {text}
          </Typography>
        </Grid>
      </div>
      {currentAssignedTo ? <AccountCircleIcon fontSize="large" sx={{ color: 'gray' }} /> : null}
    </ListItem>
  );
};

export default ChatItem;
