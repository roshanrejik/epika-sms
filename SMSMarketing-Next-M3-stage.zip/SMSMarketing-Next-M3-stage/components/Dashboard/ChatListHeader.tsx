import { Box, IconButton, Typography, Popover, CircularProgress, Button } from '@mui/material';
import PersonAddAltIcon from '@mui/icons-material/PersonAddAlt';
import SearchIcon from '@mui/icons-material/Search';
import CloseIcon from '@mui/icons-material/Close';
import { StyledTextField } from '@/constants/key';
import React from 'react';
import styles from '../../styles/admin.module.css';
import { btnstyle } from '@/constants/key';
import { PhoneMask } from '../common/TextField/RHFPhoneNumber';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

interface ChatListHeaderProps {
  isPending: boolean;
  phoneNumber: string;
  phoneError: string;
  anchorEl: HTMLButtonElement | null;
  showSearch: boolean;
  handlePhoneNumberChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  handleSubmit: () => void;
  handleClose: () => void;
  addCustomModel: (event: React.MouseEvent<HTMLButtonElement>) => void;
  setShowSearch: (value: any) => void;
  setConversationListPayLoad: any;
}

const ChatListHeader: React.FC<ChatListHeaderProps> = ({
  isPending,
  phoneNumber,
  phoneError,
  anchorEl,
  showSearch,
  handlePhoneNumberChange,
  handleSubmit,
  handleClose,
  addCustomModel,
  setShowSearch,
  setConversationListPayLoad,
}) => {
  const open = Boolean(anchorEl);
  const { setSearch } = useScreenHeight();

  const id = open ? 'simple-popover' : undefined;
  const searchhandle = () => {
    setConversationListPayLoad((prev: any) => ({
      ...prev,
      search: {
        value: '',
        field: 'all',
      },
      page: 1,
    }));
    setShowSearch((prev: any) => !prev);
    setSearch({
      value: '',
      field: 'all',
    });
  };
  return (
    <Box
      sx={{ padding: '16px 16px 0' }}
      display="flex"
      alignItems="center"
      justifyContent="space-between"
    >
      <Typography variant="h6" sx={{ fontWeight: '400' }}>
        Conversations
      </Typography>
      <Box sx={{ width: '6 0px' }} display="flex">
        <IconButton
          size="large"
          edge="start"
          color="inherit"
          aria-label="add person"
          onClick={addCustomModel}
        >
          <PersonAddAltIcon />
        </IconButton>
        <Popover
          id={id}
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          sx={{ width: '400px' }}
        >
          <div style={{ padding: '16px', width: '300px' }}>
            <StyledTextField
              margin="normal"
              id="phone-number"
              label="Phone Number"
              type="text"
              variant="outlined"
              value={phoneNumber}
              onChange={handlePhoneNumberChange}
              error={!!phoneError}
              helperText={phoneError}
              InputProps={{
                inputComponent: PhoneMask,
              }}
              fullWidth
            />
            <Button
              type="submit"
              color="primary"
              variant="contained"
              style={btnstyle}
              className={styles.loginScreenButton}
              disabled={isPending}
              onClick={handleSubmit}
              fullWidth
            >
              {isPending ? <CircularProgress size={22} sx={{ color: 'white' }} /> : 'Submit'}
            </Button>
          </div>
        </Popover>
        <IconButton onClick={searchhandle} sx={{ padding: '8px 12px' }}>
          {showSearch ? <CloseIcon /> : <SearchIcon />}
        </IconButton>
      </Box>
    </Box>
  );
};

export default ChatListHeader;
