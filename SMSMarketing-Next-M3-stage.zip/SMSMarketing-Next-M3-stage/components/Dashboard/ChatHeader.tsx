import React from 'react';
import { Typography, Select, MenuItem, InputLabel, Box, IconButton } from '@mui/material';
import { CustomFormControl } from '@/constants/key';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';

interface ChatHeaderProps {
  customerName: string;
  selectedAgent: string | null;
  agentList: any;
  handleSelectAgent: (event: any) => void;
  toggleCustomerDetails: () => void;
  showCustomerDetails: boolean;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({
  customerName,
  selectedAgent,
  agentList,
  handleSelectAgent,
  toggleCustomerDetails,
  showCustomerDetails,
}) => {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        borderBottom: '1px solid #b3cec936',
        margin: '0px 10px',
      }}
    >
      <Typography variant="h5" style={{ flexGrow: 1 }}>
        Chat with {customerName}
      </Typography>
      <CustomFormControl variant="outlined" sx={{ margin: '10px' }}>
        <InputLabel id={`label`}>{selectedAgent ? 'Assignment Status' : 'Unassigned'}</InputLabel>
        <Select
          labelId={`label`}
          label="Assignment Status"
          value={selectedAgent || ''}
          onChange={handleSelectAgent}
          placeholder="Assign Agent"
          sx={{ width: '150px' }}
        >
          <MenuItem value="">
            <em>Unassign</em>
          </MenuItem>
          {agentList?.data.data.map((agent: any) => (
            <MenuItem
              key={agent._id}
              value={agent._id}
              // sx={{
              //   '&:hover': {
              //     backgroundColor: 'var(--epika-primary-color)',
              //   },
              //   '&.Mui-selected': {
              //     backgroundColor: 'var(--epika-primary-color)',
              //   },
              // }}
            >
              {agent.name}
            </MenuItem>
          ))}
        </Select>
      </CustomFormControl>
      <Box
        display="flex"
        justifyContent="flex-end"
        alignItems="center"
        style={{
          marginRight: showCustomerDetails ? '-48px' : '-10px',
        }}
      >
        <IconButton
          onClick={toggleCustomerDetails}
          sx={{
            width: '40px',
            height: '40px',
            backgroundColor: 'lightgray',
          }}
        >
          {showCustomerDetails ? <KeyboardDoubleArrowRightIcon /> : <KeyboardDoubleArrowLeftIcon />}
        </IconButton>
      </Box>
    </div>
  );
};

export default ChatHeader;
