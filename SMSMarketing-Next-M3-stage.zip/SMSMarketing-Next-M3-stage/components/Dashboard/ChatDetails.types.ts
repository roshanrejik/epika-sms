export interface ChatDetailsProps {
  conversationId: string | null;
  search: {
    field: string;
    value: string;
  };
  searchMatchedMsg: any;
  currentAssignedTo: any;
  toPhoneNumber: string;
  customerName: string;
  refetch: () => void;
  setConversationListData: any;
  postMessageListData: any;
  setCount: any;
  setPostMessageListData: any;
  setTabValue: any;
  subscribed: boolean;
  postCannedMessageListData: any;
  setCannedListBody: any;
  customer: any;
  cannedListBody: any;
  toggleCustomerDetails: () => void;
  showCustomerDetails: boolean;
  isSubscribedLoading: boolean;
  againstCompliance: boolean;
  complianceMessage: string;
}

export interface MessageData {
  _id: number;
  text: string;
  messageTags: any;
  direction: 'sent' | 'received';
  isFocus: any;
  type: string;
  createdAt: string;
  actionStatus: string;
  status: string;
  createdBy: {
    _id: string;
    name: string;
  };
  followUp: any;
  isTwilioError: any;
}
