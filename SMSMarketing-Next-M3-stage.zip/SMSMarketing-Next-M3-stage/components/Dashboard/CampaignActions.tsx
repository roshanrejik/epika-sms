import React, { useEffect, useState } from 'react';
import {
  Grid,
  Typography,
  Box,
  Button,
  Popper,
  Paper,
  ClickAwayListener,
  IconButton,
} from '@mui/material';
import { usePostCampaignAttach, usePostListCampaign } from '@/hooks/api/campaign.hooks';
import { showToast } from '../common/Toast/defaultToastOptions';
import { usePostMessageList } from '@/hooks/api/message.hooks';
import { useSearchParams } from 'next/navigation';
import { usePostFollowUpList, usePostFollowUpAttach } from '@/hooks/api/follow-up.hooks';
import _ from 'lodash';
import { StyledTextField } from '@/constants/key';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { formatUSDate } from '@/utils/helpers';
import Loader from '../common/Loader/Loader';

const CampaignActions = ({ customerPhoneNumber, setPostMessageListData }: any) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [followUpAnchorEl, setFollowUpAnchorEl] = useState(null);
  const [searchText, setSearchText] = useState('');
  const [options, setOptions] = useState([]);
  const [followUpOptions, setFollowUpOptions] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false); // State for Modal
  const [selectedCampaignId, setSelectedCampaignId] = useState(''); // State for selected campaign ID
  const { mutate: postListCampaign } = usePostListCampaign();
  const { mutate: postFollowUpList } = usePostFollowUpList();
  const { mutate: postCampaignAttach, isPending: isPendingAttach } = usePostCampaignAttach();
  const { mutate: postFollowUpAttach, isPending: isPendingFollowUpAttach } =
    usePostFollowUpAttach();
  const { mutate: postMessageList } = usePostMessageList();
  const searchParams = useSearchParams();
  const conversationId = searchParams.get('cId');
  const [campaignLoader, setCampaignLoader] = useState(false);
  const [followUpLoader, setfollowUpLoader] = useState(false);

  const fetchCampaigns = _.debounce((search) => {
    postListCampaign(
      {
        page: '1',
        limit: '5',
        search: search,
        schedule: '3',
      },
      {
        onSuccess: (res) => {
          setOptions(res.data.data);
        },
        onError: () => {},
      },
    );
  }, 300);

  const fetchFollowUps = _.debounce((search) => {
    postFollowUpList(
      {
        page: '1',
        limit: '5',
        search: search,
      },
      {
        onSuccess: (res) => {
          setFollowUpOptions(res.data.data);
        },
        onError: () => {},
      },
    );
  }, 300);

  useEffect(() => {
    fetchCampaigns(searchText);
    fetchFollowUps(searchText);
  }, [searchText]);

  const handleClick = (event) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };
  console.log(followUpLoader, 'followUpLoader');

  const handleFollowUpClick = (event) => {
    setFollowUpAnchorEl(followUpAnchorEl ? null : event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setFollowUpAnchorEl(null);
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
  };

  const handleModalConfirm = () => {
    setCampaignLoader(true);
    postCampaignAttach(
      {
        campaignId: selectedCampaignId,
        customerPhoneNumber: customerPhoneNumber,
        forceToAttach: true, // additional force attach flag
      },
      {
        onSuccess: (res) => {
          showToast('success', res.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-success',
          });
          postMessageList(
            { conversationId, page: 1, limit: 20 },
            {
              onSuccess: (res) => {
                setPostMessageListData(res.data.data);
                handleClose();
              },
            },
          );
          setIsModalOpen(false);
        },
        onError: (err: any) => {
          showToast('error', err.response.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
        },
      },
    );
    setCampaignLoader(false);
  };

  const handleClickCampaign = async (id: string) => {
    handleClose();
    setCampaignLoader(true);
    postCampaignAttach(
      {
        campaignId: id,
        customerPhoneNumber: customerPhoneNumber,
      },
      {
        onSuccess: (res) => {
          showToast('success', res.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-success',
          });
          postMessageList(
            { conversationId, page: 1, limit: 20 },
            {
              onSuccess: (res) => {
                setPostMessageListData(res.data.data);
                handleClose();
                setCampaignLoader(false);
              },
            },
          );
        },
        onError: (err: any) => {
          if (err.response.data.alreadyAttached) {
            setSelectedCampaignId(id); // Store the selected campaign ID
            setIsModalOpen(true); // Open the modal
          } else if (err.response.data.scheduleAt) {
            showToast(
              'error',
              `This campaign message has already been scheduled at ${formatUSDate(err.response.data.scheduleAt)}`,
              {
                autoClose: 3000,
                position: 'bottom-right',
                className: 'custom-toast-error',
              },
            );
          } else {
            showToast('error', err.response.data.message, {
              autoClose: 2000,
              position: 'bottom-right',
              className: 'custom-toast-error',
            });
          }
          setCampaignLoader(false);
        },
      },
    );
  };

  const handleClickFollowUp = async (id: string) => {
    handleClose();
    setfollowUpLoader(true);
    postFollowUpAttach(
      {
        followUpId: id,
        customerPhoneNumber: customerPhoneNumber,
      },
      {
        onSuccess: (res) => {
          showToast('success', res.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-success',
          });
          postMessageList(
            { conversationId, page: 1, limit: 20 },
            {
              onSuccess: (res) => {
                setPostMessageListData(res.data.data);
                setfollowUpLoader(false);
                handleClose();
              },
            },
          );
        },
        onError: (err: any) => {
          showToast('error', err.response.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
          setfollowUpLoader(false);
        },
      },
    );
  };

  const handleSearchTextChange = (event) => {
    setSearchText(event.target.value);
  };

  return (
    <Grid item sx={{ m: 1 }}>
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <Typography
          sx={{
            color: 'var(--epika-primary-color)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
          }}
          onClick={handleClick}
        >
          {`Send Campaign`}
          <IconButton sx={{ color: 'var(--epika-primary-color)' }} size="small">
            {campaignLoader ? <Loader /> : <ArrowForwardIosIcon />}
          </IconButton>
        </Typography>
      </Box>

      <Popper
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        placement="bottom-start"
        sx={{ zIndex: 1300, width: '300px' }}
      >
        <ClickAwayListener onClickAway={handleClose}>
          <Paper sx={{ p: 2, width: '100%' }}>
            <Box>
              <StyledTextField
                label="Search"
                variant="outlined"
                value={searchText}
                onChange={handleSearchTextChange}
                fullWidth
              />
            </Box>
            {options.length > 0 ? (
              options.map((option, index) => (
                <Box
                  key={index}
                  sx={{ display: 'flex', justifyContent: 'space-between', p: 1 }}
                  disabled={isPendingAttach}
                >
                  <Typography sx={{ fontWeight: 'bold' }}> {option?.name}</Typography>
                  <Button
                    onClick={() => handleClickCampaign(option._id)}
                    sx={{ color: 'var(--epika-primary-color)', textTransform: 'capitalize' }}
                  >
                    Send
                  </Button>
                </Box>
              ))
            ) : (
              <Typography sx={{ textAlign: 'center', mt: 2 }}>No campaigns found</Typography>
            )}
          </Paper>
        </ClickAwayListener>
      </Popper>

      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <Typography
          sx={{
            color: 'var(--epika-primary-color)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
          }}
          onClick={handleFollowUpClick}
        >
          {`Schedule Follow-Ups `}
          {followUpLoader ? <Loader /> : <ArrowForwardIosIcon />}
        </Typography>
      </Box>

      <Popper
        open={Boolean(followUpAnchorEl)}
        anchorEl={followUpAnchorEl}
        placement="bottom-start"
        sx={{ zIndex: 1300, width: '300px' }}
      >
        <ClickAwayListener onClickAway={handleClose}>
          <Paper sx={{ p: 2, width: '100%' }}>
            <Box>
              <StyledTextField
                label="Search"
                variant="outlined"
                value={searchText}
                onChange={handleSearchTextChange}
                fullWidth
              />
            </Box>
            {followUpOptions.length > 0 ? (
              followUpOptions.map((option, index) => (
                <Box
                  key={index}
                  sx={{ display: 'flex', justifyContent: 'space-between', p: 1 }}
                  disabled={isPendingFollowUpAttach}
                >
                  <Typography sx={{ fontWeight: 'bold' }}> {option?.name}</Typography>
                  <Button
                    onClick={() => handleClickFollowUp(option._id)}
                    sx={{ color: 'var(--epika-primary-color)', textTransform: 'capitalize' }}
                  >
                    Schedule
                  </Button>
                </Box>
              ))
            ) : (
              <Typography sx={{ textAlign: 'center', mt: 2 }}>No follow-ups found</Typography>
            )}
          </Paper>
        </ClickAwayListener>
      </Popper>

      <ModalDialoge
        open={isModalOpen}
        onClose={handleModalClose}
        title="Force Attach Campaign"
        dialogType="delete"
        contentText="This campaign is already attached to this customer. Are you sure you want to force attach it again?"
        actionButtonText="Yes"
        cancelText="Cancel"
        onClickOK={handleModalConfirm}
      />
    </Grid>
  );
};

export default CampaignActions;
