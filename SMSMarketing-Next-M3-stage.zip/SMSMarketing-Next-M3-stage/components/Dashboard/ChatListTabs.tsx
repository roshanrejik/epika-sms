import { Box, Tab, Tabs, Divider, Typography } from '@mui/material';
import React from 'react';
import AddIcon from '@mui/icons-material/Add';
interface ChatListTabsProps {
  count: any;
  tabValue: number;
  setTabValue: React.Dispatch<React.SetStateAction<number>>;
  setConversationListData: (value: any) => void;
  setConversationListPayLoad: (value: any) => void;
}

const ChatListTabs: React.FC<ChatListTabsProps> = ({
  count,
  tabValue,
  setTabValue,
  setConversationListData,
  setConversationListPayLoad,
}) => {
  const handleTabChange = (e: any, newValue: number) => {
    setTabValue(newValue);
    let newType = '';
    if (newValue === 0) newType = 'unassign';
    else if (newValue === 1) newType = 'assign';
    else if (newValue === 2) newType = 'all';
    setConversationListPayLoad((prev: any) => ({ ...prev, type: newType, page: 1 }));
    setConversationListData([]); // Clear the conversation list data when changing tabs
  };

  return (
    <>
      <Tabs
        value={tabValue}
        textColor="inherit"
        onChange={handleTabChange}
        sx={{
          bgcolor: 'white',
          color: 'black',
          '& .MuiTabs-indicator': {
            backgroundColor: 'var(--epika-primary-color)',
          },
          pt: 0,
        }}
        variant="fullWidth"
      >
        <Tab
          label={<CustomTab count={count.unassign} label="Unassigned" />}
          style={{ paddingTop: 0 }}
        />
        <Tab
          label={<CustomTab count={count.assign} label="Assigned to Me" />}
          style={{ paddingTop: 0 }}
        />
        <Tab label={<CustomTab count={count.all} label="All" />} style={{ paddingTop: 0 }} />
      </Tabs>
      <Divider />
    </>
  );
};

export default ChatListTabs;
const CustomTab = ({ count, label }: any) => (
  <Box display="flex" flexDirection="column" alignItems="center" position="relative">
    {count === 99 && (
      <Box
        position="absolute"
        top={-10}
        right={-10}
        display="flex"
        alignItems="center"
        justifyContent="center"
        width={24}
        height={24}
        borderRadius="50%"
        color="black"
      >
        <AddIcon fontSize="small" />
      </Box>
    )}
    <Typography className="fs-28 fw-500" alignItems="center">
      {count}
    </Typography>
    <Typography variant="body2" alignItems="center" sx={{ whiteSpace: 'nowrap' }}>
      {label}
    </Typography>
  </Box>
);
