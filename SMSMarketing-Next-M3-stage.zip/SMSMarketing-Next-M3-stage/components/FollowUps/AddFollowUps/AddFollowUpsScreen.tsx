'use client';
import React, { useEffect, useState } from 'react';
import { Box, Button, CircularProgress, IconButton, MenuItem, Typography } from '@mui/material';
// import { Delete as DeleteIcon } from '@mui/icons-material';
import { StyledTextField } from '@/constants/key';
// import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import styles from '../../../styles/admin.module.css';
import {
  QueryKeyFollowUp,
  useGetFollowUpDeatils,
  usePostFollowUpSave,
} from '@/hooks/api/follow-up.hooks';
import { useRouter, useSearchParams } from 'next/navigation';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import { QueryClient } from '@tanstack/react-query';
import { useGetUserListName } from '@/hooks/api/user.hooks';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

const AddFollowUpScreen = () => {
  const searchParams = useSearchParams();
  const queryClient = new QueryClient();
  const { availableHeight } = useScreenHeight();
  const router = useRouter();
  const id = searchParams.get('id');
  const [name, setName] = useState('');
  const [agentList, setAgentList] = useState([]);
  const [steps, setSteps] = useState([
    {
      after: 1,
      unit: 'Weeks',
      actions: [{ type: 'Send Message', value: '' }],
    },
  ]);

  const [errors, setErrors] = useState({ name: false, steps: [] });

  const { data: followUp, isFetched } = useGetFollowUpDeatils(id);
  const { mutate: saveFollowUp, isPending } = usePostFollowUpSave();
  const { data: agentListAPiData, isSuccess } = useGetUserListName('');

  useEffect(() => {
    if (isSuccess) {
      setAgentList(agentListAPiData.data.data);
    }
  }, [isSuccess, agentListAPiData]);

  useEffect(() => {
    if (isFetched && followUp?.data?.data && id) {
      const followUpData = followUp.data.data;
      setName(followUpData.name);
      setSteps(
        followUpData.sequences.map((sequence) => ({
          after: sequence.after,
          unit: sequence.type.charAt(0).toUpperCase() + sequence.type.slice(1),
          actions: sequence.action.map((action) => ({
            type: action.type
              .split('-')
              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
              .join(' '),
            value:
              action.type === 'Assign'
                ? { _id: action.value._id, name: action.value.name }
                : action.value,
          })),
        })),
      );
    }
  }, [isFetched, followUp, id]);

  // const addStep = () => {
  //   setSteps([
  //     ...steps,
  //     { after: 1, unit: 'Weeks', actions: [{ type: 'Send Message', value: '' }] },
  //   ]);
  //   setErrors({ ...errors, steps: [...errors.steps, { after: false, value: false }] });
  // };

  // const addAction = (index) => {
  //   const newSteps = [...steps];
  //   newSteps[index].actions.push({ type: 'Send Message', value: '' });
  //   setSteps(newSteps);
  // };

  // const deleteStep = (index) => {
  //   const newSteps = [...steps];
  //   newSteps.splice(index, 1);
  //   setSteps(newSteps);

  //   const newErrors = [...errors.steps];
  //   newErrors.splice(index, 1);
  //   setErrors({ ...errors, steps: newErrors });
  // };

  // const deleteAction = (stepIndex, actionIndex) => {
  //   const newSteps = [...steps];
  //   newSteps[stepIndex].actions.splice(actionIndex, 1);
  //   setSteps(newSteps);
  // };

  const handleSave = async () => {
    let valid = true;
    const newErrors = { name: false, steps: [] };

    if (!name) {
      newErrors.name = true;
      valid = false;
    }

    const validatedSteps = steps.map((step) => {
      const stepError = { after: false, value: false };
      if (!step.after || step.after <= 0) {
        stepError.after = true;
        valid = false;
      }
      step.actions.forEach((action) => {
        if (action.type === 'Send Message' && !action.value.trim()) {
          stepError.value = true;
          valid = false;
        }
      });
      return stepError;
    });

    newErrors.steps = validatedSteps;

    setErrors(newErrors);

    if (!valid) {
      showToast('error', 'Please fill out all required fields', {
        autoClose: 2000,
        position: 'bottom-right',
        className: 'custom-toast-error',
      });
      return;
    }

    const formattedSteps = steps.map((step) => ({
      after: step.after,
      type: step.unit.toLowerCase(),
      action: step.actions.map((action) => {
        const formattedAction = {
          type: action.type.toLowerCase().replace(' ', '-'),
        };
        if (action.type === 'Assign') {
          const selectedAgent = agentList.find((agent) => agent._id === action.value._id);
          formattedAction.value = {
            _id: selectedAgent ? selectedAgent._id : action.value._id,
            name: selectedAgent ? selectedAgent.name : action.value.name,
          };
        } else if (action.type !== 'Closed') {
          formattedAction.value = action.value;
        }
        return formattedAction;
      }),
    }));

    const data = {
      name,
      sequences: formattedSteps,
    };

    saveFollowUp(id ? { ...data, _id: id } : data, {
      onSuccess: () => {
        queryClient.invalidateQueries([QueryKeyFollowUp.GetFollowUpDetails]);
        router.push('/followups');
      },
      onError: (err: any) => {
        const regex = 'value" is not allowed to be empty';
        if (err.response.data.message.includes(regex)) {
          showToast('error', 'Please Enter Message Text', {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
        } else {
          showToast('error', err.response.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
        }
      },
    });
  };

  return (
    <Box>
      <Box className={styles.adminCustomersContainer} sx={{ p: 3 }}>
        <Box>
          <IconButton onClick={() => router.back()}>
            <ArrowBackIcon />
          </IconButton>
          Follow-Up Page
        </Box>
      </Box>
      <Box p={3} width="70%" mx="auto" sx={{ height: availableHeight - 150, overflowY: 'auto' }}>
        <StyledTextField
          fullWidth
          label="Give your Follow-Up a name"
          margin="normal"
          value={name}
          onChange={(e) => setName(e.target.value)}
          error={errors.name}
          helperText={errors.name ? 'Name is required' : ''}
        />
        {steps.map((step, stepIndex) => (
          <Box key={stepIndex} mb={2} p={2} border={1} borderRadius={2}>
            <Box display="flex" justifyContent="space-between" alignItems="center">
              <Box display="flex" alignItems="center">
                <Typography>Step {stepIndex + 1}:</Typography>
                <StyledTextField
                  label="After"
                  type="number"
                  value={step.after}
                  onChange={(e) => {
                    const newSteps = [...steps];
                    newSteps[stepIndex].after = e.target.value;
                    setSteps(newSteps);
                  }}
                  margin="normal"
                  style={{ width: '80px', marginLeft: '8px' }}
                  error={errors.steps[stepIndex]?.after}
                  helperText={errors.steps[stepIndex]?.after ? 'After is required' : ''}
                />
                <StyledTextField
                  select
                  value={step.unit}
                  onChange={(e) => {
                    const newSteps = [...steps];
                    newSteps[stepIndex].unit = e.target.value;
                    setSteps(newSteps);
                  }}
                  margin="normal"
                  style={{ width: '120px', marginLeft: '8px' }}
                >
                  <MenuItem value="Weeks">Weeks</MenuItem>
                </StyledTextField>
              </Box>
              {/* <Button
                onClick={() => deleteStep(stepIndex)}
                startIcon={<DeleteIcon />}
                size="small"
                sx={{ color: 'red' }}
              >
                Delete Step
              </Button> */}
            </Box>
            {step.actions.map((action, actionIndex) => (
              <Box key={actionIndex} display="flex" alignItems="center" mb={1}>
                <StyledTextField
                  select
                  value={action.type}
                  onChange={(e) => {
                    const newSteps = [...steps];
                    newSteps[stepIndex].actions[actionIndex].type = e.target.value;
                    setSteps(newSteps);
                  }}
                  margin="normal"
                  style={{ width: '300px', marginRight: '8px' }}
                >
                  <MenuItem value="Send Message">Send Message</MenuItem>
                </StyledTextField>
                {action.type === 'Assign' ? (
                  <StyledTextField
                    select
                    value={action.value._id}
                    onChange={(e) => {
                      const selectedAgent = agentList.find((agent) => agent._id === e.target.value);
                      const newSteps = [...steps];
                      newSteps[stepIndex].actions[actionIndex].value = selectedAgent
                        ? { _id: selectedAgent._id, name: selectedAgent.name }
                        : { _id: '', name: '' };
                      setSteps(newSteps);
                    }}
                    margin="normal"
                    fullWidth
                  >
                    {agentList.map((agent) => (
                      <MenuItem key={agent._id} value={agent._id}>
                        {agent.name}
                      </MenuItem>
                    ))}
                  </StyledTextField>
                ) : action.type !== 'Closed' ? (
                  <StyledTextField
                    value={action.value}
                    onChange={(e) => {
                      const newSteps = [...steps];
                      newSteps[stepIndex].actions[actionIndex].value = e.target.value;
                      setSteps(newSteps);
                    }}
                    label="Message Text"
                    margin="normal"
                    fullWidth
                    error={errors.steps[stepIndex]?.value}
                    helperText={errors.steps[stepIndex]?.value ? 'Message Text is required' : ''}
                  />
                ) : null}
                {/* <IconButton onClick={() => deleteAction(stepIndex, actionIndex)}>
                  <DeleteIcon />
                </IconButton> */}
              </Box>
            ))}
            {/* <Button
              startIcon={<AddCircleOutlineIcon />}
              onClick={() => addAction(stepIndex)}
              size="small"
              sx={{ color: 'var(--epika-primary-color)' }}
            >
              Add Action
            </Button> */}
          </Box>
        ))}
        {/* <Button
          onClick={addStep}
          startIcon={<AddCircleOutlineIcon />}
          size="small"
          sx={{ color: 'var(--epika-primary-color)' }}
        >
          Add Step
        </Button> */}

        <Box display="flex" justifyContent="flex-end" mt={3}>
          <Button className={styles.adminButton} onClick={handleSave} disabled={isPending}>
            {isPending ? <CircularProgress size={22} sx={{ color: 'white' }} /> : 'Save'}
          </Button>
        </Box>
      </Box>
    </Box>
  );
};

export default AddFollowUpScreen;
