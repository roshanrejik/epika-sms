'use client';
import {
  Button,
  Card,
  CardContent,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  Link,
  Typography,
} from '@mui/material';
import React, { useState } from 'react';
import BrowserUpdatedIcon from '@mui/icons-material/BrowserUpdated';
import DriveFolderUploadIcon from '@mui/icons-material/DriveFolderUpload';
import { showToast } from '../common/Toast/defaultToastOptions';
import { useExportMessages, useImportMessages } from '@/hooks/api/message.hooks';
import {
  useDownloadTemplate,
  useExportCustomers,
  useImportCustomers,
} from '@/hooks/api/customer.hooks';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import styles from '../../styles/admin.module.css';

const ImportExport = () => {
  const [importOpen, setImportOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [exportLoading, setExportLoading] = useState<'messages' | 'customers' | null>(null);
  const { mutate: exportMessages } = useExportMessages();
  const { mutate: importMessages } = useImportMessages();
  const { mutate: exportCustomers } = useExportCustomers();
  const { mutate: importCustomers } = useImportCustomers();
  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    id: string | null;
    flag: boolean;
  }>({
    id: null,
    flag: false,
  });
  const [confirmCancelOpen, setConfirmCancelOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [importReport, setImportReport] = useState<any>(null);
  const [importErrordownloadUrl, setimportErrordownloadUrl] = useState<any>(null);
  const [currentImportType, setCurrentImportType] = useState<'messages' | 'customers' | null>(null);
  const { mutate: downloadTemplate } = useDownloadTemplate();

  const handleCancelImport = () => {
    setConfirmCancelOpen(true);
  };

  const confirmCancelImport = () => {
    setLoading(false);
    setFile(null);
    setImportOpen(false);
    setConfirmCancelOpen(false);
  };

  const handleImport = () => {
    if (file) {
      setLoading(true);
      const formData = new FormData();
      formData.append('files', file);
      if (currentImportType === 'messages') {
        importMessages(formData, {
          onSuccess: (data) => {
            setImportReport(data.report);
            setLoading(false);
            setImportOpen(false);
          },
          onError: (err: any) => {
            setLoading(false);
            showToast('error', err.response.data.message, {
              autoClose: 2000,
              position: 'bottom-right',
              className: 'custom-toast-error',
            });
          },
        });
      } else if (currentImportType === 'customers') {
        importCustomers(formData, {
          onSuccess: (data) => {
            setImportReport(data.report);
            setimportErrordownloadUrl(data.downloadUrl);
            setLoading(false);
            setImportOpen(false);
          },
          onError: (err: any) => {
            setLoading(false);
            showToast('error', err.response.data.message, {
              autoClose: 2000,
              position: 'bottom-right',
              className: 'custom-toast-error',
            });
          },
        });
      }
    }
  };

  const handleExport = (type: 'messages' | 'customers') => {
    setExportLoading(type);
    const exportHandler = type === 'messages' ? exportMessages : exportCustomers;
    exportHandler(null, {
      onSuccess: (data: any) => {
        setExportLoading(null);
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `${type}-${new Date().toLocaleString()}.csv`);
        document.body.appendChild(link);
        link.click();
      },
      onError: (err: any) => {
        setExportLoading(null);
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };

  const handleDownloadTemplate = () => {
    downloadTemplate(null, {
      onSuccess: (data: any) => {
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'customersTemplate.csv');
        document.body.appendChild(link);
        link.click();
      },
      onError: (err: any) => {
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };

  return (
    <Grid
      container
      sx={{
        justifyContent: 'space-evenly',
        gap: '20px',
        display: 'flex',
        alignContent: 'space-evenly',
        height: '100%',
      }}
    >
      <Grid item md={6}>
        <Card>
          <CardContent>
            <Grid
              sx={{ display: 'flex', alignItems: 'center', gap: '10px', justifyContent: 'center' }}
            >
              <Typography variant="h6">Customer Import and Export</Typography>

              <Button
                onClick={() => handleExport('customers')}
                disabled={exportLoading === 'customers'}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  color: 'black',
                  border: '1px solid black', // Add border
                }}
              >
                <DriveFolderUploadIcon sx={{ color: 'black' }} /> {/* Change icon color to black */}
                {exportLoading === 'customers' ? (
                  <CircularProgress size={24} />
                ) : (
                  <Typography sx={{ marginLeft: '8px', color: 'black' }}>EXPORT </Typography>
                )}
              </Button>
            </Grid>
            <Grid sx={{ display: 'flex', justifyContent: 'center', paddingTop: '20px' }}>
              <Button
                onClick={() => {
                  setCurrentImportType('customers');
                  setImportOpen(true);
                }}
                disabled={loading}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  color: 'black',
                  width: '280px',
                  border: '1px solid black', // Add border
                }}
              >
                <BrowserUpdatedIcon sx={{ color: 'black' }} /> {/* Change icon color to black */}
                <Typography sx={{ marginLeft: '8px', color: 'black' }}>IMPORT</Typography>{' '}
              </Button>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
      <Grid item md={6}>
        <Card>
          <CardContent>
            <Grid
              sx={{ display: 'flex', alignItems: 'center', gap: '10px', justifyContent: 'center' }}
            >
              <Typography variant="h6">Message Import and Export</Typography>

              <Button
                onClick={() => handleExport('messages')}
                disabled={exportLoading === 'messages'}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  color: 'black',
                  border: '1px solid black', // Add border
                }}
              >
                <DriveFolderUploadIcon sx={{ color: 'black' }} /> {/* Change icon color to black */}
                {exportLoading === 'messages' ? (
                  <CircularProgress size={24} />
                ) : (
                  <Typography sx={{ marginLeft: '8px', color: 'black' }}>EXPORT</Typography>
                )}{' '}
              </Button>
            </Grid>
            <Grid sx={{ display: 'flex', justifyContent: 'center', paddingTop: '20px' }}>
              <Button
                onClick={() => {
                  setCurrentImportType('messages');
                  setImportOpen(true);
                }}
                disabled={loading}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  width: '280px',
                  color: 'black',
                  border: '1px solid black', // Add border
                }}
              >
                <BrowserUpdatedIcon sx={{ color: 'black' }} /> {/* Change icon color to black */}
                <Typography sx={{ marginLeft: '8px', color: 'black' }}>IMPORT</Typography>{' '}
              </Button>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Remove Agent"
        dialogType={'delete'}
        contentText={'Are you sure you want to remove the agent from team?'}
        actionButtonText={'Remove'}
        cancelText={'Cancel'}
        onClickOK={() => {}}
      />
      <Dialog
        open={importOpen}
        onClose={handleCancelImport}
        maxWidth="xs" // Increase modal size
        fullWidth // Ensure the dialog takes full width up to the maxWidth
      >
        <DialogTitle>
          Import {currentImportType === 'messages' ? 'Messages' : 'Customers'}
        </DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <input
            type="file"
            accept=".csv"
            onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)}
            disabled={loading}
            style={{ width: '100%', marginBottom: '16px' }} // Ensure input takes full width and add some margin
          />
          {loading && <CircularProgress />}

          <Typography variant="body1" sx={{ marginTop: '20px' }}>
            <Link
              component="button"
              variant="body2"
              onClick={handleDownloadTemplate}
              className={styles.adminLink} // Style this class in your CSS
              disabled={loading} // This will disable the link if loading is true
              sx={{ cursor: loading ? 'not-allowed' : 'pointer', color: loading ? 'grey' : 'blue' }}
            >
              {currentImportType !== 'messages' ? 'Download Template' : null}
            </Link>
          </Typography>
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center', padding: '8px 24px' }}>
          {/* Add padding for spacing */}
          <Button
            onClick={handleCancelImport}
            className={styles.adminButtonRevert}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleImport}
            className={!file || loading ? styles.adminButtonDisabled : styles.adminButton}
            disabled={!file || loading}
          >
            Import
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={confirmCancelOpen}
        maxWidth="xs" // Increase modal size
        fullWidth // Ensure the dialog takes full width up to the maxWidth
        onClose={() => setConfirmCancelOpen(false)}
      >
        <DialogTitle>Confirm Cancel</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Typography>Are you sure you want to cancel the import process?</Typography>
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center' }}>
          <Button onClick={() => setConfirmCancelOpen(false)} className={styles.adminButton}>
            No
          </Button>
          <Button onClick={confirmCancelImport} className={styles.adminButton}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {importReport && (
        <Dialog
          open={true}
          onClose={() => setImportReport(null)}
          maxWidth="xs" // Increase modal size
          fullWidth // Ensure the dialog takes full width up to the maxWidth
        >
          <DialogTitle>Import Report</DialogTitle>
          <DialogContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <Typography>Row Count: {importReport.rowCount}</Typography>
            <Typography>Count Errors: {importReport.countErrors}</Typography>
            <Typography>Inserted Count: {importReport.insertedCount}</Typography>
            <Typography>Insert Fails: {importReport.insertFails}</Typography>
            {importErrordownloadUrl && (
              <Typography variant="body1" sx={{ marginTop: '20px' }}>
                <Link
                  component="button"
                  variant="body2"
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = importErrordownloadUrl;
                    link.setAttribute(
                      'download',
                      `import_errors_${new Date().toLocaleString()}.csv`,
                    );
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link); // Clean up the DOM
                  }}
                  className={styles.adminLink} // You can style this class in your CSS
                >
                  Download Error File
                </Link>
              </Typography>
            )}
          </DialogContent>
          <DialogActions sx={{ justifyContent: 'center' }}>
            <Button onClick={() => setImportReport(null)} className={styles.adminButton}>
              Close
            </Button>
          </DialogActions>
        </Dialog>
      )}
    </Grid>

    // <Box sx={{ margin: '100px 0px', width: '100%' }}>
    //   <Typography variant="h4" sx={{ textAlign: 'center', marginBottom: '20px' }}>
    //     Customer Import and Export
    //   </Typography>
    //   <Box
    //     sx={{
    //       display: 'flex',
    //       justifyContent: 'space-evenly',
    //       alignItems: 'center',
    //       padding: '20px',
    //       gap: 2,
    //     }}
    //   >
    //     <Button
    //       onClick={() => {
    //         setCurrentImportType('customers');
    //         setImportOpen(true);
    //       }}
    //       disabled={loading}
    //       sx={{
    //         display: 'flex',
    //         alignItems: 'center',
    //         color: 'black',
    //         border: '1px solid black', // Add border
    //       }}
    //     >
    //       <BrowserUpdatedIcon sx={{ color: 'black' }} /> {/* Change icon color to black */}
    //       <Typography sx={{ marginLeft: '8px', color: 'black' }}>IMPORT CUSTOMERS</Typography>{' '}
    //       {/* Change text color to black */}
    //     </Button>
    //     <Button
    //       onClick={() => handleExport('customers')}
    //       disabled={exportLoading === 'customers'}
    //       sx={{
    //         display: 'flex',
    //         alignItems: 'center',
    //         color: 'black',
    //         border: '1px solid black', // Add border
    //       }}
    //     >
    //       <DriveFolderUploadIcon sx={{ color: 'black' }} /> {/* Change icon color to black */}
    //       {exportLoading === 'customers' ? (
    //         <CircularProgress size={24} />
    //       ) : (
    //         <Typography sx={{ marginLeft: '8px', color: 'black' }}>EXPORT CUSTOMERS</Typography>
    //       )}{' '}
    //       {/* Change text color to black */}
    //     </Button>
    //   </Box>
    //   <Typography variant="h4" sx={{ textAlign: 'center', marginBottom: '20px' }}>
    //     Message Import and Export
    //   </Typography>
    //   <Box
    //     sx={{
    //       display: 'flex',
    //       justifyContent: 'space-evenly',
    //       alignItems: 'center',
    //       padding: '20px',
    //       gap: 2,
    //     }}
    //   >
    //     text color to black */}
    //     </Button>
    //
    //   </Box>

    // </Box>
  );
};

export default ImportExport;
