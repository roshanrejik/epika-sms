'use client';
import { Box, Button, Grid, InputAdornment } from '@mui/material';
import React, { useEffect, useMemo, useState } from 'react';
import EventIcon from '@mui/icons-material/Event';
import { useRouter } from 'next/navigation';
import styles from '../../styles/admin.module.css';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import { StyledTextField } from '@/constants/key';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import { usePostListCampaign } from '@/hooks/api/campaign.hooks';
import GlassLoader from '../common/Loader/GlassLoader';
import CampaignTable from '../Tables/CampaignTable';
import debounce from 'lodash.debounce';
import { useCampaign } from '@/context/CampaignContext';

const Campaigns = () => {
  const router = useRouter();
  const { mutate: postListCampaign } = usePostListCampaign();
  const { resetCampaign } = useCampaign();
  const [firstTimeFlag, setFirstTimeFlag] = useState(true);
  const [campaignTableData, setCampaignTableData] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [campaignListBody, setCampaignListBody] = useState({
    page: 0,
    limit: 10,
    search: '',
  });
  useEffect(() => {
    const campaignListRequestBody = {
      ...campaignListBody,
      page: campaignListBody.page + 1,
    };
    debouncedChangeHandler(campaignListRequestBody);
  }, [campaignListBody.page, campaignListBody.limit, campaignListBody.search]);

  const onSuccess = (res: any) => {
    setCampaignTableData(res.data.data);
    setTotalCount(res.data.count);
    setFirstTimeFlag(false);
  };

  const onError = () => {};

  const debouncedChangeHandler = useMemo(
    () =>
      debounce(
        (campaignListRequestBody) =>
          postListCampaign(campaignListRequestBody, { onSuccess: onSuccess, onError: onError }),
        200,
      ),
    [],
  );

  return (
    <div>
      <Grid sx={{ margin: '10px 30px' }}>
        <Grid
          sx={{
            padding: '20px',
            display: 'flex',
            justifyContent: 'space-between',
          }}
        >
          <Grid
            sx={{
              display: 'flex',
              columnGap: '10px',
            }}
          >
            <Button
              startIcon={<AddOutlinedIcon />}
              size="small"
              onClick={() => {
                resetCampaign();
                router.push('/campaigns/add-campaign/create-campaign');
              }}
              className={styles.adminButton}
              disabled={false}
            >
              NEW CAMPAIGN
            </Button>
            <Button
              startIcon={<EventIcon />}
              size="small"
              disabled
              sx={{
                color: 'black',
                borderRadius: '30px',
                padding: '6px 20px',
                textTransform: 'none',
                '&:disabled': {
                  bgcolor: 'white',
                  color: 'black',
                },
              }}
            >
              {totalCount + ' Campaign(s)'}
            </Button>
          </Grid>

          <StyledTextField
            id="outlined-basic"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchOutlinedIcon />
                </InputAdornment>
              ),
            }}
            placeholder="Search"
            value={campaignListBody.search}
            onChange={(e) =>
              setCampaignListBody({ ...campaignListBody, search: e.target.value, page: 0 })
            }
            variant="outlined"
            disabled={false}
          />
        </Grid>
      </Grid>
      <Box sx={{ margin: '25px 25px 25px 25px' }}>
        {campaignTableData.length == 0 && firstTimeFlag ? (
          <GlassLoader />
        ) : (
          <CampaignTable
            data={campaignTableData}
            setData={setCampaignTableData}
            campaignListBody={campaignListBody}
            setCampaignsListBody={setCampaignListBody}
            totalCount={totalCount}
            setTotalCount={setTotalCount}
            debouncedChangeHandler={debouncedChangeHandler}
          />
        )}
      </Box>
    </div>
  );
};

export default Campaigns;
