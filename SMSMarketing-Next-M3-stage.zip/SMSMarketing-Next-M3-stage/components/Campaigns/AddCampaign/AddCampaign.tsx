'use client';
import {
  Box,
  Button,
  IconButton,
  InputAdornment,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';
import { useRouter, useSearchParams } from 'next/navigation';
import React, { useState, useEffect } from 'react';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import EditIcon from '@mui/icons-material/Edit';
import { useCampaign } from '@/context/CampaignContext';
import { useGetCampaignDetails } from '@/hooks/api/campaign.hooks';
import styles from '../../../styles/admin.module.css';
import { StyledTextField } from '@/constants/key';

const AddCampaign = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const id = searchParams.get('id');
  const { campaign, setCampaign } = useCampaign();
  const [editName, setEditName] = useState(id ? false : true);
  const [openDialog, setOpenDialog] = useState(id ? false : campaign.name ? false : true);
  const [tempName, setTempName] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const { data, isSuccess } = useGetCampaignDetails(id);

  useEffect(() => {
    if (isSuccess) {
      const dataTemp = data?.data?.data;
      if (dataTemp) {
        setCampaign({
          ...dataTemp,
          filterRule:
            dataTemp.filterRule?.length === 0
              ? [{ or: [{ field: '', value: '' }] }]
              : dataTemp.filterRule,
        });
      }
    }
  }, [isSuccess, data, setCampaign]);

  useEffect(() => {
    if (campaign && campaign.name) {
      setEditName(!id);
    }
  }, [id]);

  const handleNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setCampaign((prevCampaign) => ({
      ...prevCampaign!,
      name: value.charAt(0).toUpperCase() + value.slice(1),
    }));
    setTempName(value.charAt(0).toUpperCase() + value.slice(1));
    setErrorMessage(''); // Clear error message when user starts typing
  };

  const handleNameSave = () => {
    if (tempName.trim() !== '') {
      setCampaign((prevCampaign) => ({
        ...prevCampaign!,
        name: tempName,
      }));
      setEditName(false);
      setOpenDialog(false);
    } else {
      setOpenDialog(true);
    }
  };

  const handleDialogClose = () => {
    setOpenDialog(false);
  };

  const handleDialogSave = () => {
    if (tempName.trim() === '') {
      setErrorMessage('Campaign name cannot be empty.');
    } else {
      setCampaign((prevCampaign) => ({
        ...prevCampaign!,
        name: tempName,
      }));
      setEditName(false);
      setOpenDialog(false);
      setErrorMessage(''); // Clear error message on successful save
    }
  };

  return (
    <div>
      <Box sx={{ margin: '25px 25px 25px 25px' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignContent: 'center' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton onClick={() => router.push('/campaigns/')}>
              <ArrowBackIcon />
            </IconButton>
            ALL CAMPAIGNS
          </Box>
          <Box
            sx={{
              fontSize: 'var(--epika-primary-font-size)',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            {editName ? (
              <TextField
                value={campaign?.name || ''}
                placeholder={'Enter Campaign Name'}
                onChange={handleNameChange}
                variant="standard"
                InputProps={{
                  sx: {
                    fontSize: 'var(--epika-primary-font-size)',
                    '&:before': {
                      borderBottom: '1px solid rgba(0, 0, 0, 0.42)',
                    },
                    '&:hover:not(.Mui-disabled):before': {
                      borderBottom: '1px solid rgba(0, 0, 0, 0.87)',
                    },
                    '&:after': {
                      borderBottom: '2px solid var(--epika-primary-color)',
                    },
                  },
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={handleNameSave}>
                        <CheckCircleOutlineIcon />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            ) : (
              <Box
                sx={{
                  fontSize: 'var(--epika-primary-font-size)',
                }}
              >
                {campaign?.name}{' '}
                <IconButton onClick={() => setEditName(true)}>
                  <EditIcon />
                </IconButton>
              </Box>
            )}
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', width: '100px' }}></Box>
        </Box>
      </Box>
      <Dialog
        open={openDialog}
        onClose={handleDialogClose}
        maxWidth="xs" // Set a fixed max width
        fullWidth // Make the dialog full width within the max width constraint
      >
        <DialogTitle>Enter Campaign Name</DialogTitle>
        <DialogContent>
          <DialogContentText
            mb={2}
            color={errorMessage ? 'error' : 'inherit'}
            sx={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} // Ensure text does not cause width change
          >
            {errorMessage || 'Campaign name is required. Please enter the name.'}
          </DialogContentText>
          <StyledTextField
            autoFocus
            margin="dense"
            label="Campaign Name"
            type="text"
            fullWidth
            value={tempName}
            onChange={handleNameChange}
            error={Boolean(errorMessage)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogSave} className={styles.adminButton}>
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default AddCampaign;
