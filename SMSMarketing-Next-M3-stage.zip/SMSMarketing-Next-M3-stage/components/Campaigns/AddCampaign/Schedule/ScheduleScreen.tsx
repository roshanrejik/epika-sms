'use client';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import { Box, Button, Grid, Typography } from '@mui/material';
import styles from '../../../../styles/admin.module.css';
import React from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { usePostSaveCampaign } from '@/hooks/api/campaign.hooks';
import { useCampaign } from '@/context/CampaignContext';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import { campaignsData, hasFilterRule } from '@/utils/helpers';

const ScheduleScreen = () => {
  const { availableHeight } = useScreenHeight();
  const { mutate: postSaveCampaign } = usePostSaveCampaign();
  const { campaign, setCampaign }: any = useCampaign();
  const router = useRouter();
  const searchParams = useSearchParams();
  const id = searchParams.get('id');

  const handlePublish = (status: any) => {
    console.log(status, campaign?.schedule, 'statusstatus');
    if (status != '0') {
      if (campaign?.schedule == 0) {
        showToast('error', 'Please select a schedule option', {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
        return;
      }
    }

    if (status === '1') {
      if (!hasFilterRule(campaign)) {
        showToast('error', 'Please Add Filter Rule', {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
        return;
      }

      if (hasEmptyMessageText(campaign)) {
        showToast('error', 'Message text cannot be empty', {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
        return;
      }
    }

    // Check and set default messages if needed
    const updatedCampaign = {
      ...campaign,
      id,
      schedule: status,
      messages:
        campaign.messages && campaign.messages.length > 0
          ? campaign.messages.map((message) => ({
              ...message,
              text: message.text || '',
            }))
          : [{ text: '', optOut: false }],
    };

    postSaveCampaign(campaignsData(updatedCampaign), {
      onSuccess: () => {
        router.push('/campaigns/');
      },
      onError: (err: any) => {
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };
  const handlePublishSchedule = (status: any) => {
    console.log(status, campaign?.schedule, 'statusstatus');
    if (campaign?.schedule == 0) {
      showToast('error', 'Please select a schedule option', {
        autoClose: 2000,
        position: 'bottom-right',
        className: 'custom-toast-error',
      });
      return;
    }

    if (status === '1') {
      if (!hasFilterRule(campaign)) {
        showToast('error', 'Please Add Filter Rule', {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
        return;
      }

      if (hasEmptyMessageText(campaign)) {
        showToast('error', 'Message text cannot be empty', {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
        return;
      }
    }

    // Check and set default messages if needed
    const updatedCampaign = {
      ...campaign,
      id,
      schedule: status,
      messages:
        campaign.messages && campaign.messages.length > 0
          ? campaign.messages.map((message) => ({
              ...message,
              text: message.text || '',
            }))
          : [{ text: '', optOut: false }],
    };

    postSaveCampaign(campaignsData(updatedCampaign), {
      onSuccess: () => {
        router.push('/campaigns/');
      },
      onError: (err: any) => {
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };

  const hasEmptyMessageText = (campaign) => {
    return campaign?.messages?.some((message) => !message.text || message.text.trim() === '');
  };

  const campaignOptions = [
    {
      title: 'Immediate',
      apiValue: '1',
      description:
        'Send this campaign out immediately. It will take about 0-3 hours to complete, depending on the number of recipients. (You must set some filters for Recipients).',
    },
    // {
    //   title: 'Scheduled',
    //   description:
    //     'Send this campaign later, you get to pick when. (You must set some filters for Recipients).',
    //   child: (
    //     <>
    //       <LocalizationProvider dateAdapter={AdapterDayjs}>
    //         <DateTimePicker
    //           views={['year', 'month', 'day', 'hours', 'minutes']}
    //           onChange={(newValue) => setCampaign({ ...campaign, scheduledTime: newValue })}
    //           renderInput={(params) => <TextField {...params} />}
    //         />
    //       </LocalizationProvider>
    //       <Typography variant="body1">Time zone:</Typography>
    //       <Typography variant="body1">Central Time (US & Canada)</Typography>
    //     </>
    //   ),
    // },
    {
      title: 'Ready to Send',
      apiValue: '3',
      description:
        "This campaign is ready for the world but you don't want to send this campaign with the API, maybe you want to send it to individual customers later, or maybe you're going to use this campaign in a way that we didn't expect (we'd love to hear about it).",
    },
  ];

  return (
    <Grid
      sx={{
        height: availableHeight - 190,
        display: 'flex',
        alignContent: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        overflow: 'auto',
        gap: 2,
        padding: 2,
      }}
    >
      <Grid
        sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: 2 }}
      >
        <Typography variant="h6"> Would You Like to Send This Campaign?</Typography>
      </Grid>
      <Grid
        container
        spacing={2}
        sx={{ display: 'flex', gap: 2, justifyContent: 'center', alignItems: 'center' }}
      >
        {campaignOptions.map((option: any, index) => (
          <Grid
            item
            key={index}
            sx={{
              width: '300px',
              height: '300px',
              border: '1px solid black',
              cursor: 'pointer',
              ...(campaign.schedule === option.apiValue && {
                border: '2px solid var(--epika-primary-color)',
              }),
            }}
            p={2}
            sm={6}
            lg={3}
            onClick={() => setCampaign({ ...campaign, schedule: option.apiValue })}
          >
            <Typography variant="h6">{option.title}</Typography>
            <Typography variant="body1">{option.description}</Typography>
            {option?.child}
          </Grid>
        ))}
      </Grid>
      <Grid item xs={12} sx={{ m: 2 }}>
        <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
          <Button
            size="small"
            onClick={() => handlePublish('0')}
            disabled={campaign?.status == 2}
            className={campaign?.status == 2 ? styles.adminButtonDisabled : styles.adminButton}
          >
            SAVE DRAFT
          </Button>

          <Button
            size="small"
            onClick={() => handlePublishSchedule(campaign?.schedule)}
            style={{ backgroundColor: 'black', color: 'white' }}
            className={styles.adminButton}
          >
            PUBLISH
          </Button>
        </Box>
      </Grid>
    </Grid>
  );
};

export default ScheduleScreen;
