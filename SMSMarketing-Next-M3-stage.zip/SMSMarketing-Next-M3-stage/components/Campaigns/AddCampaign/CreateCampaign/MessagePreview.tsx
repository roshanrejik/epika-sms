import React, { useState } from 'react';
import {
  Grid,
  Box,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import styles from '../../../../styles/admin.module.css';
import { StyledTextField } from '@/constants/key';
import { PhoneMask } from '@/components/common/TextField/RHFPhoneNumber';
import { usePostSendMessagePreview } from '@/hooks/api/message.hooks';
import { showToast } from '@/components/common/Toast/defaultToastOptions';

const MessagePreview = ({ campaign }: any) => {
  const { mutate: sendMessage } = usePostSendMessagePreview();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const sendMessagePreview = () => {
    const formattedPhoneNumber = phoneNumber.replace(/\D/g, '');
    if (!formattedPhoneNumber || formattedPhoneNumber.length < 11) {
      showToast('error', 'Please enter a valid phone number.', {
        autoClose: 2000,
        position: 'bottom-right',
        className: 'custom-toast-error',
      });
      return;
    }

    sendMessage(
      {
        text: campaign?.messages[0].text,
        toPhoneNumber: '+' + formattedPhoneNumber,
      },
      {
        onSuccess: () => {
          setOpen(false);
          setPhoneNumber('');
          showToast('success', 'Test message sent successfully.', {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-success',
          });
        },
        onError: (err: any) => {
          showToast('error', err.response.data.message || 'Failed to send message.', {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
        },
      },
    );
  };

  return (
    <>
      <Grid
        sx={{
          width: '200px',
          height: '350px',
          marginLeft: '30px',
          border: '1px solid lightgrey',
          display: 'flex',
          flexDirection: 'column',
          borderRadius: '10px',
          backgroundColor: 'white',
          position: 'relative',
        }}
      >
        <Box
          sx={{
            flex: 1,
            width: '100%',
            padding: '10px 0',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            marginBottom: '10px',
            overflowY: 'auto', // Enable vertical scrolling if content overflows
          }}
        >
          {campaign?.messages[0].text && (
            <Typography
              sx={{
                fontWeight: 'bold',
                backgroundColor: '#91BEA0',
                color: 'white',
                padding: '10px 15px',
                borderRadius: '10px',
                textAlign: 'center',
                wordBreak: 'break-word',
                overflowWrap: 'break-word',
                maxWidth: '100%',
                margin: '10px', // Add margin for spacing
              }}
            >
              {campaign?.messages[0].text}
            </Typography>
          )}
        </Box>
        <Box
          sx={{
            width: '100%',
            boxSizing: 'border-box',
          }}
        >
          <Button
            variant="contained"
            className={styles.adminButton}
            onClick={handleClickOpen}
            disabled={!campaign?.messages[0].text}
            sx={{
              width: '100%',
              textTransform: 'none',
            }}
          >
            Send Test Message
          </Button>
        </Box>
      </Grid>

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Send a Test Message</DialogTitle>
        <DialogContent>
          <Typography gutterBottom>Make sure your text looks good before sending.</Typography>
          <Typography variant="subtitle2">Phone Number</Typography>
          <StyledTextField
            autoFocus
            id="phoneNumber"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            label="Phone Number"
            type="text"
            fullWidth
            variant="outlined"
            margin="normal"
            InputProps={{
              inputComponent: PhoneMask,
            }}
          />

          <Typography variant="body2" color="textSecondary" gutterBottom>
            Note: If you are using <a href="#">properties</a> in your text variants, we&apos;ll
            replace them with the property values associated with the phone number above.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} className={styles.adminButtonRevert}>
            Cancel
          </Button>
          <Button onClick={sendMessagePreview} className={styles.adminButton}>
            Send
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default MessagePreview;
