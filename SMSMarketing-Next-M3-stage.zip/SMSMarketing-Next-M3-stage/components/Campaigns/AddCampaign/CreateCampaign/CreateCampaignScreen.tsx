'use client';

import React, { useCallback, useEffect, useState, useRef } from 'react';
import {
  Button,
  Checkbox,
  Grid,
  IconButton,
  InputAdornment,
  Popover,
  Tooltip,
  Typography,
  Paper,
  List,
  ListItem,
} from '@mui/material';
import { Box } from '@mui/system';
import AddReactionIcon from '@mui/icons-material/AddReaction';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import EmojiPicker from 'emoji-picker-react';
import PlaylistAddIcon from '@mui/icons-material/PlaylistAdd';
import { useRouter, useSearchParams } from 'next/navigation';
import { StyledTextField } from '@/constants/key';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import { usePostSaveCampaign } from '@/hooks/api/campaign.hooks';
import { usePostCannedMessageList } from '@/hooks/api/canned.hooks';
import TemplateResponses from '@/components/MsgTemplate/MsgTemplate';
import styles from '../../../../styles/admin.module.css';
import { campaignsData } from '@/utils/helpers';
import { useCampaign } from '@/context/CampaignContext';
import MessagePreview from './MessagePreview';
import debounce from 'lodash.debounce';

const CreateCampaignScreen = () => {
  const { campaign, setCampaign } = useCampaign();
  const [showEmoji, setShowEmoji] = useState<boolean>(false);
  const [showTemplate, setShowTemplate] = useState<boolean>(false);
  const [anchorElTemplate, setAnchorElTemplate] = useState<HTMLElement | null>(null);
  const [postTemplateMessageListData, setPostTemplateMessageListData] = useState([]);
  const [templateListBody, setTemplateListBody] = useState({
    page: 0,
    limit: 10,
    search: '',
    shared: true,
    campaignTemplate: true,
  });
  const router = useRouter();
  const [anchorElEmoji, setAnchorElEmoji] = useState<HTMLElement | null>(null);
  const [cursorPosition, setCursorPosition] = useState(0);
  const [showPopup, setShowPopup] = useState(false);
  const { mutate: postSaveCampaign } = usePostSaveCampaign();
  const searchParams = useSearchParams();
  const { mutate: postTempleteMessageList } = usePostCannedMessageList();
  const [customerFields, setCustomerFields] = useState([]);
  const id = searchParams.get('id') == 'null' ? '' : searchParams.get('id');
  const textFieldRef = useRef<HTMLInputElement>(null);

  const fetchTemplateMessages = useCallback(
    debounce((payload: any) => {
      postTempleteMessageList(payload, {
        onSuccess: (res: any) => {
          setPostTemplateMessageListData(res.data.data);
        },
      });
    }, 300),
    [],
  ); // 300ms debounce delay

  useEffect(() => {
    const payload = {
      ...templateListBody,
      page: templateListBody.page + 1,
      shared: true,
      campaignTemplate: true,
    };
    fetchTemplateMessages(payload);
  }, [templateListBody, fetchTemplateMessages]);

  const handleTemplateClick = (event: React.MouseEvent<HTMLElement>) => {
    setShowTemplate((prev) => !prev);
    setAnchorElTemplate(anchorElTemplate ? null : event.currentTarget);
  };

  const handlePublish = (schedule: any) => {
    postSaveCampaign(campaignsData({ ...campaign, id, schedule: schedule }), {
      onSuccess: () => {
        router.push('/campaigns/');
      },
      onError: (err: any) => {
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };

  const handleEmojiClick = (event: React.MouseEvent<HTMLElement>) => {
    setShowEmoji((prev) => !prev);
    setAnchorElEmoji(anchorElEmoji ? null : event.currentTarget);
  };

  const onEmojiClick = (emojiData: any) => {
    if (textFieldRef.current) {
      const start = textFieldRef.current.selectionStart || 0;
      const end = textFieldRef.current.selectionEnd || 0;
      const newMessage = campaign?.messages[0].text || '';
      const updatedMessage = newMessage.slice(0, start) + emojiData.emoji + newMessage.slice(end);

      if (updatedMessage.length <= 250) {
        setCampaign((prevCampaign: any) => ({
          ...prevCampaign,
          messages: [{ ...prevCampaign.messages[0], text: updatedMessage }],
        }));
        setCursorPosition(start + emojiData.emoji.length); // Update cursor position

        // Move cursor to the new position
        setTimeout(() => {
          textFieldRef.current?.focus();
          textFieldRef.current?.setSelectionRange(
            start + emojiData.emoji.length,
            start + emojiData.emoji.length,
          );
        }, 0);
      }
    }
  };

  const handleCopySlug = () => {
    if (campaign?.slug) {
      navigator.clipboard.writeText(campaign.slug).then(() => {
        showToast('success', 'Copied to clipboard', {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-success',
        });
      });
    }
  };

  const onError = (err: any) =>
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });

  useEffect(() => {
    const payload = {
      ...templateListBody,
      page: templateListBody.page + 1,
    };
    postTempleteMessageList(payload, {
      onSuccess: (res) => {
        setCustomerFields(res.data.customerFields);
      },
      onError: onError,
    });
  }, [templateListBody]);

  const handleMessageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const message = e.target.value;
    const position = e.target.selectionStart || 0;
    const optOutText = 'Press "Stop" to stop the service. Press "Start" to show interest';

    setCampaign((prevCampaign: any) => {
      const updatedMessages = [{ ...prevCampaign.messages[0], text: message }];

      // Check if the opt-out message is present
      const optOutPresent = message.includes(optOutText);
      const updatedCampaign = {
        ...prevCampaign,
        messages: updatedMessages,
        messages: [
          {
            ...updatedMessages[0],
            optOut: optOutPresent,
          },
        ],
      };

      return updatedCampaign;
    });

    setCursorPosition(position);
    // Show popup for dynamic variables
    if (message.slice(position - 2, position) === '{{') {
      setShowPopup(true);
    } else {
      setShowPopup(false);
    }
  };

  const handleOptOutChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const optOutChecked = !e.target.checked;
    setCampaign((prevCampaign: any) => {
      let newText = prevCampaign.messages[0].text;
      const optOutText = '\nPress "Stop" to stop the service. Press "Start" to show interest';

      if (optOutChecked) {
        newText = newText.replace(optOutText, '');
      } else {
        if (!newText.includes(optOutText)) {
          newText += optOutText;
        }
      }

      return {
        ...prevCampaign,
        messages: [
          {
            ...prevCampaign.messages[0],
            optOut: !optOutChecked,
            text: newText,
          },
        ],
      };
    });
  };

  const handleSuggestionClick = (suggestion: any) => {
    const textBeforeCursor = campaign.messages[0].text.slice(0, cursorPosition - 2); // Remove the {{ before cursor
    const textAfterCursor = campaign.messages[0].text.slice(cursorPosition);

    const newText = `${textBeforeCursor}{{${suggestion}}}${textAfterCursor}`;
    setCampaign((prevCampaign: any) => ({
      ...prevCampaign,
      messages: [{ ...prevCampaign.messages[0], text: newText }],
    }));
    setShowPopup(false);

    // Move cursor to the new position
    const newCursorPosition = cursorPosition + suggestion.length + 3; // +3 for the {{
    setCursorPosition(newCursorPosition);

    setTimeout(() => {
      textFieldRef.current?.focus();
      textFieldRef.current?.setSelectionRange(newCursorPosition, newCursorPosition);
    }, 0);
  };

  return (
    <Grid
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'column',
        marginBottom: '200px',
      }}
    >
      <Grid
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <Grid sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Box sx={{ display: 'flex', flexDirection: 'row', gap: 2 }}>
            <Box>
              <Typography sx={{ fontWeight: 'bold' }}>Description</Typography>
              <StyledTextField
                label="Description"
                placeholder="Description"
                value={campaign?.description || ''}
                onChange={(e) => setCampaign({ ...campaign, description: e.target.value })}
                margin="normal"
                fullWidth
              />
            </Box>
            <Box>
              <Typography sx={{ fontWeight: 'bold' }}>Slug*(Send via API)</Typography>
              <StyledTextField
                label="Slug*(Send via API)"
                placeholder="Slug"
                value={campaign?.slug || ''}
                onChange={(e) => setCampaign({ ...campaign, slug: e.target.value })}
                margin="normal"
                disabled
                fullWidth
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={handleCopySlug}>
                        <ContentCopyIcon />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
          </Box>
          <Box>
            <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
              <Typography sx={{ fontWeight: 'bold' }}>Message</Typography>
            </Box>
            <Box position="relative">
              {showPopup && (
                <Paper style={{ position: 'absolute', top: '-50%', left: 0, zIndex: 1 }}>
                  <List>
                    {customerFields.map((suggestion: any) => (
                      <ListItem
                        button
                        key={suggestion}
                        onClick={() => handleSuggestionClick(suggestion)}
                      >
                        {suggestion}
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              )}
              <StyledTextField
                variant="outlined"
                fullWidth
                placeholder="Type your message"
                value={campaign?.messages[0].text || ''}
                multiline
                minRows={4}
                onChange={handleMessageChange}
                disabled={id !== null && id !== ''}
                inputRef={textFieldRef}
              />

              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'end',
                  border: '1px solid lightgrey',
                  borderRadius: '0px 0px 10px 10px',
                }}
              >
                <Popover
                  open={showEmoji}
                  anchorEl={anchorElEmoji}
                  onClose={handleEmojiClick}
                  anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'right',
                  }}
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'left',
                  }}
                >
                  <EmojiPicker onEmojiClick={onEmojiClick} />
                </Popover>

                <Tooltip title="Opt out">
                  <Checkbox
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)', // Set the color for the checked state
                      },
                    }}
                    onChange={handleOptOutChange}
                    checked={campaign?.messages[0].optOut || false}
                  />
                </Tooltip>

                <IconButton onClick={handleTemplateClick}>
                  <PlaylistAddIcon />
                </IconButton>
                <IconButton onClick={handleEmojiClick}>
                  <AddReactionIcon />
                </IconButton>
              </Box>
            </Box>
          </Box>
        </Grid>
        <MessagePreview campaign={campaign} />
      </Grid>
      <Grid
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          flexDirection: 'column',
          gap: 2,
        }}
      >
        <Typography sx={{ fontWeight: 'bold' }}>
          Tips on increasing message deliverability
        </Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button
            size="small"
            className={campaign?.status == 2 ? styles.adminButtonDisabled : styles.adminButton}
            onClick={() => handlePublish('0')}
          >
            SAVE DRAFT
          </Button>

          <Button
            startIcon={<ArrowForwardIcon />}
            size="small"
            onClick={() => {
              router.push('/campaigns/add-campaign/settings/?id=' + id);
            }}
            style={{ backgroundColor: 'black', color: 'white' }}
            className={styles.adminButton}
          >
            NEXT
          </Button>
        </Box>
      </Grid>
      <Popover
        open={showTemplate}
        anchorEl={anchorElTemplate}
        onClose={handleTemplateClick}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
      >
        <Box>
          <TemplateResponses
            setTemplateListBody={setTemplateListBody}
            templateListBody={templateListBody}
            postTemplateMessageListData={postTemplateMessageListData}
            handleMessage={(e: any) => setCampaign({ ...campaign, messages: [{ text: e }] })}
            handleTemplateClick={handleTemplateClick}
            from={'campaignTemplate'}
          />
        </Box>
      </Popover>
    </Grid>
  );
};

export default CreateCampaignScreen;
