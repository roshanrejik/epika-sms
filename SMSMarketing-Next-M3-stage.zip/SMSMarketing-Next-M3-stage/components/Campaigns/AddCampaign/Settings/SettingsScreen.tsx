'use client';
import React, { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import {
  Box,
  Button,
  Grid,
  Typography,
  Select,
  MenuItem,
  RadioGroup,
  FormControlLabel,
  Radio,
  InputLabel,
  IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import { useGetUserListName } from '@/hooks/api/user.hooks';
import { useGetTeamList } from '@/hooks/api/team.hooks';
import { useCampaign } from '@/context/CampaignContext';
import styles from '../../../../styles/admin.module.css';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import { usePostSaveCampaign } from '@/hooks/api/campaign.hooks';
import { CustomFormControl } from '@/constants/key';
import { campaignsData } from '@/utils/helpers';
import { usePostFollowUpList } from '@/hooks/api/follow-up.hooks';

const SettingsScreen = () => {
  const { availableHeight } = useScreenHeight();
  const { data: agentList } = useGetUserListName('');
  const { data: teamList } = useGetTeamList('');
  const searchParams = useSearchParams();
  const router = useRouter();
  const id = searchParams.get('id');
  const { campaign, setCampaign }: any = useCampaign();
  const { mutate: postSaveCampaign } = usePostSaveCampaign();
  const { mutate: postFollowUpList } = usePostFollowUpList();
  const [followUpList, setFollowUpList] = useState<any[]>([]);

  useEffect(() => {
    postFollowUpList(
      {
        page: '',
        limit: '',
        search: '',
      },
      {
        onSuccess: (data: any) => {
          setFollowUpList(data.data.data);
        },
      },
    );
  }, []);

  useEffect(() => {
    if (campaign.assignType === '2' && campaign.assignedTo?._id !== campaign.assignedTo) {
      const selectedAgent = agentList?.data?.data.find(
        (ele: any) => ele._id === campaign.assignedTo,
      );
      if (selectedAgent) {
        setCampaign((prevCampaign: any) => ({
          ...prevCampaign,
          assignedTo: selectedAgent,
        }));
      }
    } else if (campaign.assignType === '3' && campaign.assignedTo?.team !== campaign.assignedTo) {
      const selectedTeam = teamList?.data?.data.find((ele: any) => ele._id === campaign.assignedTo);
      if (selectedTeam) {
        setCampaign((prevCampaign: any) => ({
          ...prevCampaign,
          assignedTo: selectedTeam,
        }));
      }
    }
  }, [agentList?.data?.data, teamList?.data?.data, campaign.assignedTo, setCampaign]);
  const handlePublish = (schedule: any) => {
    postSaveCampaign(campaignsData({ ...campaign, id, schedule: schedule }), {
      onSuccess: () => {
        router.push('/campaigns/');
      },
      onError: (err: any) => {
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };

  const handleResponseTypeChange = (e: any) => {
    const { value } = e.target;
    setCampaign((prevCampaign: any) => ({
      ...prevCampaign,
      responsetype: value,
    }));
  };

  const handleAssignResponseChange = (e: any) => {
    const { value } = e.target;
    setCampaign((prevCampaign: any) => ({
      ...prevCampaign,
      assignType: value,
    }));
  };

  const handleFollowUpIdChange = (e: any) => {
    const { value } = e.target;
    setCampaign((prevCampaign: any) => ({
      ...prevCampaign,
      followUpId: value,
    }));
  };

  const handleAssignToChange = (e: any) => {
    const { value } = e.target;
    let assignedTo = agentList?.data?.data.find((ele: any) => ele._id === value);
    if (!assignedTo) {
      assignedTo = teamList?.data?.data.find((ele: any) => ele._id === value);
    }
    setCampaign((prevCampaign: any) => ({
      ...prevCampaign,
      assignedTo: assignedTo,
    }));
  };
  const handleRemoveFollowUp = () => {
    setCampaign((prevCampaign: any) => ({
      ...prevCampaign,
      followUpId: '', // Clear the selected follow-up
    }));
  };

  return (
    <div
      style={{
        height: availableHeight - 190,
        overflowY: 'scroll',
        overflowX: 'hidden',
        display: 'flex',
        justifyContent: 'center',
      }}
    >
      <Box sx={{ width: '80%' }}>
        <Grid container spacing={2} rowSpacing={5}>
          <Grid item xs={12} md={4} lg={4}>
            <Typography sx={{ fontWeight: 'bold', pb: 2 }}>Expected Response Type*</Typography>
            <CustomFormControl variant="outlined" sx={{ minWidth: 350 }}>
              <Select value={campaign.responsetype} onChange={handleResponseTypeChange} fullWidth>
                <MenuItem value="1">Not sure what I&apos;ll get</MenuItem>
                <MenuItem value="2">Numbers</MenuItem>
                <MenuItem value="3">Yes or No</MenuItem>
              </Select>
            </CustomFormControl>
          </Grid>
          <Grid item xs={12}>
            <Typography sx={{ fontWeight: 'bold' }}>Assign Responses</Typography>
            <RadioGroup
              value={campaign.assignType}
              onChange={handleAssignResponseChange}
              sx={{ display: 'flex', flexDirection: 'row', gap: 2 }}
            >
              <FormControlLabel
                value="1"
                control={
                  <Radio
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)',
                      },
                    }}
                  />
                }
                label="Do nothing"
              />
              <FormControlLabel
                value="2"
                control={
                  <Radio
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)',
                      },
                    }}
                  />
                }
                label={
                  <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Typography>Assign response to a team member</Typography>
                    </Box>
                    <CustomFormControl variant="outlined" sx={{ minWidth: 350, mt: 2 }}>
                      <InputLabel id="assign-to-label">Select Team Member</InputLabel>
                      <Select
                        labelId="assign-to-label"
                        value={campaign.assignedTo?._id}
                        onChange={handleAssignToChange}
                        fullWidth
                        disabled={campaign.assignType !== '2'}
                        label="Select Team Member"
                      >
                        {agentList?.data?.data.map((agent: any) => (
                          <MenuItem key={agent._id} value={agent._id}>
                            {agent.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </CustomFormControl>
                  </Box>
                }
              />

              <FormControlLabel
                value="3"
                control={
                  <Radio
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)',
                      },
                    }}
                  />
                }
                label={
                  <Box>
                    <Typography>Assign response to a team (round-robin)</Typography>
                    <CustomFormControl variant="outlined" sx={{ minWidth: 350, mt: 2 }}>
                      <InputLabel id="assign-to-team-label">Select Team</InputLabel>
                      <Select
                        labelId="assign-to-team-label"
                        value={campaign.assignedTo?._id}
                        onChange={handleAssignToChange}
                        fullWidth
                        label="Select Team"
                        disabled={campaign.assignType !== '3'}
                      >
                        {teamList?.data?.data.map((team: any) => (
                          <MenuItem key={team._id} value={team._id}>
                            {team.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </CustomFormControl>
                  </Box>
                }
              />
            </RadioGroup>
          </Grid>
          <Grid item xs={12} md={4} lg={4}>
            <Typography sx={{ fontWeight: 'bold', pb: 2 }}>Attach Follow-Up</Typography>
            <CustomFormControl
              variant="outlined"
              sx={{ display: 'flex', alignItems: 'center', minWidth: 350 }}
            >
              <InputLabel labelId="attach-followup-label">Select Follow-Up</InputLabel>
              <Select
                value={campaign.followUpId}
                labelId="attach-followup-label"
                onChange={handleFollowUpIdChange}
                fullWidth
                sx={{ flexGrow: 1 }}
                endAdornment={
                  campaign.followUpId && (
                    <IconButton onClick={() => handleRemoveFollowUp()}>
                      <CloseIcon />
                    </IconButton>
                  )
                }
              >
                {followUpList.map((followUp: any) => (
                  <MenuItem key={followUp._id} value={followUp._id}>
                    {followUp.name}
                  </MenuItem>
                ))}
              </Select>
            </CustomFormControl>
          </Grid>

          {/* <Grid item xs={12}>
            <Typography sx={{ fontWeight: 'bold' }}>From Number</Typography>
            <RadioGroup
              value={fromNumber}
              onChange={handleFromNumberChange}
              sx={{ display: 'flex', flexDirection: 'row', gap: 2 }}
            >
              <FormControlLabel
                value="default"
                control={
                  <Radio
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)',
                      },
                    }}
                  />
                }
                label={
                  <Typography sx={{ maxWidth: '300px', ml: 2 }} variant="body2">
                    <Typography variant="body1" sx={{ fontWeight: '500' }}>
                      Default
                    </Typography>
                    Messages will be sent from a company number
                  </Typography>
                }
                sx={{ display: 'flex', alignItems: 'center' }}
              />
              <FormControlLabel
                value="dedicatedNumber"
                control={
                  <Radio
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)',
                      },
                    }}
                  />
                }
                label={
                  <Typography sx={{ maxWidth: '300px', ml: 2 }} variant="body2">
                    <Typography variant="body1" sx={{ fontWeight: '500' }}>
                      Dedicated Team Member Number
                    </Typography>
                    Message sent from dedicated number if available, otherwise, we will use the
                    default number on the account
                  </Typography>
                }
                sx={{ display: 'flex', alignItems: 'center' }}
              />
              <FormControlLabel
                value="dedicatedTeamNumber"
                control={
                  <Radio
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)',
                      },
                    }}
                  />
                }
                label={
                  <Typography sx={{ maxWidth: '300px', ml: 2 }} variant="body2">
                    <Typography variant="body1" sx={{ fontWeight: '500' }}>
                      Dedicated Team Number
                    </Typography>
                    Message sent from dedicated team member of the last team to which the team
                    member was assigned
                  </Typography>
                }
                sx={{ display: 'flex', alignItems: 'center' }}
              />
            </RadioGroup>
          </Grid> */}
          <Grid item xs={12} sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
              <Button
                size="small"
                onClick={() => handlePublish('0')}
                className={campaign?.status == 2 ? styles.adminButtonDisabled : styles.adminButton}
                disabled={campaign?.status == 2}
              >
                SAVE DRAFT
              </Button>

              <Button
                startIcon={<ArrowForwardIcon />}
                size="small"
                onClick={() =>
                  router.push('/campaigns/add-campaign/recipients-api-toggle/?id=' + id)
                }
                style={{ backgroundColor: 'black', color: 'white' }}
                className={styles.adminButton}
              >
                NEXT
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </div>
  );
};

export default SettingsScreen;
