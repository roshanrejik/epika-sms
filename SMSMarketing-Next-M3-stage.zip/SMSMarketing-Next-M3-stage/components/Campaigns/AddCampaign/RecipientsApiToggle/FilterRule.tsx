// FilterComponent.js
import React from 'react';
import { Box, Button, Typography, IconButton } from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import { useGetCustomerPropertyKeys } from '@/hooks/api/customer.hooks';
import FilterGroup from './FilterGroup';

interface Filter {
  field: string;
  value: string;
}

const FilterComponent: React.FC<{
  filterRules: { or: Filter[] }[];
  setFilterRules: (filterRules: { or: Filter[] }[]) => void;
}> = ({ filterRules, setFilterRules }) => {
  const { data: propertyKeys } = useGetCustomerPropertyKeys();

  const handleFilterChange = (
    event: React.ChangeEvent<{ value: unknown }>,
    groupIndex: number,
    filterIndex: number,
    key: 'field' | 'value',
  ) => {
    const newFilterGroups = [...filterRules];
    newFilterGroups[groupIndex].or[filterIndex][key] = event.target.value as string;
    setFilterRules(newFilterGroups);
  };

  const handleAddFilter = (groupIndex: number) => {
    const newFilterGroups = [...filterRules];

    // Ensure that the 'or' array is initialized
    if (!newFilterGroups[groupIndex].or) {
      newFilterGroups[groupIndex].or = [];
    }

    newFilterGroups[groupIndex].or.push({ field: '', value: '' });
    setFilterRules(newFilterGroups);
  };

  const handleRemoveFilter = (groupIndex: number, filterIndex: number) => {
    const newFilterGroups = [...filterRules];
    newFilterGroups[groupIndex].or.splice(filterIndex, 1);
    setFilterRules(newFilterGroups);
  };

  const handleAddGroup = () => {
    setFilterRules([...filterRules, { or: [{ field: '', value: '' }] }]);
  };

  const handleRemoveGroup = (groupIndex: number) => {
    const newFilterGroups = [...filterRules];
    newFilterGroups.splice(groupIndex, 1);
    setFilterRules(newFilterGroups);
  };

  return (
    <Box sx={{ padding: '0px' }}>
      {filterRules.map((filterGroup, groupIndex) => (
        <Box key={groupIndex} mb={2} border="1px solid #ddd" borderRadius="4px" p={2}>
          <Box display="flex" alignItems="center" justifyContent="space-between">
            <Typography variant="body2" mb={1}>
              {groupIndex > 0
                ? 'Or people matching these filters'
                : 'People matching these filters'}
            </Typography>
            <IconButton onClick={() => handleRemoveGroup(groupIndex)} color="error">
              <RemoveCircleOutlineIcon />
            </IconButton>
          </Box>
          <FilterGroup
            filters={filterGroup.or}
            handleAddFilter={handleAddFilter}
            handleRemoveFilter={handleRemoveFilter}
            handleFilterChange={handleFilterChange}
            groupIndex={groupIndex}
            propertyKeys={propertyKeys?.data?.data || []}
          />
        </Box>
      ))}
      <Button
        onClick={handleAddGroup}
        sx={{ color: 'var(--epika-primary-color)' }}
        startIcon={<AddCircleOutlineIcon />}
      >
        OR GROUP
      </Button>
    </Box>
  );
};

export default FilterComponent;
