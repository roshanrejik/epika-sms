import React from 'react';
import { Box, Button, IconButton } from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import FilterItem from './FilterItem';

interface Filter {
  field: string;
  value: string;
}

interface FilterGroupProps {
  filters: Filter[];
  handleAddFilter: (groupIndex: number) => void;
  handleRemoveFilter: (groupIndex: number, filterIndex: number) => void;
  handleFilterChange: (
    event: React.ChangeEvent<{ value: unknown }>,
    groupIndex: number,
    filterIndex: number,
    key: 'field' | 'value',
  ) => void;
  groupIndex: number;
  propertyKeys: any;
}

const FilterGroup: React.FC<FilterGroupProps> = ({
  filters,
  handleAddFilter,
  handleRemoveFilter,
  handleFilterChange,
  groupIndex,
  propertyKeys,
}) => {
  return (
    <Box mb={2}>
      {filters?.map((filter, filterIndex) => (
        <Box key={filterIndex} display="flex" alignItems="center" mb={1}>
          <FilterItem
            field={filter.field}
            value={filter.value}
            handleChange={(e, key) => handleFilterChange(e, groupIndex, filterIndex, key)}
            propertyKeys={propertyKeys}
            groupIndex={groupIndex}
            filterIndex={filterIndex}
          />
          <IconButton onClick={() => handleRemoveFilter(groupIndex, filterIndex)} size="small">
            <RemoveCircleOutlineIcon />
          </IconButton>
        </Box>
      ))}
      <Button
        startIcon={<AddCircleOutlineIcon />}
        onClick={() => handleAddFilter(groupIndex)}
        size="small"
        sx={{ color: 'var(--epika-primary-color)' }}
      >
        Add Filter
      </Button>
    </Box>
  );
};

export default FilterGroup;
