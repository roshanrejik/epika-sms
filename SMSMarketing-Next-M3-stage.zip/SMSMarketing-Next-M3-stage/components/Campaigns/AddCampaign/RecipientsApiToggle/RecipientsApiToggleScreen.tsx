'use client';

import { showToast } from '@/components/common/Toast/defaultToastOptions';
import { useCampaign } from '@/context/CampaignContext';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import { usePostSaveCampaign } from '@/hooks/api/campaign.hooks';
import { usePostCustomerSelectedAudience } from '@/hooks/api/customer.hooks';
import { campaignsData } from '@/utils/helpers';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { Box, Button, Grid, Switch, Typography } from '@mui/material';
import { useRouter, useSearchParams } from 'next/navigation';
import React, { useEffect } from 'react';
import styles from '../../../../styles/admin.module.css';
import FilterComponent from './FilterRule';

const RecipientsApiToggleScreen = () => {
  const { mutate: postCustomerSelectedAudience, isPending } = usePostCustomerSelectedAudience();
  const { mutate: postSaveCampaign } = usePostSaveCampaign();
  const { availableHeight } = useScreenHeight();

  const searchParams = useSearchParams();
  const router = useRouter();
  const id = searchParams.get('id');
  const { campaign, setCampaign } = useCampaign();

  useEffect(() => {
    // Remove filters with empty 'value' and create a new filtered data object
    const filteredData = campaignsData({
      removeUndeliveredCustomers: campaign.removeUndeliveredCustomers,
      filterRule: campaign?.filterRule
        ?.map((group) => ({
          ...group,
          or: group.or?.filter(
            (filter: any) => filter.field.trim() !== '' && filter.value.trim() !== '',
          ),
        }))
        .filter((group) => group.or?.length > 0), // Ensure to remove empty groups
    });

    // Check if there are any filters left after filtering out empty values
    const hasValidFilters = filteredData?.filterRule?.length > 0;

    if (campaign.filterRule?.[0] === 'all') {
      filteredData.filterRule = ['all'];
    } else if (!hasValidFilters) {
      filteredData.filterRule = [];
    }

    postCustomerSelectedAudience(filteredData, {
      onSuccess: (res) => {
        setCampaign((prevCampaign: any) => ({
          ...prevCampaign,
          recipients: res.data.count,
        }));
      },
    });
  }, [campaign.removeUndeliveredCustomers, campaign.filterRule]);

  const handlePublish = (schedule: any) => {
    postSaveCampaign(campaignsData({ ...campaign, id, schedule: schedule }), {
      onSuccess: () => {
        router.push('/campaigns/');
      },
      onError: (err: any) => {
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };

  const handleSwitchChange = (key: string) => {
    if (key === 'all') {
      if (JSON.stringify(campaign.filterRule) === JSON.stringify(['all'])) {
        setCampaign((prevCampaign: any) => ({
          ...prevCampaign,
          filterRule: campaign.previousFilterRule,
        }));
      } else {
        setCampaign((prevCampaign: any) => ({
          ...prevCampaign,
          filterRule: ['all'],
          previousFilterRule: campaign.filterRule,
        }));
      }
    } else {
      setCampaign((prevCampaign: any) => ({
        ...prevCampaign,
        [key]: !prevCampaign[key],
      }));
    }
  };

  console.log(campaign?.filterRule, 'campaign?.filterRulecampaign?.filterRule');

  return (
    <Grid
      sx={{
        overflowY: 'auto',
        height: availableHeight - 300,
      }}
    >
      <Grid sx={{ display: 'flex', flexDirection: 'row' }}>
        <Box
          sx={{
            flexGrow: 1,
            margin: '20px',
          }}
        >
          <Box sx={{ display: 'flex', flexDirection: 'row' }}>
            <Box sx={{ fontWeight: 'bold', flexGrow: 1, marginRight: '10px' }}>
              Include people matching these filters
            </Box>
            <Box sx={{ fontWeight: 'bold' }}>Remove undeliverable customers</Box>
            <Switch
              checked={!!campaign?.removeUndeliveredCustomers}
              onChange={() => handleSwitchChange('removeUndeliveredCustomers')}
              sx={{
                '& .MuiSwitch-switchBase.Mui-checked': {
                  color: 'var(--epika-primary-color)',
                },
                '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                  backgroundColor: 'var(--epika-primary-color)',
                },
              }}
            />
          </Box>
          <Box sx={{ display: 'flex', flexDirection: 'row' }}>
            <Box sx={{ flexGrow: 1 }}>Send To All Customers</Box>
            <Switch
              checked={campaign?.filterRule?.[0] === 'all' || false}
              onChange={() => handleSwitchChange('all')}
              sx={{
                '& .MuiSwitch-switchBase.Mui-checked': {
                  color: 'var(--epika-primary-color)',
                },
                '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                  backgroundColor: 'var(--epika-primary-color)',
                },
              }}
            />
          </Box>

          {campaign?.filterRule?.[0] === 'all' ? null : (
            <FilterComponent
              filterRules={campaign?.filterRule || []}
              setFilterRules={(newFilterGroups: any) =>
                setCampaign((prevCampaign: any) => ({
                  ...prevCampaign,
                  filterRule: newFilterGroups,
                }))
              }
            />
          )}
        </Box>
        <Box
          sx={{ backgroundColor: 'lightgrey', padding: '40px', height: '400px', overflowY: 'auto' }}
        >
          <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
            Audience Details
          </Typography>
          {campaign?.filterRule?.length === 1 && campaign.filterRule[0] === 'all'
            ? null
            : campaign?.filterRule?.map((condition, index) => {
                const conditionType = Object.keys(condition)[0];
                return (
                  <div key={index}>
                    <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                      {index != 0
                        ? conditionType.charAt(0).toUpperCase() + conditionType.slice(1)
                        : null}
                    </Typography>
                    <ul>
                      {condition[conditionType]?.map((item, idx) => (
                        <li key={idx}>
                          {item.field}: {item.value}
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}

          <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
            Selected Audience : {isPending ? '....' : campaign?.recipients}
          </Typography>
        </Box>
      </Grid>
      <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', mt: 2 }}>
        <Button
          size="small"
          className={campaign?.status == 2 ? styles.adminButtonDisabled : styles.adminButton}
          onClick={() => handlePublish('0')}
        >
          SAVE DRAFT
        </Button>

        <Button
          startIcon={<ArrowForwardIcon />}
          size="small"
          onClick={() => {
            router.push('/campaigns/add-campaign/schedule/?id=' + id);
          }}
          style={{ backgroundColor: 'black', color: 'white' }}
          className={styles.adminButton}
        >
          NEXT
        </Button>
      </Box>
    </Grid>
  );
};

export default RecipientsApiToggleScreen;
