import React from 'react';
import { CustomFormControl } from '@/constants/key';
import { Select, MenuItem } from '@mui/material';
import { useGetCustomerPropertyValues } from '@/hooks/api/customer.hooks';

interface FilterItemProps {
  field: string;
  value: string;
  handleChange: (event: React.ChangeEvent<{ value: unknown }>, key: 'field' | 'value') => void;
  propertyKeys: any[];
  groupIndex: number;
  filterIndex: number;
}

const FilterItem: React.FC<FilterItemProps> = ({ field, value, handleChange, propertyKeys }) => {
  const { data: propertyValues } = useGetCustomerPropertyValues(field);

  return (
    <>
      <CustomFormControl variant="outlined">
        <Select
          value={field}
          onChange={(e) => handleChange(e, 'field')}
          variant="outlined"
          size="small"
          sx={{ mr: 1, minWidth: 200 }}
        >
          {propertyKeys.map((ele: any) => (
            <MenuItem key={ele} value={ele}>
              {ele}
            </MenuItem>
          ))}
        </Select>
      </CustomFormControl>
      <CustomFormControl variant="outlined">
        <Select
          value={value}
          onChange={(e) => handleChange(e, 'value')}
          variant="outlined"
          size="small"
          sx={{ mr: 1, minWidth: 200 }}
          disabled={!field}
        >
          {propertyValues?.data?.data.map((ele: any) => (
            <MenuItem key={ele} value={ele}>
              {ele}
            </MenuItem>
          ))}
        </Select>
      </CustomFormControl>
    </>
  );
};

export default FilterItem;
