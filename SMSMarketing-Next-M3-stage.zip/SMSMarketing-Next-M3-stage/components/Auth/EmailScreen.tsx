'use client';
import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { Box, Button, CircularProgress, Grid, Typography } from '@mui/material';
import { useRouter } from 'next/navigation';
import FormProvider from '@/context/FormProvider';
import RHFTextField from '../common/TextField/RHFTextField';
import { showToast } from '../common/Toast/defaultToastOptions';
import { emailValidationSchema } from '@/validations/Auth/AuthSchema';
import { useUserVerifyMailID } from '@/hooks/api/user.hooks';
import cookies from '@/utils/cookies';
import Image from 'next/image';
import Logo from '@/assets/EpikLogoWhitebackground.png';
import { btnstyle } from '@/constants/key';
import styles from './LoginScreen.module.css';

const EmailScreen = () => {
  const router = useRouter();
  const { mutate: submitEmailVerify, isPending } = useUserVerifyMailID();

  const defaultValues = {
    email: '',
  };

  const methods = useForm({
    defaultValues,
    resolver: yupResolver(Yup.object(emailValidationSchema)),
  });

  const onSuccess = (res: any) => {
    router.push('/auth/password');
    cookies.set('email', res.data.token, { path: '/' });
  };

  const onError = (err: any) => {
    showToast('error', err.response?.data?.message || 'Something went wrong!', {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  };

  const onSubmit = (data: any) => {
    submitEmailVerify(data, { onSuccess, onError });
  };

  return (
    <Grid container className={styles.loginScreenContainer}>
      <Grid item className={styles.loginScreenContainerImageItem}>
        <Image src={Logo} alt="logo" width={393} height={97} />
      </Grid>
      <Grid item className={styles.loginScreenContainerFormItem}>
        <Box sx={{ width: '100%' }}>
          <Typography
            sx={{
              fontSize: 'var(--epika-primary-header-size)',
              fontWeight: '700',
            }}
          >
            Sign In
          </Typography>

          <FormProvider methods={methods} onSubmit={methods.handleSubmit(onSubmit)}>
            <RHFTextField fullWidth label="Email Address" name="email" type="email" />
            <Button
              type="submit"
              color="primary"
              variant="contained"
              style={btnstyle}
              className={styles.loginScreenButton}
              disabled={isPending}
              fullWidth
            >
              {isPending ? <CircularProgress size={22} sx={{ color: 'white' }} /> : 'Submit'}
            </Button>
          </FormProvider>
        </Box>
      </Grid>
    </Grid>
  );
};

export default EmailScreen;
