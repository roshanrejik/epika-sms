'use client';
import { FormProvider, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { Box, Button, CircularProgress, Grid, Typography } from '@mui/material';
import { useRouter } from 'next/navigation';
import React from 'react';
import { useDispatch } from 'react-redux';
import { showToast } from '../common/Toast/defaultToastOptions';
import { login, setUserData } from '@/lib/features/userSlice';
import cookies from '@/utils/cookies';
import RHFTextField from '../common/TextField/RHFTextField';
import { passwordValidationSchema } from '@/validations/Auth/AuthSchema';
import { useUserLogin } from '@/hooks/api/user.hooks';
import Image from 'next/image';
import Logo from '@/assets/EpikLogoWhitebackground.png';
import { btnstyle } from '@/constants/key';
import styles from './LoginScreen.module.css';

const PasswordScreen = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { mutate: submitLogin, isPending } = useUserLogin();

  const defaultValues = {
    password: '',
  };

  const methods = useForm({
    defaultValues,
    resolver: yupResolver(Yup.object(passwordValidationSchema)),
  });

  const onSuccess = (res: any) => {
    const { data, accessToken, refreshToken } = res.data;
    cookies.set('accessToken', accessToken, { path: '/' });
    cookies.set('refreshToken', refreshToken, { path: '/' });
    dispatch(setUserData(data));
    dispatch(login());
    router.push('/dashboard/');
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  };

  const onSubmit = (data: any) => {
    const payload = {
      token: cookies.get('email'),
      password: btoa(data.password),
    };
    submitLogin(payload, { onSuccess, onError });
  };

  return (
    <Grid container className={styles.loginScreenContainer}>
      <Grid item className={styles.loginScreenContainerImageItem}>
        <Image src={Logo} alt="logo" width={393} height={97} />
      </Grid>
      <Grid item className={styles.loginScreenContainerFormItem}>
        <Box sx={{ width: '100%' }}>
          <Typography
            sx={{
              fontSize: 'var(--epika-primary-header-size)',
              fontWeight: '700',
            }}
          >
            Sign In
          </Typography>

          <FormProvider {...methods}>
            <form onSubmit={methods.handleSubmit(onSubmit)}>
              <RHFTextField
                fullWidth
                label="Password"
                name="password"
                type="password"
                variant="outlined"
              />
              <Button
                type="submit"
                color="primary"
                variant="contained"
                style={btnstyle}
                className={styles.loginScreenButton}
                disabled={isPending}
                fullWidth
              >
                {isPending ? <CircularProgress size={22} sx={{ color: 'white' }} /> : 'Submit'}
              </Button>
            </form>
          </FormProvider>
        </Box>
      </Grid>
    </Grid>
  );
};

export default PasswordScreen;
