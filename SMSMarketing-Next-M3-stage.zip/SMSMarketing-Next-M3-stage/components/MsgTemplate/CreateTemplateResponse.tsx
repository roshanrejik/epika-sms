import React, { useEffect, useState } from 'react';
import {
  Button,
  Switch,
  FormControlLabel,
  Box,
  Typography,
  Container,
  Paper,
  List,
  ListItem,
  CircularProgress,
} from '@mui/material';
import { btnstyle, StyledTextField } from '@/constants/key';
import styles from '../../styles/admin.module.css';
import { usePostCannedMessageSave } from '@/hooks/api/canned.hooks';

const CreateTemplateResponse = ({
  id = null,
  initialName = '',
  initialText = '',
  initialShared = false,
  customerFields,
  handleClose,
  onSave,
  onError,
}: any) => {
  const [shared, setShared] = useState(initialShared);
  const [responseName, setResponseName] = useState(initialName);
  const [responseText, setResponseText] = useState(initialText);
  const [showPopup, setShowPopup] = useState(false);
  const [cursorPosition, setCursorPosition] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { mutate: saveTemplateMessage, isPending } = usePostCannedMessageSave();

  useEffect(() => {
    setResponseName(initialName);
    setResponseText(initialText);
    setShared(initialShared);
  }, [initialName, initialText, initialShared]);

  const handleSave = () => {
    setIsSubmitted(true);
    if (!responseName || !responseText) {
      return;
    }

    const payload = {
      name: responseName,
      text: responseText,
      shared: shared,
      campaignTemplate: true,
      _id: id ? id : '',
    };
    saveTemplateMessage(payload, {
      onSuccess: () => {
        onSave(payload);
        handleClose();
      },
      onError: onError,
    });
  };

  const handleTextChange = (e: any) => {
    const value = e.target.value;
    setResponseText(value);
    const position = e.target.selectionStart;
    setCursorPosition(position);

    if (value.slice(position - 2, position) === '{{') {
      setShowPopup(true);
    } else {
      setShowPopup(false);
    }
  };

  const handleSuggestionClick = (suggestion: any) => {
    const textBeforeCursor = responseText.slice(0, cursorPosition - 2); // Remove the {{ before cursor
    const textAfterCursor = responseText.slice(cursorPosition);

    const newText = `${textBeforeCursor}{{${suggestion}}}${textAfterCursor}`;
    setResponseText(newText);
    setShowPopup(false);
  };

  return (
    <Container maxWidth="sm">
      <Box display="flex" flexDirection="column" mt={4}>
        <Typography variant="h6">{id ? 'Edit' : 'Create'} Template </Typography>
        <StyledTextField
          label="Enter template  name"
          value={responseName}
          onChange={(e) => setResponseName(e.target.value)}
          margin="normal"
          fullWidth
          error={isSubmitted && !responseName}
          helperText={isSubmitted && !responseName ? 'Name is required' : ''}
        />
        <FormControlLabel
          control={
            <Switch
              checked={shared}
              onChange={(e) => setShared(e.target.checked)}
              name="shared"
              color="primary"
              sx={{
                '& .MuiSwitch-switchBase.Mui-checked': {
                  color: 'var(--epika-primary-color)',
                },
                '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                  backgroundColor: 'var(--epika-primary-color)',
                },
              }}
            />
          }
          label="Shared"
        />
        <Box position="relative">
          {showPopup && (
            <Paper style={{ position: 'absolute', top: '-70%', left: 60, zIndex: 1 }}>
              <List>
                {customerFields.map((suggestion: any) => (
                  <ListItem
                    button
                    key={suggestion}
                    onClick={() => handleSuggestionClick(suggestion)}
                  >
                    {suggestion}
                  </ListItem>
                ))}
              </List>
            </Paper>
          )}
          <StyledTextField
            label="Text"
            value={responseText}
            onChange={handleTextChange}
            multiline
            rows={4}
            margin="normal"
            fullWidth
            error={isSubmitted && !responseText}
            helperText={isSubmitted && !responseText ? 'Text is required' : ''}
          />
        </Box>
        <Button
          style={{ ...btnstyle, color: 'white' }}
          className={styles.adminButtonBottom}
          onClick={handleSave}
        >
          {isPending ? <CircularProgress size={22} sx={{ color: 'white' }} /> : 'Save'}
        </Button>
      </Box>
    </Container>
  );
};

export default CreateTemplateResponse;
