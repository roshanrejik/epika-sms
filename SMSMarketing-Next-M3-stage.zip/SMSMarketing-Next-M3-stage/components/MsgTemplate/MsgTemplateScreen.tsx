'use client';
import { Box, Button, InputAdornment, Modal } from '@mui/material';
import React, { useEffect, useState } from 'react';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import styles from '../../styles/admin.module.css';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import { StyledTextField } from '@/constants/key';
import PeopleOutlineOutlinedIcon from '@mui/icons-material/PeopleOutlineOutlined';
import CreateTemplateResponse from './CreateTemplateResponse';
import { showToast } from '../common/Toast/defaultToastOptions';
import TemplateTable from '../Tables/TemplateTable';
import { usePostCannedMessageList, usePostCannedMessageSave } from '@/hooks/api/canned.hooks';

const TemplateScreen = () => {
  const [openModal, setOpenModal] = useState(false);
  const { mutate: saveTemplateMessage } = usePostCannedMessageSave();
  const { mutate: postTemplateMessageList } = usePostCannedMessageList();
  const [templateTableData, setTemplateTableData] = useState([]);
  const [customerFields, setCustomerFields] = useState([]);
  const [totalCount, setTotalCount] = useState(0);

  const [templateListBody, setTemplateListBody] = useState({
    page: 0,
    limit: 10,
    search: '',
    shared: '',
    campaignTemplate: true,
  });
  const onError = (err: any) =>
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  useEffect(() => {
    const payload = {
      ...templateListBody,
      page: templateListBody.page + 1,
      campaignTemplate: true,
    };
    postTemplateMessageList(payload, {
      onSuccess: (res: any) => {
        setTemplateTableData(res.data.data);
        setTotalCount(res.data.totalCount);
        setCustomerFields(res.data.customerFields);
      },
      onError: onError,
    });
  }, [templateListBody]);

  const handleAddMemberClick = () => {
    setOpenModal(true);
  };

  const handleClose = () => {
    postTemplateMessageList(
      { ...templateListBody, page: 1 },
      {
        onSuccess: (res: any) => {
          setTemplateTableData(res.data.data);
          setCustomerFields(res.data.customerFields);
          setOpenModal(false);
        },
        onError: (err: any) => {
          onError(err);
          setOpenModal(false);
        },
      },
    );
  };

  const handleToggleProperty = (e: any, id: string, status: boolean) => {
    e.preventDefault();
    setTemplateTableData((prevState: any) =>
      prevState.map((item: any) => (item._id === id ? { ...item, shared: !status } : item)),
    );
    saveTemplateMessage({ _id: id, shared: !status }, { onError: onError });
  };

  return (
    <Box sx={{ margin: '0px 0px', width: '100%' }}>
      <Box sx={{ margin: '20px', display: 'flex', justifyContent: 'space-between' }}>
        <Box sx={{ display: 'flex', columnGap: '10px' }}>
          <Button
            startIcon={<AddOutlinedIcon />}
            size="small"
            onClick={handleAddMemberClick}
            className={styles.adminButton}
          >
            ADD Template
          </Button>
          <Button
            startIcon={<PeopleOutlineOutlinedIcon />}
            size="small"
            disabled
            sx={{
              color: 'black',
              borderRadius: '30px',
              padding: '6px 20px',
              textTransform: 'none',
              '&:disabled': {
                bgcolor: 'white',
                color: 'black',
              },
            }}
          >
            {templateTableData?.length + ' Template '}
          </Button>
        </Box>

        <StyledTextField
          id="outlined-basic"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchOutlinedIcon />
              </InputAdornment>
            ),
          }}
          placeholder="Search template "
          value={templateListBody.search}
          onChange={(e) => setTemplateListBody({ ...templateListBody, search: e.target.value })}
          variant="outlined"
        />

        <Modal
          open={openModal}
          onClose={() => setOpenModal(false)}
          aria-labelledby="modal-title"
          aria-describedby="modal-description"
        >
          <Box
            sx={{
              p: 2,
              maxWidth: '550px',
              maxHeight: '500px',
              borderRadius: '10px',
              margin: 'auto',
              mt: '10%',
              bgcolor: 'background.paper',
            }}
          >
            <CreateTemplateResponse
              customerFields={customerFields}
              initialName={''}
              initialText={''}
              initialShared={false}
              onSave={() => {
                handleClose();
                setTotalCount((prev) => prev + 1);
              }}
              handleClose={handleClose}
              onError={onError}
            />
          </Box>
        </Modal>
      </Box>
      <Box sx={{ margin: '25px 25px' }}>
        <TemplateTable
          data={templateTableData}
          setData={setTemplateTableData}
          handleToggleProperty={handleToggleProperty}
          totalCount={totalCount}
          setTotalCount={setTotalCount}
          templateListBody={templateListBody}
          customerFields={customerFields}
          setTemplateListBody={setTemplateListBody}
        />
      </Box>
    </Box>
  );
};

export default TemplateScreen;
