import React from 'react';
import {
  List,
  ListItem,
  ListItemText,
  IconButton,
  Typography,
  Box,
  InputAdornment,
} from '@mui/material';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import { Close as CloseIcon } from '@mui/icons-material';
import { StyledTextField } from '@/constants/key';
import SettingsIcon from '@mui/icons-material/Settings';
import { useRouter } from 'next/navigation';
import { replacePlaceholders } from '@/utils/helpers';

const TemplateResponses = ({
  postTemplateMessageListData,
  templateListBody,
  handleMessage,
  setTemplateListBody,
  customer,
  handleTemplateClick,
  from,
}: any) => {
  const router = useRouter();
  const handleSearchChange = (event: any) => {
    setTemplateListBody((prev: any) => ({ ...prev, search: event.target.value }));
  };

  const filteredMessages = postTemplateMessageListData.filter((response: any) =>
    response.name.toLowerCase().includes(templateListBody.search.toLowerCase()),
  );

  return (
    <Box sx={{ minWidth: 400, padding: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h6">Template </Typography>
        <IconButton onClick={handleTemplateClick}>
          <CloseIcon />
        </IconButton>
      </Box>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <IconButton onClick={() => router.push('/msgtemplate/')}>
          <SettingsIcon /> <Typography variant="body1">Manage </Typography>
        </IconButton>
      </Box>
      <StyledTextField
        label="Search"
        variant="outlined"
        fullWidth
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchOutlinedIcon />
            </InputAdornment>
          ),
        }}
        value={templateListBody.search}
        onChange={handleSearchChange}
        sx={{ marginTop: 2, marginBottom: 2 }}
      />
      <List sx={{ maxHeight: '300px', overflow: 'auto' }}>
        {filteredMessages.length > 0 ? (
          filteredMessages.map((response: any) => (
            <ListItem
              key={response._id}
              sx={{
                cursor: 'pointer',
                '&:hover': {
                  backgroundColor: 'rgba(0, 0, 0, 0.08)', // Light grey background on hover
                },
              }}
            >
              <ListItemText
                primary={response.name}
                secondary={response.text}
                onClick={() => {
                  from == 'campaignTemplate'
                    ? handleMessage(response.text)
                    : handleMessage(replacePlaceholders(response.text, customer));
                  handleTemplateClick();
                }}
              />
            </ListItem>
          ))
        ) : (
          <Typography variant="body1" sx={{ padding: 2, textAlign: 'center' }}>
            No results found
          </Typography>
        )}
      </List>
    </Box>
  );
};

export default TemplateResponses;
