// Plugins.tsx
'use client';

import RHFTextField from '@/components/common/TextField/RHFTextField';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import FormProvider from '@/context/FormProvider';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { Box, Button, CircularProgress, Grid, Typography } from '@mui/material';
import React, { useEffect, useState, useRef } from 'react';
import styles from '../../styles/admin.module.css';
import {
  useGetWebPluginDetails,
  usePostUploadWebPluginImage,
  usePostWebPluginSave,
} from '@/hooks/api/web-plugin.hooks';
import { WebPluginSchema } from '@/validations/Auth/WebPluginsSchema';
import Image from 'next/image';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

const Plugins: React.FC = () => {
  const { data: pluginsDetails, isSuccess } = useGetWebPluginDetails();
  const { mutate: uploadImage } = usePostUploadWebPluginImage();
  const { mutate: saveForm, isPending } = usePostWebPluginSave();
  const [uploadedImage, setUploadedImage] = useState<string | ArrayBuffer | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { availableHeight } = useScreenHeight();
  const defaultValues = {
    text: '',
    contactName: '',
    image: null,
  };

  const methods = useForm({
    resolver: yupResolver(WebPluginSchema),
    defaultValues,
  });

  useEffect(() => {
    if (isSuccess && pluginsDetails) {
      methods.reset({
        text: pluginsDetails.data?.data?.text || '',
        contactName: pluginsDetails.data?.data?.contactName || '',
        image: pluginsDetails.data?.data?.image,
      });
      setUploadedImage(pluginsDetails.data?.data?.image);
    }
  }, [isSuccess, pluginsDetails, methods]);

  const onSuccess = (res: any) => {
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  };

  const onSubmit = (data: any) => {
    const payload = { ...pluginsDetails?.data?.data, ...data };
    delete payload.image; // Remove the image key from the payload
    saveForm(payload, { onSuccess, onError });
  };

  const handleUpload = (files: File[]) => {
    const file = files[0];

    if (file) {
      if (file.size > 1024 * 1024) {
        // Example file size limit (1MB)
        showToast('error', 'File size exceeds the limit', {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
        return;
      }

      const reader = new FileReader();

      reader.onloadend = () => {
        setUploadedImage(reader.result);
        const formData = new FormData();
        formData.append('files', file);
        uploadImage(formData, {
          onSuccess: (res: any) => {
            const { data } = res;
            methods.setValue('image', data[0].filename);
            methods.trigger('image');

            // Call saveForm after setting the image value
            const payload = { ...pluginsDetails?.data?.data, ...methods.getValues() };
            saveForm(payload, { onSuccess, onError });
          },
          onError,
        });
      };

      reader.readAsDataURL(file);
    }
  };

  const handleImageClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <FormProvider methods={methods} onSubmit={methods.handleSubmit(onSubmit)}>
      <Grid
        container
        spacing={3}
        mt={7}
        className={styles.adminAgentsTable}
        style={{ overflow: 'scroll', height: availableHeight - 60 + 'px' }}
      >
        <Grid item xs={12} className={styles.adminAgentsTableHeader}>
          <Typography
            sx={{
              fontSize: 'var(--epika-primary-header-size)',
              fontWeight: '700',
            }}
          >
            Edit Web Plugin
          </Typography>
        </Grid>
        <Grid item xs={12} md={6} lg={6}>
          <RHFTextField name="text" label="Text" multiline rows={4} />
        </Grid>
        <Grid item xs={12} sx={{ padding: '0px !important' }}></Grid>
        <Grid item xs={12} md={6}>
          <RHFTextField name="contactName" label="Contact Name" />
        </Grid>
        {uploadedImage && (
          <Grid item xs={12} sx={{ paddingTop: '0px !important' }}>
            <Box mt={2} position="relative">
              <Image
                src={uploadedImage || pluginsDetails?.data?.data?.image}
                alt="Uploaded Image"
                width={200}
                height={200}
                onClick={handleImageClick}
              />
              <input
                type="file"
                ref={fileInputRef}
                style={{ display: 'none' }}
                onChange={(e) => handleUpload(Array.from(e.target.files!))}
              />
            </Box>
          </Grid>
        )}

        <Grid item xs={12} md={6} lg={6} className={styles.adminButtonSpacing}>
          <Button
            type="submit"
            color="primary"
            variant="contained"
            style={{ margin: '20px 0', backgroundColor: 'var(--epika-primary-color)' }}
            className={styles.adminButtonBottom}
            disabled={methods.formState.isSubmitting || isPending}
            fullWidth
          >
            {isPending ? <CircularProgress size={24} sx={{ color: 'white' }} /> : 'Submit'}
          </Button>
        </Grid>
      </Grid>
    </FormProvider>
  );
};

export default Plugins;
