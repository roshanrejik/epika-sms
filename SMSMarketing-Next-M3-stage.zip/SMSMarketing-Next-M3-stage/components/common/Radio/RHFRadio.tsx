// RHFRadio.tsx
import React from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { Radio, FormControlLabel, FormHelperText } from '@mui/material';

type IProps = {
  name: string;
  label: string;
  value: any;
};

type Props = IProps;

export default function RHFRadio({ name, label, value }: Props) {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <div>
          <FormControlLabel
            sx={{
              '& .MuiRadio-root': {
                color: 'var(--epika-primary-color)',
              },
              '& .Mui-checked': {
                color: 'var(--epika-primary-color)',
              },
            }}
            control={<Radio {...field} checked={field.value === value} />}
            label={label}
            value={value}
          />
          {!!error && (
            <FormHelperText error sx={{ px: 2 }}>
              {error.message}
            </FormHelperText>
          )}
        </div>
      )}
    />
  );
}
