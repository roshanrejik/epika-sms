// RHFRadioGroup.tsx
import { useFormContext, Controller } from 'react-hook-form';
import {
  Radio,
  RadioGroup,
  FormHelperText,
  RadioGroupProps,
  FormControlLabel,
  Box,
} from '@mui/material';
import React from 'react';

type Option = {
  label: string;
  value: any;
  component?: React.ReactNode;
};

type IProps = {
  name: string;
  options: Option[];
};

type Props = IProps & RadioGroupProps;

export default function RHFRadioGroup({ name, options, ...other }: Props) {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <div>
          <RadioGroup
            {...field}
            row
            {...other}
            sx={{ display: 'flex', flexDirection: 'row', gap: 2 }}
          >
            {options.map((option, i) => (
              <Box sx={{ display: 'flex', flexDirection: 'column' }} key={i}>
                <FormControlLabel
                  key={option.value}
                  value={option.value}
                  control={
                    <Radio
                      sx={{
                        color: 'var(--epika-primary-color)',
                        '&.Mui-checked': {
                          color: 'var(--epika-primary-color)', // Set the color for the checked state
                        },
                      }}
                    />
                  }
                  label={option.label}
                />
                <div key={option.value}>{option.component}</div>
              </Box>
            ))}
          </RadioGroup>

          {!!error && (
            <FormHelperText error sx={{ px: 2 }}>
              {error.message}
            </FormHelperText>
          )}
        </div>
      )}
    />
  );
}
