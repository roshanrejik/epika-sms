import * as React from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import FormHelperText from '@mui/material/FormHelperText';
import Checkbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import { CustomFormControl, CustomOutlinedInput } from '@/constants/key';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

type Props = {
  name: string;
  label: string;
  multiple: boolean;
  options: string[];
};

export default function RHFSelectName({ name, options, label, multiple }: Props) {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      defaultValue={multiple ? [] : ''}
      render={({ field, fieldState }) => (
        <CustomFormControl fullWidth error={!!fieldState.error}>
          <InputLabel id={`${name}-label`}>{label}</InputLabel>
          <Select
            labelId={`${name}-label`}
            id={name}
            value={field.value}
            fullWidth
            onChange={(event: SelectChangeEvent<any>) => {
              const { value } = event.target;
              field.onChange(value);
            }}
            multiple={multiple}
            error={!!fieldState.error}
            label={label}
            input={<CustomOutlinedInput label={label} />}
            renderValue={(selected) => {
              if (multiple) {
                return (selected || []).join(', ');
              } else {
                return selected;
              }
            }}
            MenuProps={MenuProps}
          >
            {options.map((option) => (
              <MenuItem key={option} value={option}>
                {multiple ? (
                  <Checkbox
                    checked={field.value.includes(option)}
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)', // Set the color for the checked state
                      },
                    }}
                  />
                ) : null}
                <ListItemText primary={option} />
              </MenuItem>
            ))}
          </Select>
          {fieldState.error && (
            <FormHelperText sx={{ color: '#d32f2f' }}>{fieldState.error?.message}</FormHelperText>
          )}
        </CustomFormControl>
      )}
    />
  );
}
