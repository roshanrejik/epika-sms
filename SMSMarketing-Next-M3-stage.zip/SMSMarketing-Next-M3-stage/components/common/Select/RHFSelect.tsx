import * as React from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import FormHelperText from '@mui/material/FormHelperText';
import Checkbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import { CustomFormControl, CustomOutlinedInput } from '@/constants/key';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import InputAdornment from '@mui/material/InputAdornment';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

type Props = {
  name: string;
  label: string;
  multiple: boolean;
  options: { _id: string; name: string }[];
};

export default function RHFSelect({ name, options, label, multiple }: Props) {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      defaultValue={multiple ? [] : ''}
      render={({ field, fieldState }) => (
        <CustomFormControl fullWidth error={!!fieldState.error}>
          <InputLabel id={`${name}-label`}>{label}</InputLabel>
          <Select
            labelId={`${name}-label`}
            id={name}
            value={field.value}
            fullWidth
            onChange={(event: SelectChangeEvent<{ value: unknown }>) => {
              const { value } = event.target;
              field.onChange(value);
            }}
            multiple={multiple}
            error={!!fieldState.error}
            label={label}
            input={
              <CustomOutlinedInput
                label={label}
                endAdornment={
                  (multiple && (field.value as any[]).length > 0) || (!multiple && field.value) ? (
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="clear selection"
                        onClick={() => field.onChange(multiple ? [] : '')}
                        edge="end"
                        sx={{ marginRight: 1 }}
                      >
                        <CloseIcon />
                      </IconButton>
                    </InputAdornment>
                  ) : null
                }
              />
            }
            renderValue={(selected) => {
              if (multiple) {
                return (selected || [])
                  .map((selectedId: any) => {
                    const selectedOption = options.find((option) => option._id === selectedId);
                    return selectedOption ? selectedOption.name : '';
                  })
                  .join(', ');
              } else {
                const selectedOption = options.find((option: any) => option._id === selected);
                return selectedOption ? selectedOption.name : '';
              }
            }}
            MenuProps={MenuProps}
          >
            {options.map((option, i) => (
              <MenuItem key={option._id} value={option._id}>
                {multiple ? (
                  <Checkbox
                    key={i}
                    checked={field.value.includes(option._id)}
                    sx={{
                      color: 'var(--epika-primary-color)',
                      '&.Mui-checked': {
                        color: 'var(--epika-primary-color)', // Set the color for the checked state
                      },
                    }}
                  />
                ) : null}
                <ListItemText primary={option.name} />
              </MenuItem>
            ))}
          </Select>
          {fieldState.error && (
            <FormHelperText sx={{ color: '#d32f2f' }}>{fieldState.error?.message}</FormHelperText>
          )}
        </CustomFormControl>
      )}
    />
  );
}
