import { Controller, useFormContext } from 'react-hook-form';
import { TextFieldProps } from '@mui/material/TextField';
import { InputAdornment, IconButton } from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import React, { useState } from 'react';
import { StyledTextField } from '@/constants/key';
import styles from './TestFiels.module.css';

type Props = TextFieldProps & {
  name: string;
  borderRadius?: number | string;
};

export default function RHFTextField({
  name,
  helperText,
  type,
  borderRadius = 8,
  ...other
}: Props) {
  const { control } = useFormContext();

  const [showPassword, setShowPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <StyledTextField
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                {type === 'password' && (
                  <IconButton onClick={togglePasswordVisibility}>
                    {showPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
                  </IconButton>
                )}
              </InputAdornment>
            ),
            style: {
              borderRadius: borderRadius,
            },
          }}
          {...field}
          fullWidth
          type={showPassword && type === 'password' ? 'text' : type}
          value={field.value}
          onChange={(event) => {
            if (type === 'number') {
              const value = event.target.value;
              field.onChange(value === '' ? '' : Number(value));
            } else if (type === 'capitalize') {
              const value = event.target.value;
              const capitalizedValue = value.charAt(0).toUpperCase() + value.slice(1);
              field.onChange(capitalizedValue);
            } else {
              field.onChange(event.target.value);
            }
          }}
          error={!!error}
          helperText={error ? error?.message : helperText}
          style={{ minWidth: '250px' }}
          className={styles.noArrows}
          {...other}
        />
      )}
    />
  );
}
