import { Controller, useFormContext } from 'react-hook-form';
import { TextFieldProps } from '@mui/material/TextField';
import React from 'react';
import MaskedInput from 'react-text-mask';
import { StyledTextField } from '@/constants/key';

// ----------------------------------------------------------------------

type Props = TextFieldProps & {
  name: string;
  borderRadius?: number | string;
};

export default function RHFPhoneNumber({
  name,
  helperText,
  type,
  borderRadius = 8,
  ...other
}: Props) {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <StyledTextField
          fullWidth
          type={type}
          value={field?.value ? field?.value : ''}
          onChange={(e) => field.onChange(e.target.value)}
          defaultValue=""
          error={!!error}
          helperText={error ? error?.message : helperText}
          InputProps={{
            style: {
              borderRadius: borderRadius,
            },
            inputComponent: PhoneMask,
          }}
          {...other}
        />
      )}
    />
  );
}

export function PhoneMask(props: any) {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={(ref: any) => {
        if (inputRef) {
          inputRef.current = ref ? ref.inputElement : null;
        }
      }}
      guide={false}
      mask={[
        '+',
        '1',
        ' ',
        '(',
        /\d/,
        /\d/,
        /\d/,
        ')',
        ' ',
        /\d/,
        /\d/,
        /\d/,
        '-',
        /\d/,
        /\d/,
        /\d/,
        /\d/,
      ]}
      showMask={false}
    />
  );
}
