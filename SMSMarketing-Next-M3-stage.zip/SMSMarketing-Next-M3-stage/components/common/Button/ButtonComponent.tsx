import React from 'react';
import Button, { ButtonProps } from '@mui/material/Button';

type RHFButtonProps = ButtonProps;

const ButtonComponent: React.FC<RHFButtonProps> = (props) => {
  const { onClick, className, children, ...otherProps } = props;

  return (
    <Button
      className={className}
      onClick={onClick}
      variant="contained"
      size="large"
      color="primary"
      {...otherProps}
    >
      {children}
    </Button>
  );
};

export default ButtonComponent;
