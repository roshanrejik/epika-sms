import React from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import { Box } from '@mui/material';
import { styled } from '@mui/system';

const GlassLoaderContainer = styled(Box)({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  position: 'absolute',

  width: '100%',
  height: '50%',
  backdropFilter: 'blur(10px)',
  backgroundColor: 'rgba(255, 255, 255, 0.2)',
  zIndex: 1, // Ensure it appears above other content
});

const GlassLoader = () => {
  return (
    <GlassLoaderContainer>
      <CircularProgress sx={{ color: 'var(--epika-primary-color)' }} />
    </GlassLoaderContainer>
  );
};

export default GlassLoader;
