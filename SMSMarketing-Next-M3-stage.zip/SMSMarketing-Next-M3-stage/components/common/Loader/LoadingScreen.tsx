import React from 'react';
import Box from '@mui/material/Box';
import SplashScreen from '@/assets/EpikLogoWhitebackground.png';
import Image from 'next/image';
const LoadingScreen = () => {
  return (
    <Box
      component="div"
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        width: '100vw',
      }}
    >
      <Image src={SplashScreen.src} alt="splash-screen" width={393} height={97} />
    </Box>
  );
};

export default LoadingScreen;
