import React from 'react';
import './Loader.css'; // Keep the same styling

const Loader = () => {
  return (
    <div className="inline-loader">
      <div className="spinner"></div>
    </div>
  );
};

export default Loader;
