// FileUploadButton.tsx
import React from 'react';
import Dropzone from 'react-dropzone';
import EmptyUpload from './EmptyUpload';

export const FileUploadButton = ({ handleUpload }: any) => {
  return (
    <Dropzone onDrop={(acceptedFiles) => handleUpload(acceptedFiles)}>
      {({ getRootProps, getInputProps }) => (
        <section>
          <div
            {...getRootProps()}
            style={{
              cursor: 'pointer',
              padding: '20px',
              border: '2px dashed #ccc',
              textAlign: 'center',
            }}
          >
            <input {...getInputProps()} />
            <EmptyUpload />
          </div>
        </section>
      )}
    </Dropzone>
  );
};
