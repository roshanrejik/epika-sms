import React from 'react';
import { Stack, Typography } from '@mui/material';
import styles from './fileupload.module.css';
import Image from 'next/image';
import docUpload from '@/assets/icons/docUpload.svg';

const EmptyUpload = () => {
  return (
    <Stack className={styles.emptyUpload}>
      <Image alt="upload" height={26} width={26} src={docUpload} />
      <Typography variant="h6" className={styles.emptyTitleOne}>
        Drop or Browse Documents
      </Typography>
      <Typography variant="h6" className={styles.emptyTitleTwo}>
        Drop files here or click <span className={styles.browseText}>browse</span> through your
        machine
      </Typography>
    </Stack>
  );
};

export default EmptyUpload;
