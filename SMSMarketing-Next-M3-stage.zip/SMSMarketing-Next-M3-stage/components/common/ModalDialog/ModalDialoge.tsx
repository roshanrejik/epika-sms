import React from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField,
} from '@mui/material';
import styles from './dialoge.module.css';

type modalProps = {
  open: boolean;
  onClose?: () => void;
  title: string;
  dialogType: 'logout' | 'delete' | 'alert' | 'statusChange' | 'cancel' | 'deletelastDealer';
  contentText: string;
  actionButtonText: string;
  cancelText: 'Cancel' | 'close';
  onClickOK?: any;
  label?: string;
  handleReasonChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  reason?: string;
};

function ModalDialoge(props: modalProps) {
  const {
    open,
    onClose,
    title,
    dialogType,
    contentText,
    actionButtonText,
    cancelText,
    onClickOK,
    label,
    handleReasonChange,
    reason,
  } = props;
  return (
    <>
      <Dialog
        open={open}
        onClose={onClose}
        className={styles.modalDialogeMain}
        PaperProps={{
          sx: {
            borderRadius: '16px',
            boxShadow: '-10px 10px 14px #919EAB50;',
            width: '396px',
          },
        }}
      >
        <DialogTitle className={styles.dialogTitleStyleLogout}>{title}</DialogTitle>
        <DialogContent className={styles.dialogContentStyleLogout}>
          <DialogContentText
            className={styles.dialogConfirmationLogout}
            style={{
              marginRight: dialogType === 'alert' ? '80px' : '',
            }}
          >
            {contentText}
          </DialogContentText>
          {dialogType == 'statusChange' || dialogType == 'cancel' ? (
            <TextField
              id="outlined-basic"
              label={label}
              variant="outlined"
              placeholder=""
              value={reason}
              onChange={handleReasonChange}
              multiline
              maxRows={4}
              sx={{
                width: '356px',
                height: '138px',
                marginTop: '32px',
                '& .MuiOutlinedInput-root': {
                  height: '100%',
                  alignItems: 'unset !important',
                },
                '& .Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#637381 !important',
                  borderWidth: '1px !important',
                },
                '& .label.Mui-focused': {
                  color: 'red !important',
                },
                '& .css-12vsubh-MuiInputBase-root-MuiOutlinedInput-root': {
                  alignItems: 'unset !important',
                },
                '& .MuiInputLabel-outlined': {
                  color: '#637381 !important',
                  fontSize: '14px',
                },
              }}
            />
          ) : null}
        </DialogContent>
        <DialogActions className={styles.dialogActionsCommon}>
          {actionButtonText !== 'OK' && (
            <Button onClick={onClose} disableRipple className={styles.dialogCancelButtonStyleLogut}>
              {cancelText}
            </Button>
          )}
          {dialogType !== 'deletelastDealer' && (
            <Button
              autoFocus
              onClick={(e) => onClickOK(e)}
              disableRipple
              className={
                dialogType === 'delete' || dialogType === 'cancel'
                  ? styles.dialogdeleteButtonStyleLogout
                  : dialogType === 'statusChange'
                    ? styles.dialoglogoutButtonStyleLogout
                    : styles.dialoglogoutButtonStyleLogout
              }
              style={{ width: dialogType === 'alert' ? '88px' : '' }}
            >
              {actionButtonText}
            </Button>
          )}
        </DialogActions>
      </Dialog>
    </>
  );
}

export default ModalDialoge;
