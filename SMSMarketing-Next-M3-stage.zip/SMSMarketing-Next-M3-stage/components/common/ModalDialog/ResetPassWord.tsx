import React, { useEffect } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid } from '@mui/material';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import FormProvider from '@/context/FormProvider';
import RHFTextField from '../TextField/RHFTextField';
import styles from './dialoge.module.css';

type ModalProps = {
  open: boolean;
  onClose?: () => void;
  title: string;
  actionButtonText: string;
  cancelText: 'Cancel' | 'close';
  onClickOK: (data: any) => void;
};

const validationSchema = Yup.object().shape({
  password: Yup.string().required('Password is required'),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref('password')], 'Passwords must match')
    .required('Confirm Password is required'),
});

function ResetPassWord(props: ModalProps) {
  const { open, onClose, title, actionButtonText, cancelText, onClickOK } = props;
  const defaultValues = {
    password: '',
    confirmPassword: '',
  };
  const methods = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues,
  });

  const { reset } = methods;

  useEffect(() => {
    if (!open) {
      reset(defaultValues);
    }
  }, [open, reset]);

  const onSubmit = (data: any) => {
    // handle form submission
    onClickOK(data);
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      className={styles.modalDialogeMain}
      PaperProps={{
        sx: {
          borderRadius: '16px',
          boxShadow: '-10px 10px 14px #919EAB50;',
          width: '396px',
        },
      }}
    >
      <DialogTitle className={styles.dialogTitleStyleLogout}>{title}</DialogTitle>
      <DialogContent className={styles.dialogContentStyleLogout}>
        <FormProvider methods={methods} onSubmit={methods.handleSubmit(onSubmit)}>
          <Grid container spacing={3} className={styles.adminAgentsTable}>
            <Grid item xs={12} lg={12} mt={2}>
              <RHFTextField name="password" label="Password" type="password" />
            </Grid>
            <Grid item xs={12} lg={12}>
              <RHFTextField name="confirmPassword" label="Confirm Password" type="password" />
            </Grid>
          </Grid>
        </FormProvider>
      </DialogContent>
      <DialogActions className={styles.dialogActionsCommon}>
        {actionButtonText !== 'OK' && (
          <Button onClick={onClose} disableRipple className={styles.dialogCancelButtonStyleLogut}>
            {cancelText}
          </Button>
        )}
        <Button
          onClick={methods.handleSubmit(onSubmit)}
          disableRipple
          style={{
            background: 'var(--epika-primary-color)',
            color: 'white',
          }}
          className={styles.dialogOKButtonStyleLogut}
        >
          {actionButtonText}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default ResetPassWord;
