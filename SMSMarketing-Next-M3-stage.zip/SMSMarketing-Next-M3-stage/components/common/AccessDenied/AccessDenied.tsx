import React from 'react';
import { Box, Typography, Button, Container } from '@mui/material';
import LockIcon from '@mui/icons-material/Lock';

const AccessDenied = () => {
  return (
    <Container>
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        height="80vh"
        textAlign="center"
      >
        <LockIcon style={{ fontSize: 80, color: 'var(--epika-primary-color)' }} />
        <Typography variant="h4" gutterBottom>
          Access Denied
        </Typography>
        <Typography variant="body1" gutterBottom>
          You do not have access to this page.
        </Typography>
        <Button
          size="large"
          href="/"
          sx={{
            color: 'primary.contrastText',
            backgroundColor: 'var(--epika-primary-color)',

            borderRadius: '30px',
            minWidth: '150px',
            padding: '5px 20px',
            '&:hover': {
              bgcolor: 'var(--epika-primary-color)',
              color: 'white',
            },
          }}
        >
          Go to Home
        </Button>
      </Box>
    </Container>
  );
};

export default AccessDenied;
