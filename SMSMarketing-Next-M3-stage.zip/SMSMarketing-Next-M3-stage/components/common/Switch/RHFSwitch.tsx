import * as React from 'react';
import { FormControlLabel, FormHelperText } from '@mui/material';
import Switch from '@mui/material/Switch';
import { Controller, useFormContext } from 'react-hook-form';

type RHFSwitchProps = {
  name: string;
  label: string;
  errorMessage?: string; // New prop for error message
};

const RHFSwitch: React.FC<RHFSwitchProps> = ({ name, label, errorMessage }) => {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <>
          <FormControlLabel
            control={
              <Switch
                {...field}
                checked={field.value}
                onChange={(e) => field.onChange(e.target.checked)}
                sx={{
                  '& .MuiSwitch-switchBase.Mui-checked': {
                    color: 'var(--epika-primary-color)',
                  },
                }}
              />
            }
            label={label}
          />
          {error && errorMessage && <FormHelperText error>{errorMessage}</FormHelperText>}
        </>
      )}
    />
  );
};

export default RHFSwitch;
