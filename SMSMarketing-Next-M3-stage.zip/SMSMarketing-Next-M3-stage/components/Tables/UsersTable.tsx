'use client';
import React, { useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import GroupRoundedIcon from '@mui/icons-material/GroupRounded';
import AccountCircleRoundedIcon from '@mui/icons-material/AccountCircleRounded';
import {
  Box,
  Checkbox,
  IconButton,
  ListItemText,
  MenuItem,
  Popover,
  Switch,
  Typography,
} from '@mui/material';
import TablePagination from '@mui/material/TablePagination';
import { UserTableProps } from '@/@types/FormTypes';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useUserDelete, useUserSave } from '@/hooks/api/user.hooks';
import { showToast } from '../common/Toast/defaultToastOptions';
import { useRouter } from 'next/navigation';
import FilterListIcon from '@mui/icons-material/FilterList';
import { checkAvailability } from '@/utils/helpers';
import { useGetTeamList } from '@/hooks/api/team.hooks';
import { useGetRoleList } from '@/hooks/api/role.hooks';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import CloseIcon from '@mui/icons-material/Close';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import { useScreenHeight } from '@/context/ScreenHeightProvider';

export default function UsersTable({
  data,
  setData,
  userListBody,
  setUserListBody,
  totalCount,
  fromScreen,
  refetch,
  setTotalCount,
  debouncedChangeHandler,
  handleDeleteFromTeam,
}: any) {
  const router = useRouter();
  const { mutate: deleteUser } = useUserDelete(); // api to delete user
  const { mutate: saveAgent } = useUserSave(); // api to save user
  const { data: teamsList } = useGetTeamList();
  const { data: roleList } = useGetRoleList();
  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    id: string | null;
    flag: boolean;
  }>({
    id: null,
    flag: false,
  });
  const [rowsPerPage, setRowsPerPage] = React.useState(userListBody.limit);
  const [selectedTeams, setSelectedTeams] = useState<any>([]);
  const [selectedRoles, setSelectedRoles] = useState<any>([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const { availableHeight } = useScreenHeight();
  const [anchorAvailableFilterEl, setAnchorAvailableFilterEl] = useState(null);
  const [anchorTeamsFilterEl, setAnchorTeamsFilterEl] = useState(null);
  const [anchorRoleFilterEl, setAnchorRoleFilterEl] = useState(null);
  const [rowId, setRowId] = useState<null | string>(null); // New state to store the current row's id
  const [availableOpts, setAvailableOpts] = useState<any>([
    { label: 'Available', value: false, key: 'available', id: 0 },
    { label: 'Not Available', value: false, key: 'notAvailable', id: 1 },
  ]);

  const handleClose = () => {
    setAnchorEl(null); // Close the popover edit and delete
  };

  const handleCloseFilter = () => {
    setAnchorAvailableFilterEl(null);
    setAnchorTeamsFilterEl(null);
    setAnchorRoleFilterEl(null);
  }; // close the filter popup

  const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null, newPage: number) => {
    setUserListBody((prevState: any) => ({
      ...prevState,
      page: newPage,
    }));
  }; //page number change

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const newRowsPerPage = parseInt(event.target.value, 10);
    setRowsPerPage(newRowsPerPage);
    setUserListBody((prevState: any) => ({
      ...prevState,
      limit: newRowsPerPage, // Set the new rows per page
      page: 0, // Reset page to 1 when rows per page changes
    }));
  };

  const handleAction = (e: any, id: string) => {
    setAnchorEl(e.currentTarget);
    setRowId(id); // Store the current row's id
  }; // edit and delete

  const handleAvailableFilters = (e: any, id: string) => {
    setAnchorAvailableFilterEl(e.currentTarget);
    setRowId(id); // Store the current row's id
  };

  const handleTeamsFilters = (e: any, id: string) => {
    setAnchorTeamsFilterEl(e.currentTarget);
    setRowId(id); // Store the current row's id
  };

  const handleRoleFilters = (e: any, id: string) => {
    setAnchorRoleFilterEl(e.currentTarget);
    setRowId(id); // Store the current row's id
  };

  const onSuccess = (res: any) => {
    refetch();
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
    });
    const userListRequestBody = {
      ...userListBody,
      page: userListBody.page + 1,
    };

    debouncedChangeHandler(userListRequestBody);
    setAnchorEl(null);
  };

  const handleDelete = () => {
    setData((prevState: any) =>
      prevState.filter((item: any) => item._id !== showdeleteModelFlag.id),
    );
    setAnchorEl(null);
    setTotalCount((prev: any) => prev - 1);
    const payload = {
      _id: [showdeleteModelFlag.id],
    };
    deleteUser(payload, {
      onSuccess: onSuccess,
      onError: onError,
    });
    setShowdeleteModelFlag({ id: null, flag: false });
  }; //delete user
  const handleToggleAvailable = (e: any, id: string, status: boolean) => {
    e.preventDefault();
    setData((prevState: any) =>
      prevState.map((item: any) => (item._id === id ? { ...item, active: !status } : item)),
    );
    saveAgent({ _id: id, active: !status }, { onSuccess: onSuccess, onError: onError });
  };

  const handleEdit = (id: string) => {
    router.push('/admin/agents/add-agent?id=' + id);
  };

  const handleToggleAvailableAPI = (e: any, id: string, status: boolean) => {
    e.preventDefault();
    setAvailableOpts((prevState: any) =>
      prevState.map((item: any) => (item.id === id ? { ...item, value: !status } : item)),
    );
    setUserListBody((prevState: any) => ({
      ...prevState,
      active: checkAvailability(
        availableOpts.map((item: any) => (item.id === id ? { ...item, value: !status } : item)),
      ),
    }));
  };
  const handleSortClick = (field: string) => {
    setUserListBody((prevState: any) => ({
      ...prevState,
      sortField: field,
      sortOrder: userListBody.sortOrder == -1 ? 1 : -1,
    }));
  };

  const handleRole = (id: string) => {
    selectedRoles.includes(id)
      ? setSelectedRoles(selectedRoles.filter((role: any) => role !== id))
      : setSelectedRoles([...selectedRoles, id]);
    setUserListBody((prevState: any) => ({
      ...prevState,
      roleId: selectedRoles.includes(id)
        ? selectedRoles.filter((role: any) => role !== id)
        : [...selectedRoles, id],
    }));
  };
  const handleTeam = (id: string) => {
    selectedTeams.includes(id)
      ? setSelectedTeams(selectedTeams.filter((role: any) => role !== id))
      : setSelectedTeams([...selectedTeams, id]);
    setUserListBody((prevState: any) => ({
      ...prevState,
      teamId: selectedTeams.includes(id)
        ? selectedTeams.filter((role: any) => role !== id)
        : [...selectedTeams, id],
    }));
  };

  return (
    <>
      <TableContainer component={Paper}>
        <Box sx={{ height: availableHeight - 300, overflow: 'scroll' }}>
          <Table sx={{ minWidth: 65 }} aria-label="simple table">
            <TableHead>
              <TableRow sx={{ backgroundColor: 'rgba(0, 0, 0, 0.05)' }}>
                <TableCell align="left"></TableCell>
                <TableCell
                  align="left"
                  onClick={() => handleSortClick('firstName')}
                  sx={{
                    fontSize: 'var(--epika-primary-font-size)',
                    minWidth: '190px',
                    fontWeight: 700,
                  }}
                >
                  <span>FIRST NAME</span>
                  <IconButton
                    aria-label="Filter list"
                    sx={{
                      backgroundColor: userListBody.sortField === 'firstName' ? '#0000000A' : ``,
                    }}
                  >
                    {userListBody.sortField === 'firstName' ? (
                      userListBody.sortOrder == 1 ? (
                        <ArrowUpwardIcon />
                      ) : (
                        <ArrowDownwardIcon />
                      )
                    ) : (
                      <ArrowDownwardIcon />
                    )}
                  </IconButton>
                </TableCell>
                <TableCell
                  align="left"
                  onClick={() => handleSortClick('lastName')}
                  sx={{
                    fontSize: 'var(--epika-primary-font-size)',
                    minWidth: '190px',
                    fontWeight: 700,
                  }}
                >
                  <span>LAST NAME</span>
                  <IconButton
                    aria-label="Filter list"
                    sx={{
                      backgroundColor: userListBody.sortField === 'lastName' ? '#0000000A' : ``,
                    }}
                  >
                    {userListBody.sortField === 'lastName' ? (
                      userListBody.sortOrder == 1 ? (
                        <ArrowUpwardIcon />
                      ) : (
                        <ArrowDownwardIcon />
                      )
                    ) : (
                      <ArrowDownwardIcon />
                    )}
                  </IconButton>
                </TableCell>
                <TableCell
                  align="left"
                  onClick={() => handleSortClick('email')}
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>EMAIL</span>
                  <IconButton
                    aria-label="Filter list"
                    sx={{ backgroundColor: userListBody.sortField === 'email' ? '#0000000A' : `` }}
                  >
                    {userListBody.sortField === 'email' ? (
                      userListBody.sortOrder == 1 ? (
                        <ArrowUpwardIcon />
                      ) : (
                        <ArrowDownwardIcon />
                      )
                    ) : (
                      <ArrowDownwardIcon />
                    )}
                  </IconButton>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <span>ROLE</span>

                    <Popover
                      open={Boolean(anchorRoleFilterEl)}
                      anchorEl={anchorRoleFilterEl}
                      onClose={handleCloseFilter}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                      }}
                      transformOrigin={{
                        vertical: 'center',
                        horizontal: 'center',
                      }}
                      PaperProps={{
                        elevation: 2,
                      }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          padding: '1rem',
                        }}
                      >
                        {roleList?.data?.data?.map((opt: any) => (
                          <MenuItem
                            key={opt._id}
                            value={opt._id}
                            onClick={() => handleRole(opt._id)}
                          >
                            <Checkbox
                              checked={selectedRoles.includes(opt._id)}
                              onClick={() => handleRole(opt._id)}
                              sx={{
                                color: 'var(--epika-primary-color)',
                                '&.Mui-checked': {
                                  color: 'var(--epika-primary-color)', // Set the color for the checked state
                                },
                              }}
                            />
                            <ListItemText primary={opt.name} />
                          </MenuItem>
                        ))}
                      </Box>
                    </Popover>
                    <IconButton
                      onClick={(e) => handleRoleFilters(e, '3')}
                      aria-label="Filter list"
                      sx={{ backgroundColor: selectedRoles.length ? '#0000000A' : `` }}
                    >
                      <FilterListIcon />
                    </IconButton>
                  </Box>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <span>AVAILABLE</span>
                    <Popover
                      open={Boolean(anchorAvailableFilterEl)}
                      anchorEl={anchorAvailableFilterEl}
                      onClose={handleCloseFilter}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                      }}
                      transformOrigin={{
                        vertical: 'center',
                        horizontal: 'center',
                      }}
                      PaperProps={{
                        elevation: 2,
                      }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          padding: '1rem',
                        }}
                      >
                        {availableOpts?.map((opt: any) => (
                          <MenuItem
                            key={opt.key}
                            value={opt.value}
                            onClick={(e) => handleToggleAvailableAPI(e, opt.id, opt.value)}
                          >
                            <Checkbox
                              checked={opt.value}
                              sx={{
                                color: 'var(--epika-primary-color)',
                                '&.Mui-checked': {
                                  color: 'var(--epika-primary-color)', // Set the color for the checked state
                                },
                              }}
                            />
                            <ListItemText primary={opt.label} />
                          </MenuItem>
                        ))}
                      </Box>
                    </Popover>
                    <IconButton
                      onClick={(e) => handleAvailableFilters(e, '4')}
                      aria-label="Filter list"
                      sx={{
                        backgroundColor: availableOpts.some((opt: any) => opt.value)
                          ? '#0000000A'
                          : ``,
                      }}
                    >
                      <FilterListIcon />
                    </IconButton>
                  </Box>
                </TableCell>
                {fromScreen != 'team' && (
                  <TableCell align="left">
                    <Box
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        maxWidth: '250px',
                        fontSize: 'var(--epika-primary-font-size)',
                        fontWeight: 700,
                      }}
                    >
                      <span>TEAMS</span>

                      <Popover
                        open={Boolean(anchorTeamsFilterEl)}
                        anchorEl={anchorTeamsFilterEl}
                        onClose={handleCloseFilter}
                        anchorOrigin={{
                          vertical: 'bottom',
                          horizontal: 'center',
                        }}
                        transformOrigin={{
                          vertical: 'center',
                          horizontal: 'center',
                        }}
                        PaperProps={{
                          elevation: 2,
                        }}
                      >
                        <Box
                          sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            padding: '1rem',
                          }}
                        >
                          {teamsList?.data?.data?.map((opt: any) => (
                            <MenuItem
                              key={opt._id}
                              value={opt._id}
                              onClick={() => handleTeam(opt._id)}
                            >
                              <Checkbox
                                checked={selectedTeams.includes(opt._id)}
                                onClick={() => handleTeam(opt._id)}
                                sx={{
                                  color: 'var(--epika-primary-color)',
                                  '&.Mui-checked': {
                                    color: 'var(--epika-primary-color)', // Set the color for the checked state
                                  },
                                }}
                              />
                              <ListItemText primary={opt.name} />
                            </MenuItem>
                          ))}
                        </Box>
                      </Popover>
                      <IconButton
                        onClick={(e) => handleTeamsFilters(e, '4')}
                        aria-label="Filter list"
                        sx={{
                          backgroundColor: selectedTeams.length ? '#0000000A' : ``,
                        }}
                      >
                        <FilterListIcon />
                      </IconButton>
                    </Box>
                  </TableCell>
                )}

                {fromScreen != 'team' && (
                  <TableCell
                    align="left"
                    sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                  >
                    <span>ACTIONS</span>
                  </TableCell>
                )}
                {fromScreen == 'team' && (
                  <TableCell
                    align="left"
                    sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                  >
                    <span>{'  '}</span>
                  </TableCell>
                )}
              </TableRow>
            </TableHead>

            <TableBody sx={{ position: 'relative' }}>
              {data?.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={9}
                    align="center"
                    sx={{ fontSize: 'var(--epika-primary-font-size)' }}
                  >
                    <span>No records found</span>
                  </TableCell>
                </TableRow>
              ) : (
                data?.map((row: UserTableProps) => (
                  <TableRow
                    key={row._id}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell
                      align="left"
                      sx={{ color: 'gray', paddingRight: '0px', fontSize: '1rem' }}
                    >
                      <AccountCircleRoundedIcon
                        sx={{ fontSize: 'var(--epika-primary-icon-size)' }}
                      />
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.firstName}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.lastName}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.email}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.role?.name}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      <Switch
                        checked={row.active}
                        onChange={(e) => handleToggleAvailable(e, row?._id, row.active)}
                        sx={{
                          '& .MuiSwitch-switchBase.Mui-checked': {
                            color: 'var(--epika-primary-color)',
                          },
                          '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                            backgroundColor: 'var(--epika-primary-color)',
                          },
                        }}
                      />
                    </TableCell>
                    {fromScreen != 'team' && (
                      <TableCell
                        align="left"
                        sx={{
                          fontSize: 'var(--epika-primary-font-size)',
                          maxWidth: '250px',
                        }}
                      >
                        <Box sx={{ display: 'flex', alignItems: 'center', color: 'gray' }}>
                          <GroupRoundedIcon sx={{ marginRight: '5px' }} />
                          {row.teams.map((team) => team.name).join(', ')}
                        </Box>
                      </TableCell>
                    )}
                    {fromScreen != 'team' && (
                      <TableCell
                        align="left"
                        sx={{
                          fontSize: 'var(--epika-primary-icon-size)',
                          cursor: 'pointer',
                        }}
                        onClick={(e) => handleAction(e, row?._id)}
                      >
                        ...
                      </TableCell>
                    )}
                    {fromScreen == 'team' && (
                      <TableCell
                        align="left"
                        sx={{
                          fontSize: 'var(--epika-primary-font-size)',
                          cursor: 'pointer',
                        }}
                      >
                        <IconButton
                          onClick={() => handleDeleteFromTeam(row || '')}
                          sx={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            borderRadius: 2,
                            backgroundColor: '#80808017',
                          }}
                        >
                          <CloseIcon />
                          <Typography>REMOVE</Typography>
                        </IconButton>
                      </TableCell>
                    )}
                    <Popover
                      open={Boolean(anchorEl)}
                      anchorEl={anchorEl}
                      onClose={handleClose}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                      }}
                      transformOrigin={{
                        vertical: 'center',
                        horizontal: 'center',
                      }}
                      PaperProps={{
                        elevation: 2,
                      }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          padding: '1rem',
                          alignItems: 'flex-start', // Align items to the start
                        }}
                      >
                        <IconButton
                          onClick={() => handleEdit(rowId || '')}
                          sx={{
                            display: 'flex',
                            justifyContent: 'flex-start', // Align content to the start
                            borderRadius: 2,
                            width: '100%', // Ensure full width for proper alignment
                          }}
                        >
                          <EditIcon sx={{ marginRight: '0.5rem' }} />
                          <Typography>Edit</Typography>
                        </IconButton>
                        <IconButton
                          onClick={() => {
                            setShowdeleteModelFlag({ flag: true, id: rowId });
                          }}
                          sx={{
                            display: 'flex',
                            justifyContent: 'flex-start', // Align content to the start
                            borderRadius: 2,
                            width: '100%', // Ensure full width for proper alignment
                          }}
                        >
                          <DeleteIcon sx={{ marginRight: '0.5rem' }} />
                          <Typography>Delete</Typography>
                        </IconButton>
                      </Box>
                    </Popover>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Box>
        <TablePagination
          component="div"
          count={totalCount}
          page={userListBody.page}
          onPageChange={handleChangePage}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            '& .MuiTablePagination-toolbar': {
              fontSize: 'var(--epika-primary-font-size)',
            },
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows, & .MuiTablePagination-actions':
              {
                fontSize: 'var(--epika-primary-font-size)',
              },
            '& .MuiTablePagination-select': {
              fontSize: 'var(--epika-primary-font-size)',
            },
            '& .MuiTablePagination-selectIcon': {
              fontSize: 'var(--epika-primary-font-size)',
            },
          }}
        />
      </TableContainer>
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Delete"
        dialogType={'delete'}
        contentText={'Are you sure you want to delete the agent?'}
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
        onClickOK={() => handleDelete()}
      />{' '}
    </>
  );
}
