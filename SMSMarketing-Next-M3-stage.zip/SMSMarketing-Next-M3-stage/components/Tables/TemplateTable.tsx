import React, { useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Box, IconButton, Popover, Switch, Typography, Modal } from '@mui/material';
import TablePagination from '@mui/material/TablePagination';
import DeleteIcon from '@mui/icons-material/Delete';
import SettingsIcon from '@mui/icons-material/Settings';
import { showToast } from '../common/Toast/defaultToastOptions';
import { TeamTableProps } from '@/@types/FormTypes';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import { useDeleteCannedMessage } from '@/hooks/api/canned.hooks';
import CreateTemplateResponse from '../MsgTemplate/CreateTemplateResponse';

export default function TemplateTable({
  data,
  templateListBody,
  setTemplateListBody,
  totalCount,
  setData,
  handleToggleProperty,
  setTotalCount,
  customerFields, // Add customerFields prop
}: any) {
  const { mutate: deleteTemplateMessage } = useDeleteCannedMessage();
  const [rowsPerPage, setRowsPerPage] = useState(templateListBody.limit);
  const [anchorEl, setAnchorEl] = useState(null);
  const { availableHeight } = useScreenHeight();

  const [rowId, setRowId] = useState<null | string>(null);
  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    id: string | null;
    flag: boolean;
  }>({
    id: null,
    flag: false,
  });
  const [showEditForm, setShowEditForm] = useState(false); // State to show edit form
  const [editData, setEditData] = useState<TeamTableProps | null>(null); // State to hold the data for editing

  const handleClose = () => {
    setAnchorEl(null); // Close the popover
  };

  const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null, newPage: number) => {
    setTemplateListBody((prevState: any) => ({
      ...prevState,
      page: newPage,
    }));
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const newRowsPerPage = parseInt(event.target.value, 10);
    setRowsPerPage(newRowsPerPage);
    setTemplateListBody((prevState: any) => ({
      ...prevState,
      limit: newRowsPerPage,
      page: 0, // Reset page to 1 when rows per page changes
    }));
  };

  const handleAction = (e: any, id: string) => {
    setAnchorEl(e.currentTarget);
    setRowId(id); // Store the current row's id
  };

  const onSuccess = (res: any) => {
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
    setAnchorEl(null);
  };

  const handleDelete = () => {
    setData((prevState: any) =>
      prevState.filter((item: any) => item._id !== showdeleteModelFlag.id),
    );
    setTotalCount((prevState: any) => prevState - 1);
    setAnchorEl(null);

    const payload = {
      _id: [showdeleteModelFlag.id],
    };
    deleteTemplateMessage(payload, {
      onSuccess: onSuccess,
      onError: onError,
    });
    setShowdeleteModelFlag({ id: null, flag: false });
  };

  const handleEdit = (id: string) => {
    const templateData = data.find((template: TeamTableProps) => template._id === id);
    if (templateData) {
      setEditData(templateData);
      setShowEditForm(true); // Show the edit form
      setAnchorEl(null);
    }
  };

  const handleEditClose = () => {
    setShowEditForm(false);
    setEditData(null);
  };

  return (
    <>
      <TableContainer component={Paper}>
        <Box sx={{ height: availableHeight - 200, overflow: 'scroll' }}>
          <Table sx={{ minWidth: 65 }} aria-label="simple table">
            <TableHead>
              <TableRow sx={{ backgroundColor: 'rgba(0, 0, 0, 0.05)' }}>
                <TableCell align="left"></TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>NAME</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>TEXT</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>SHARED</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>ACTIONS</span>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {data?.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={7}
                    align="center"
                    sx={{ fontSize: 'var(--epika-primary-font-size)' }}
                  >
                    <span>No records found</span>
                  </TableCell>
                </TableRow>
              ) : (
                data.map((row: TeamTableProps) => (
                  <TableRow
                    key={row._id}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell
                      align="right"
                      sx={{
                        color: 'gray',
                        paddingRight: '0px',
                        fontSize: 'var(--epika-primary-icon-size)',
                      }}
                    ></TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.name}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.text}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      <Switch
                        checked={row.shared}
                        onChange={(e) => handleToggleProperty(e, row?._id, row.shared)}
                        sx={{
                          '& .MuiSwitch-switchBase.Mui-checked': {
                            color: 'var(--epika-primary-color)',
                          },
                          '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                            backgroundColor: 'var(--epika-primary-color)',
                          },
                        }}
                      />
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{ fontSize: 'var(--epika-primary-icon-size)', cursor: 'pointer' }}
                      onClick={(e) => handleAction(e, row?._id)}
                    >
                      ...
                    </TableCell>
                    <Popover
                      open={Boolean(anchorEl)}
                      anchorEl={anchorEl}
                      onClose={handleClose}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'center',
                      }}
                      PaperProps={{
                        elevation: 2,
                      }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          padding: '1rem',
                          alignItems: 'flex-start', // Align items to the start
                        }}
                      >
                        <IconButton
                          onClick={() => handleEdit(rowId || '')}
                          sx={{
                            display: 'flex',
                            justifyContent: 'flex-start', // Align content to the start
                            borderRadius: 2,
                            width: '100%', // Ensure full width for proper alignment
                          }}
                        >
                          <SettingsIcon sx={{ marginRight: '0.5rem' }} />
                          <Typography>Edit Template </Typography>
                        </IconButton>
                        <IconButton
                          onClick={() => setShowdeleteModelFlag({ flag: true, id: rowId })}
                          sx={{
                            display: 'flex',
                            justifyContent: 'flex-start', // Align content to the start
                            borderRadius: 2,
                            width: '100%', // Ensure full width for proper alignment
                          }}
                        >
                          <DeleteIcon sx={{ marginRight: '0.5rem' }} />
                          <Typography>Delete</Typography>
                        </IconButton>
                      </Box>
                    </Popover>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Box>
        <TablePagination
          component="div"
          count={totalCount}
          page={templateListBody.page}
          onPageChange={handleChangePage}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            '& .MuiTablePagination-toolbar': {
              fontSize: 'var(--epika-primary-font-size)',
            },
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows, & .MuiTablePagination-actions':
              {
                fontSize: 'var(--epika-primary-font-size)',
              },
            '& .MuiTablePagination-select': {
              fontSize: 'var(--epika-primary-font-size)',
            },
            '& .MuiTablePagination-selectIcon': {
              fontSize: 'var(--epika-primary-font-size)',
            },
          }}
        />
      </TableContainer>
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Delete"
        dialogType={'delete'}
        contentText={'Are you sure you want to delete the template response?'}
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
        onClickOK={() => handleDelete()}
      />
      <Modal
        open={showEditForm}
        onClose={handleEditClose}
        aria-labelledby="edit-modal-title"
        aria-describedby="edit-modal-description"
      >
        <Box
          sx={{
            p: 2,
            maxWidth: '550px',
            maxHeight: '500px',
            borderRadius: '10px',
            margin: 'auto',
            mt: '10%',
            bgcolor: 'background.paper',
          }}
        >
          {showEditForm && editData && (
            <CreateTemplateResponse
              id={editData._id}
              customerFields={customerFields}
              handleClose={handleEditClose}
              initialName={editData.name}
              initialText={editData.text}
              initialShared={editData.shared}
              onSave={(updatedData: any) => {
                setData((prevState: any) =>
                  prevState.map((item: any) => (item._id === updatedData._id ? updatedData : item)),
                );
                handleEditClose();
              }}
            />
          )}
        </Box>
      </Modal>
    </>
  );
}
