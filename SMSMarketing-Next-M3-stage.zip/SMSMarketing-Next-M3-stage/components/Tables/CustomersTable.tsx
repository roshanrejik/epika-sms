import React, { useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Box, IconButton, Popover, Typography } from '@mui/material';
import TablePagination from '@mui/material/TablePagination';
import DeleteIcon from '@mui/icons-material/Delete';
import { showToast } from '../common/Toast/defaultToastOptions';
import { useRouter } from 'next/navigation';
import SettingsIcon from '@mui/icons-material/Settings';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import { useDeleteCustomer } from '@/hooks/api/customer.hooks';
import { formatPhoneNumber } from '@/utils/helpers';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import ChatIcon from '@mui/icons-material/Chat';
import { usePostConversationSaveFind } from '@/hooks/api/conversation.hooks';
export default function CustomersTable({
  data,
  customerListBody,
  setCustomerListBody,
  totalCount,
  setTotalCount,
  setData,
}: any) {
  // const { mutate: deleteUser } = useTeamDelete();
  const [rowsPerPage, setRowsPerPage] = React.useState(customerListBody.limit);
  const [anchorEl, setAnchorEl] = useState(null);
  const { mutate: deleteCustomer } = useDeleteCustomer();
  const { mutate: postConversationSaveFind } = usePostConversationSaveFind();
  const [rowId, setRowId] = useState<null | string>(null); // New state to store the current row's id
  const { availableHeight } = useScreenHeight();

  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    id: string | null;
    flag: boolean;
  }>({
    id: null,
    flag: false,
  });
  const router = useRouter();

  const handleClose = () => {
    setAnchorEl(null); // Close the popover
  };

  const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null, newPage: number) => {
    setCustomerListBody((prevState: any) => ({
      ...prevState,
      page: newPage,
    }));
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const newRowsPerPage = parseInt(event.target.value, 10);
    setRowsPerPage(newRowsPerPage);
    setCustomerListBody((prevState: any) => ({
      ...prevState,
      limit: newRowsPerPage,
      page: 0, // Reset page to 1 when rows per page changes
    }));
  };

  const handleAction = (e: any, id: string) => {
    setAnchorEl(e.currentTarget);
    setRowId(id); // Store the current row's id
  };

  const onSuccess = (res: any) => {
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
    setAnchorEl(null);
  };

  const handleDelete = () => {
    setData((prevState: any) =>
      prevState.filter((item: any) => item._id !== showdeleteModelFlag.id),
    );
    setAnchorEl(null);
    setTotalCount((prev: any) => prev - 1);
    const payload = {
      _id: [showdeleteModelFlag.id],
    };
    deleteCustomer(payload, {
      onSuccess: onSuccess,
      onError: onError,
    });
    setShowdeleteModelFlag({ id: null, flag: false });
  };

  const handleEdit = (id: string) => {
    router.push('/customers/add-customer/?id=' + id);
  };

  const goToChat = (phoneNumber: string) => {
    postConversationSaveFind(
      { customerPhoneNumber: '+' + phoneNumber.replace(/\D/g, '') },
      {
        onSuccess: (res) => {
          router.push('/dashboard/?cId=' + res.data.conversationId);
        },
        onError: (err: any) => {
          showToast('error', err.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
        },
      },
    );
  };

  return (
    <>
      {' '}
      <TableContainer component={Paper}>
        <Box sx={{ height: availableHeight - 300, overflow: 'scroll' }}>
          <Table sx={{ minWidth: 65 }} aria-label="simple table">
            <TableHead>
              <TableRow sx={{ backgroundColor: 'rgba(0, 0, 0, 0.05)' }}>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>FIRST NAME</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>LAST NAME</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>EMAIL</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>PHONE NUMBER</span>
                </TableCell>

                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>ACTIONS</span>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {data?.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={7}
                    align="center"
                    sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 500 }}
                  >
                    <span>No records found</span>
                  </TableCell>
                </TableRow>
              ) : (
                data.map((row: any) => (
                  <TableRow
                    key={row._id}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.firstName}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.lastName}
                    </TableCell>

                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.email}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {formatPhoneNumber(row.phone)}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{ fontSize: 'var(--epika-primary-icon-size)', cursor: 'pointer' }}
                      onClick={(e) => handleAction(e, row?._id)}
                    >
                      ...
                    </TableCell>
                    <Popover
                      open={Boolean(anchorEl)}
                      anchorEl={anchorEl}
                      onClose={handleClose}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'center',
                      }}
                      PaperProps={{
                        elevation: 2,
                      }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          padding: '1rem',
                          alignItems: 'flex-start', // Align items to the start
                        }}
                      >
                        <IconButton
                          onClick={() => handleEdit(rowId || '')}
                          sx={{
                            display: 'flex',
                            justifyContent: 'flex-start', // Align content to the start
                            borderRadius: 2,
                            width: '100%', // Ensure full width for proper alignment
                          }}
                        >
                          <SettingsIcon sx={{ marginRight: '0.5rem' }} />
                          <Typography>Edit</Typography>
                        </IconButton>
                        <IconButton
                          onClick={() => setShowdeleteModelFlag({ flag: true, id: rowId })}
                          sx={{
                            display: 'flex',
                            justifyContent: 'flex-start', // Align content to the start
                            borderRadius: 2,
                            width: '100%', // Ensure full width for proper alignment
                          }}
                        >
                          <DeleteIcon sx={{ marginRight: '0.5rem' }} />
                          <Typography>Delete</Typography>
                        </IconButton>
                        <IconButton
                          onClick={() =>
                            goToChat(data.find((row: any) => row._id === rowId)?.phone)
                          }
                          sx={{
                            display: 'flex',
                            justifyContent: 'flex-start',
                            borderRadius: 2,
                            width: '100%',
                          }}
                        >
                          <ChatIcon sx={{ marginRight: '0.5rem' }} />
                          <Typography>Open chat</Typography>
                        </IconButton>
                      </Box>
                    </Popover>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Box>
        <TablePagination
          component="div"
          count={totalCount}
          page={customerListBody.page}
          onPageChange={handleChangePage}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            '& .MuiTablePagination-toolbar': {
              fontSize: 'var(--epika-primary-font-size)',
            },
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows, & .MuiTablePagination-actions':
              {
                fontSize: 'var(--epika-primary-font-size)',
              },
            '& .MuiTablePagination-select': {
              fontSize: 'var(--epika-primary-font-size)',
            },
            '& .MuiTablePagination-selectIcon': {
              fontSize: 'var(--epika-primary-font-size)',
            },
          }}
        />
      </TableContainer>{' '}
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Delete"
        dialogType={'delete'}
        contentText={'Are you sure you want to delete the customer?'}
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
        onClickOK={() => handleDelete()}
      />
    </>
  );
}
