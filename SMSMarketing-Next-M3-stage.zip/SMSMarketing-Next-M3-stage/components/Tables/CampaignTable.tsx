import React, { useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import GroupRoundedIcon from '@mui/icons-material/GroupRounded';
import { Box, IconButton, Popover, Tooltip, Typography } from '@mui/material';
import TablePagination from '@mui/material/TablePagination';
import DeleteIcon from '@mui/icons-material/Delete';
import { showToast } from '../common/Toast/defaultToastOptions';
import { useRouter } from 'next/navigation';
import SettingsIcon from '@mui/icons-material/Settings';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import { useCampaignDelete } from '@/hooks/api/campaign.hooks';

export default function CampaignTable({
  data,
  campaignListBody,
  setCampaignsListBody,
  totalCount,
  setData,
  setTotalCount,
}: any) {
  const { mutate: deleteCampaign } = useCampaignDelete();
  const [rowsPerPage, setRowsPerPage] = React.useState(campaignListBody.limit);
  const [anchorEl, setAnchorEl] = useState(null);
  const { availableHeight } = useScreenHeight();
  const [rowId, setRowId] = useState<null | string>(null);
  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    id: string | null;
    flag: boolean;
  }>({
    id: null,
    flag: false,
  });
  const [selectedRow, setSelectedRow] = useState<any>(null); // New state to store the selected row
  const router = useRouter();

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null, newPage: number) => {
    setCampaignsListBody((prevState: any) => ({
      ...prevState,
      page: newPage,
    }));
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const newRowsPerPage = parseInt(event.target.value, 10);
    setRowsPerPage(newRowsPerPage);
    setCampaignsListBody((prevState: any) => ({
      ...prevState,
      limit: newRowsPerPage,
      page: 0,
    }));
  };

  const getStatus = (status: string) => {
    switch (status) {
      case '0':
        return 'Draft';
      case '1':
        return 'Ready to send';
      case '2':
        return 'Sent';
      default:
        return 'Draft';
    }
  };

  const handleAction = (e: any, row: any) => {
    setAnchorEl(e.currentTarget);
    setRowId(row._id);
    setSelectedRow(row); // Store the selected row
  };

  const onSuccess = (res: any) => {
    setData((prevState: any) =>
      prevState.filter((item: any) => item._id !== showdeleteModelFlag.id),
    );
    setAnchorEl(null);
    setTotalCount((prev: any) => prev - 1);
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
    setAnchorEl(null);
  };

  const handleDelete = () => {
    const payload = {
      _id: [showdeleteModelFlag.id],
    };
    deleteCampaign(payload, {
      onSuccess: onSuccess,
      onError: onError,
    });
    setShowdeleteModelFlag({ id: null, flag: false });
  };

  const handleEdit = (id: string) => {
    router.push('/campaigns/add-campaign/create-campaign/?id=' + id);
  };

  return (
    <>
      <TableContainer component={Paper}>
        <Box sx={{ height: availableHeight - 300, overflow: 'scroll' }}>
          <Table sx={{ minWidth: 65 }} aria-label="simple table">
            <TableHead>
              <TableRow sx={{ backgroundColor: 'rgba(0, 0, 0, 0.05)' }}>
                <TableCell align="left"></TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>CAMPAIGN NAME</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>STATUS</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>CREATED AT</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>RECIPIENTS</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>RESPONSES</span>
                </TableCell>
                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>UNSUBSCRIBES</span>
                </TableCell>

                <TableCell
                  align="left"
                  sx={{ fontSize: 'var(--epika-primary-font-size)', fontWeight: 700 }}
                >
                  <span>ACTIONS</span>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {data?.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={8}
                    align="center"
                    sx={{ fontSize: 'var(--epika-primary-font-size)' }}
                  >
                    <span>No records found</span>
                  </TableCell>
                </TableRow>
              ) : (
                data.map((row: any) => (
                  <TableRow
                    key={row._id}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell
                      align="right"
                      sx={{
                        color: 'gray',
                        paddingRight: '0px',
                        fontSize: 'var(--epika-primary-icon-size)',
                      }}
                    >
                      <GroupRoundedIcon
                        sx={{
                          fontSize: 'var(--epika-primary-icon-size)',
                        }}
                      />
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      <div>{row.name}</div>
                      <div
                        style={{
                          fontSize: '0.9rem', // Reduced font size
                          color: 'gray', // Gray color
                        }}
                      >
                        {row.description}
                      </div>
                    </TableCell>

                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {getStatus(row.status)}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {new Intl.DateTimeFormat('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: '2-digit',
                      }).format(new Date(row.createdAt))}
                      ,{' '}
                      {new Intl.DateTimeFormat('en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: true,
                      }).format(new Date(row.createdAt))}{' '}
                      {
                        new Intl.DateTimeFormat('en-US', {
                          timeZoneName: 'short',
                        })
                          .formatToParts(new Date(row.createdAt))
                          .find((part) => part.type === 'timeZoneName')?.value
                      }
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.recipients}
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {row.responseCount} ({row.responsePercentage}%)
                    </TableCell>
                    <TableCell
                      align="left"
                      sx={{
                        fontSize: 'var(--epika-primary-font-size)',
                      }}
                    >
                      {`${row.unsubscribedCount} `}
                    </TableCell>

                    <TableCell
                      align="left"
                      sx={{ fontSize: 'var(--epika-primary-icon-size)', cursor: 'pointer' }}
                      onClick={(e) => handleAction(e, row)}
                    >
                      ...
                    </TableCell>
                    <Popover
                      open={Boolean(anchorEl)}
                      anchorEl={anchorEl}
                      onClose={handleClose}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'center',
                      }}
                      PaperProps={{
                        elevation: 2,
                      }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          padding: '1rem',
                          alignItems: 'flex-start',
                        }}
                      >
                        <Tooltip
                          title={
                            selectedRow?.status !== '0' ? 'Only Draft Campaign can be edited' : ''
                          }
                        >
                          <span>
                            {' '}
                            {/* Tooltip requires a span wrapper around the IconButton when it's disabled */}
                            <IconButton
                              onClick={() => handleEdit(rowId || '')}
                              sx={{
                                display: 'flex',
                                justifyContent: 'flex-start',
                                borderRadius: 2,
                                width: '100%',
                              }}
                              disabled={selectedRow?.status !== '0'} // Use the selectedRow status
                            >
                              <SettingsIcon sx={{ marginRight: '0.5rem' }} />
                              <Typography>Edit</Typography>
                            </IconButton>
                          </span>
                        </Tooltip>

                        <Tooltip
                          title={
                            selectedRow?.recipients != '0' && selectedRow?.status != '0'
                              ? 'Campaign Message Already Attached to Conversation'
                              : ''
                          }
                        >
                          <span>
                            {' '}
                            {/* Tooltip requires a span wrapper around the IconButton when it's disabled */}
                            <IconButton
                              onClick={() => setShowdeleteModelFlag({ flag: true, id: rowId })}
                              sx={{
                                display: 'flex',
                                justifyContent: 'flex-start',
                                borderRadius: 2,
                                width: '100%',
                              }}
                              disabled={
                                selectedRow?.recipients != '0' && selectedRow?.status != '0'
                              } // Use the selectedRow status
                            >
                              <DeleteIcon sx={{ marginRight: '0.5rem' }} />
                              <Typography>Delete</Typography>
                            </IconButton>
                          </span>
                        </Tooltip>
                      </Box>
                    </Popover>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Box>
        <TablePagination
          component="div"
          count={totalCount}
          page={campaignListBody.page}
          onPageChange={handleChangePage}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            '& .MuiTablePagination-toolbar': {
              fontSize: 'var(--epika-primary-font-size)',
            },
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows, & .MuiTablePagination-actions':
              {
                fontSize: 'var(--epika-primary-font-size)',
              },
            '& .MuiTablePagination-select': {
              fontSize: 'var(--epika-primary-font-size)',
            },
            '& .MuiTablePagination-selectIcon': {
              fontSize: 'var(--epika-primary-font-size)',
            },
          }}
        />
      </TableContainer>
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Delete"
        dialogType={'delete'}
        contentText={'Are you sure you want to delete the campaign?'}
        actionButtonText={'Delete'}
        cancelText={'Cancel'}
        onClickOK={() => handleDelete()}
      />
    </>
  );
}
