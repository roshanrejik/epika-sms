'use client';
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { Box, Button, CircularProgress, Grid, IconButton, Typography } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useRouter, useSearchParams } from 'next/navigation';
import styles from '../../styles/admin.module.css';
import { showToast } from '@/components/common/Toast/defaultToastOptions';
import FormProvider from '@/context/FormProvider';
import RHFTextField from '@/components/common/TextField/RHFTextField';
import RHFPhoneNumber from '@/components/common/TextField/RHFPhoneNumber';
import Tooltip from '@mui/material/Tooltip';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CustomProperties from './CustomProperties'; // Import the new component
import {
  useGetCustomerDetails,
  useGetTimezoneList,
  usePostCustomerSave,
} from '@/hooks/api/customer.hooks'; // Make sure these hooks exist
import { CustomerSchema } from '@/validations/Auth/CustomerSchema';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import RHFSelect from '../common/Select/RHFSelect';

const AddCustomer = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { availableHeight } = useScreenHeight();
  const id = searchParams.get('id');
  const { mutate: saveCustomer, isPending } = usePostCustomerSave(); // api to save customer
  const { data: customerDetails, isSuccess } = useGetCustomerDetails(id);
  const [customProperties, setCustomProperties] = useState([{ name: '', value: '' }]);
  const btnstyle = { margin: '20px 0', backgroundColor: 'var(--epika-primary-color)' };
  const { data } = useGetTimezoneList();
  const defaultValues = {
    _id: '',
    subscribed: false,
    lastName: '',
    firstName: '',
    phone: '',
    email: '',
    timezone: '',
    location: '',
    zipcode: '',
    customProperties: [], // Initialize with an empty array
  };

  const methods = useForm({
    resolver: yupResolver(CustomerSchema),
    defaultValues,
  });

  useEffect(() => {
    if (isSuccess && customerDetails && id) {
      const customerData = customerDetails?.data?.data;
      methods.reset(customerData);
      setCustomProperties(
        Object.entries(customerData.customProperties || {}).map(([name, value]) => ({
          name,
          value,
        })),
      );
    }
  }, [isSuccess, customerDetails, id, methods]);

  const onSuccess = (res: any) => {
    router.push('/customers/');
    showToast('success', res.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-success',
    });
  };

  const onError = (err: any) => {
    showToast('error', err.response.data.message, {
      autoClose: 2000,
      position: 'bottom-right',
      className: 'custom-toast-error',
    });
  };

  const onSubmit = (data: any) => {
    const formattedData = {
      ...data,
      phone: '+' + data.phone.replace(/\D/g, ''),
      customProperties: customProperties.reduce((acc, property) => {
        if (property.name && property.value) {
          acc[property.name] = property.value;
        }
        return acc;
      }, {}),
    };
    saveCustomer(formattedData, { onSuccess: (res: any) => onSuccess(res), onError: onError });
  };

  return (
    <>
      <FormProvider methods={methods} onSubmit={methods.handleSubmit(onSubmit)}>
        <Box className={styles.adminCustomersContainer} sx={{ p: 3 }}>
          <Box>
            <IconButton onClick={() => router.back()}>
              <ArrowBackIcon />
            </IconButton>
            CUSTOMERS PAGE
          </Box>
        </Box>
        <Grid
          container
          spacing={3}
          className={styles.adminCustomersTable}
          sx={{ p: 6, pt: 0, overflow: 'scroll', height: availableHeight - 60 + 'px' }}
        >
          <Grid item xs={12} className={styles.adminCustomersTableHeader}>
            <Typography
              sx={{
                fontSize: 'var(--epika-primary-header-size)',
                fontWeight: '700',
              }}
            >
              {id ? 'Edit Customer' : 'Add New Customer'}
            </Typography>
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFPhoneNumber
              name="phone"
              label="Phone Number"
              type="text"
              disabled={id ? true : false}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="firstName" label="First Name" type="capitalize" />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="lastName" label="Last Name" type="text" />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="email" label="Email" type="text" />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="zipcode" label="Zip Code" type="number" />
          </Grid>
          <Grid item xs={12} md={6} lg={4}>
            <RHFTextField name="location" label="Location" type="text" />
          </Grid>{' '}
          <Grid item xs={12} md={6} lg={4}>
            <Box display="flex" alignItems="center">
              <RHFSelect
                name="timezone"
                label="Timezone"
                multiple={false}
                options={data?.data?.data || []}
              />
              {id ? (
                <Tooltip title="If the customer has scheduled messages, they will be rescheduled based on the selected timezone">
                  <IconButton>
                    <InfoOutlinedIcon sx={{ color: 'var(--epika-primary-color)' }} />
                  </IconButton>
                </Tooltip>
              ) : null}
            </Box>
          </Grid>
          <Grid item xs={12} className={styles.adminCustomersTableHeader}>
            <Typography
              sx={{
                fontSize: '25px',
                fontWeight: '700',
              }}
            >
              Custom Properties
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <CustomProperties properties={customProperties} setProperties={setCustomProperties} />
          </Grid>
          <Grid item xs={12} className={styles.adminButtonSpacing} gap={2}>
            <Button
              type="submit"
              color="primary"
              variant="contained"
              style={btnstyle}
              className={styles.adminButtonBottom}
              disabled={isPending}
              fullWidth
            >
              {isPending ? <CircularProgress size={24} sx={{ color: 'white' }} /> : 'Submit'}
            </Button>
          </Grid>
        </Grid>
      </FormProvider>
    </>
  );
};

export default AddCustomer;
