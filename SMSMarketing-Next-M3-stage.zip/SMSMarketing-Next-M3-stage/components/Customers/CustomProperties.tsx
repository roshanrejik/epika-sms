import React from 'react';
import { Grid, IconButton, Button } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import { StyledTextField } from '@/constants/key';

const CustomProperties = ({ properties, setProperties }: any) => {
  const handleAddProperty = () => {
    setProperties([...properties, { name: '', value: '' }]);
  };

  const handleRemoveProperty = (index) => {
    const newProperties = properties.filter((_, i) => i !== index);
    setProperties(newProperties);
  };

  const handlePropertyChange = (index, field, value) => {
    const newProperties = properties.map((property, i) =>
      i === index ? { ...property, [field]: value } : property,
    );
    setProperties(newProperties);
  };

  return (
    <Grid container spacing={2}>
      {properties.map((property: any, index: any) => (
        <Grid item xs={12} key={index} container spacing={2} alignItems="center">
          <Grid item xs={5}>
            <StyledTextField
              label=" Property name"
              value={property.name}
              onChange={(e) => handlePropertyChange(index, 'name', e.target.value)}
              fullWidth
            />
          </Grid>
          <Grid item xs={5}>
            <StyledTextField
              label=" Property value"
              value={property.value}
              onChange={(e) => handlePropertyChange(index, 'value', e.target.value)}
              fullWidth
            />
          </Grid>
          <Grid item xs={2}>
            <IconButton onClick={() => handleRemoveProperty(index)}>
              <DeleteIcon />
            </IconButton>
          </Grid>
        </Grid>
      ))}
      <Grid item xs={12}>
        <Button
          onClick={handleAddProperty}
          startIcon={<AddIcon />}
          sx={{ color: 'var(--epika-primary-color)' }}
        >
          Add Property
        </Button>
      </Grid>
    </Grid>
  );
};

export default CustomProperties;
