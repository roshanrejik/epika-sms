'use client';
import {
  Button,
  InputAdornment,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  CircularProgress,
  Link,
  Grid,
} from '@mui/material';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import styles from '../../styles/admin.module.css';
import PeopleOutlineOutlinedIcon from '@mui/icons-material/PeopleOutlineOutlined';
import { StyledTextField } from '@/constants/key';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import GlassLoader from '../common/Loader/GlassLoader';
import {
  usePostCustomerList,
  useExportCustomers,
  useImportCustomers,
  useDownloadTemplate,
} from '@/hooks/api/customer.hooks';
import BrowserUpdatedIcon from '@mui/icons-material/BrowserUpdated';
import DriveFolderUploadIcon from '@mui/icons-material/DriveFolderUpload';
import debounce from 'lodash.debounce';
import CustomersTable from '../Tables/CustomersTable';
import { useRouter } from 'next/navigation';
import { showToast } from '../common/Toast/defaultToastOptions';

const Customers = () => {
  const { mutate: postCustomerList } = usePostCustomerList();
  const { mutate: exportCustomers } = useExportCustomers();
  const { mutate: importCustomers } = useImportCustomers();
  const { mutate: downloadTemplate } = useDownloadTemplate();
  const [customerListBody, setCustomerListBody] = useState({
    page: 0,
    limit: 10,
    search: '',
  });
  const router = useRouter();
  const [firstTimeFlag, setFirstTimeFlag] = useState(true);
  const [customerTableData, setCustomerTableData] = useState([]); // agent table data
  const [totalCount, setTotalCount] = useState(0); // total agent count
  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState<{
    id: string | null;
    flag: boolean;
  }>({
    id: null,
    flag: false,
  });

  const [importOpen, setImportOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);
  const [importReport, setImportReport] = useState<any>(null);
  const [importErrordownloadUrl, setimportErrordownloadUrl] = useState<any>(null);
  const [confirmCancelOpen, setConfirmCancelOpen] = useState(false);

  const onSuccess = (res: any) => {
    setCustomerTableData(res.data.data);
    setTotalCount(res.data.totalCount);
    setFirstTimeFlag(false);
  };

  const handleExport = () => {
    setExportLoading(true);
    exportCustomers(null, {
      onSuccess: (data: any) => {
        setExportLoading(false);
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `customers-${new Date().toLocaleString()}.csv`);
        document.body.appendChild(link);
        link.click();
      },
      onError: (err: any) => {
        setExportLoading(false);
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };

  const handleImport = () => {
    if (file) {
      setLoading(true);
      const formData = new FormData();
      formData.append('files', file);
      importCustomers(formData, {
        onSuccess: (data) => {
          setImportReport(data.report);
          setimportErrordownloadUrl(data.downloadUrl);
          setLoading(false);
          setImportOpen(false);
          reloadCustomerList();
        },
        onError: (err: any) => {
          setLoading(false);
          showToast('error', err.response.data.message, {
            autoClose: 2000,
            position: 'bottom-right',
            className: 'custom-toast-error',
          });
        },
      });
    }
  };

  const handleDownloadTemplate = () => {
    downloadTemplate(null, {
      onSuccess: (data: any) => {
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'customersTemplate.csv');
        document.body.appendChild(link);
        link.click();
      },
      onError: (err: any) => {
        showToast('error', err.response.data.message, {
          autoClose: 2000,
          position: 'bottom-right',
          className: 'custom-toast-error',
        });
      },
    });
  };

  const reloadCustomerList = () => {
    const customerListRequestBody = {
      ...customerListBody,
      page: 1, // Reset to the first page
    };
    postCustomerList(customerListRequestBody, { onSuccess });
  };

  const handleCancelImport = () => {
    setConfirmCancelOpen(true);
  };

  const confirmCancelImport = () => {
    setLoading(false);
    setFile(null);
    setImportOpen(false);
    setConfirmCancelOpen(false);
  };

  const debouncedChangeHandler = useMemo(
    () =>
      debounce(
        (customerListRequestBody) =>
          postCustomerList(customerListRequestBody, { onSuccess: onSuccess }),
        200,
      ),
    [],
  );
  const phoneNumberPattern = useCallback(/^\+?(\d[\d-() ]{7,}\d)$/, []);

  useEffect(() => {
    customerListBody.search = customerListBody?.search.trim();
    if (phoneNumberPattern.test(customerListBody?.search)) {
      customerListBody.search = customerListBody.search.replace(/[^+\d]/g, '');
    }
    const customerListRequestBody = {
      ...customerListBody,
      page: customerListBody.page + 1,
    };
    debouncedChangeHandler(customerListRequestBody);
  }, [customerListBody.page, customerListBody.search, customerListBody.limit]);

  return (
    <div>
      <Grid sx={{ margin: '10px 30px' }}>
        <Grid
          sx={{
            display: 'flex',
            margin: '0px 7px 0px',
            justifyContent: 'end',
            alignItems: 'center',
            padding: '20px',
            gap: 2,
          }}
        >
          <Button
            onClick={() => setImportOpen(true)}
            disabled={loading}
            sx={{ display: 'flex', alignItems: 'center', color: 'black' }} // Change button text and icon color to black
          >
            <BrowserUpdatedIcon sx={{ color: 'black' }} /> {/* Change icon color to black */}
            <Typography sx={{ marginLeft: '8px', color: 'black' }}>
              IMPORT CUSTOMERS
            </Typography>{' '}
            {/* Change text color to black */}
          </Button>
          <Button
            onClick={handleExport}
            disabled={exportLoading}
            sx={{ display: 'flex', alignItems: 'center', color: 'black' }} // Change button text and icon color to black
          >
            <DriveFolderUploadIcon sx={{ color: 'black' }} /> {/* Change icon color to black */}
            {exportLoading ? (
              <CircularProgress size={24} />
            ) : (
              <Typography sx={{ marginLeft: '8px', color: 'black' }}>EXPORT CUSTOMERS</Typography>
            )}{' '}
            {/* Change text color to black */}
          </Button>
        </Grid>

        <Grid
          sx={{
            padding: '20px',
            display: 'flex',
            justifyContent: 'space-between',
          }}
        >
          <Grid
            sx={{
              display: 'flex',
              columnGap: '10px',
            }}
          >
            <Button
              startIcon={<AddOutlinedIcon />}
              size="small"
              onClick={() => router.push('/customers/add-customer')}
              className={styles.adminButton}
              disabled={loading}
            >
              ADD CUSTOMER
            </Button>
            <Button
              startIcon={<PeopleOutlineOutlinedIcon />}
              size="small"
              disabled
              sx={{
                color: 'black',
                borderRadius: '30px',
                padding: '6px 20px',
                textTransform: 'none',
                '&:disabled': {
                  bgcolor: 'white',
                  color: 'black',
                },
              }}
            >
              {totalCount + ' Customer(s)'}
            </Button>
          </Grid>

          <StyledTextField
            id="outlined-basic"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchOutlinedIcon />
                </InputAdornment>
              ),
            }}
            placeholder="Search"
            value={customerListBody.search}
            onChange={(e) =>
              setCustomerListBody({ ...customerListBody, search: e.target.value, page: 0 })
            }
            variant="outlined"
            disabled={loading}
          />
        </Grid>

        <Grid sx={{ margin: '25px 25px 25px 25px' }}>
          {customerTableData.length == 0 && firstTimeFlag ? (
            <GlassLoader />
          ) : (
            <CustomersTable
              data={customerTableData}
              setData={setCustomerTableData}
              customerListBody={customerListBody}
              setCustomerListBody={setCustomerListBody}
              totalCount={totalCount}
              setTotalCount={setTotalCount}
              debouncedChangeHandler={debouncedChangeHandler}
            />
          )}
        </Grid>
      </Grid>
      <ModalDialoge
        open={showdeleteModelFlag.flag}
        onClose={() => setShowdeleteModelFlag({ flag: false, id: null })}
        title="Remove Agent"
        dialogType={'delete'}
        contentText={'Are you sure you want to remove the agent from team?'}
        actionButtonText={'Remove'}
        cancelText={'Cancel'}
        onClickOK={() => {}}
      />
      <Dialog
        open={importOpen}
        onClose={handleCancelImport}
        maxWidth="xs" // Increase modal size
        fullWidth // Ensure the dialog takes full width up to the maxWidth
      >
        <DialogTitle>Import Customers</DialogTitle>
        <DialogContent
          sx={{
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            padding: '8px 24px',
          }}
        >
          <input
            type="file"
            accept=".csv"
            onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)}
            disabled={loading}
            style={{ width: '100%', marginBottom: '16px' }} // Ensure input takes full width and add some margin
          />
          {loading && <CircularProgress />}
          <Typography variant="body1" sx={{ marginTop: '20px' }}>
            <Link
              component="button"
              variant="body2"
              onClick={handleDownloadTemplate}
              className={styles.adminLink} // Style this class in your CSS
              disabled={loading} // This will disable the link if loading is true
              sx={{ cursor: loading ? 'not-allowed' : 'pointer', color: loading ? 'grey' : 'blue' }}
            >
              Download Template
            </Link>
          </Typography>
        </DialogContent>
        <DialogActions sx={{ padding: '8px 24px' }}>
          <Button
            onClick={handleCancelImport}
            className={styles.adminButtonRevert}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleImport}
            className={!file || loading ? styles.adminButtonDisabled : styles.adminButton}
            disabled={!file || loading}
          >
            Import
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={confirmCancelOpen}
        maxWidth="xs" // Increase modal size
        onClose={() => setConfirmCancelOpen(false)}
      >
        <DialogTitle>Confirm Cancel</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to cancel the import process?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmCancelOpen(false)} className={styles.adminButton}>
            No
          </Button>
          <Button onClick={confirmCancelImport} className={styles.adminButton}>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      {importReport && (
        <Dialog open={true} onClose={() => setImportReport(null)}>
          <DialogTitle>Import Report</DialogTitle>
          <DialogContent>
            <Typography>Row Count: {importReport.rowCount}</Typography>
            <Typography>Count Errors: {importReport.countErrors}</Typography>
            <Typography>Inserted Count: {importReport.insertedCount}</Typography>
            <Typography>Insert Fails: {importReport.insertFails}</Typography>
            {importErrordownloadUrl && (
              <Typography variant="body1" sx={{ marginTop: '20px' }}>
                <Link
                  component="button"
                  variant="body2"
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = importErrordownloadUrl;
                    link.setAttribute(
                      'download',
                      `import_errors_${new Date().toLocaleString()}.csv`,
                    );
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link); // Clean up the DOM
                  }}
                  className={styles.adminLink} // You can style this class in your CSS
                >
                  Download Error File
                </Link>
              </Typography>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setImportReport(null)} className={styles.adminButton}>
              Close
            </Button>
          </DialogActions>
        </Dialog>
      )}
    </div>
  );
};

export default Customers;
