'use client';
import { Grid, IconButton, Toolbar, Typography } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import React from 'react';
import { useDispatch } from 'react-redux';
import { handleMenuOpen } from '@/lib/features/userSlice';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { getHeaderTitle } from '@/utils/helpers';
import HomeIcon from '@mui/icons-material/Home';
import Logo from '@/assets/EpikaLogoGreenbackground.png';
import Image from 'next/image';

const Header = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const id = searchParams.get('id');
  const readOnly = searchParams.get('readOnly');
  const handleNavigation = (path: string) => {
    router.push(path);
  };
  if (pathname.includes('auth')) {
    return null;
  }
  return (
    <Grid className="headerAppBar">
      <Toolbar style={{ display: 'flex', justifyContent: 'space-between', color: 'white' }}>
        <IconButton
          size="large"
          edge="start"
          color="inherit"
          aria-label="menu"
          sx={{ mr: 2 }}
          onClick={() => dispatch(handleMenuOpen())}
        >
          <MenuIcon />
        </IconButton>
        <IconButton
          size="large"
          edge="start"
          color="inherit"
          aria-label="home"
          onClick={() => handleNavigation('/dashboard/')}
        >
          <HomeIcon />
        </IconButton>
        <Typography
          variant="h5"
          sx={{
            margin: 'auto',
            fontWeight: '500',
          }}
        >
          {getHeaderTitle(pathname, id, readOnly)}
        </Typography>
        <Image src={Logo.src} alt={'logo'} width={100} height={64} />
      </Toolbar>
    </Grid>
  );
};

export default Header;
