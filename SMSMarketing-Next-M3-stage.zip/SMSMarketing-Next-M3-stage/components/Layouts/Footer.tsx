'use client';
import React from 'react';
import TagLine from '@/assets/EpikaLogoGEGRtaglineFC01.png';
import Image from 'next/image';
import { usePathname } from 'next/navigation';

const Footer = () => {
  const pathname = usePathname();
  if (pathname.includes('auth')) {
    return null;
  }
  return (
    <footer>
      <Image src={TagLine.src} alt="tagline" width={400} height={60} />
    </footer>
  );
};

export default Footer;
