'use client';
import { handleMenuOpen, logout, user } from '@/lib/features/userSlice';
import { Drawer, ListItem, ListItemText, Collapse, Box, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined';
import { usePathname, useRouter } from 'next/navigation';
import React, { useState } from 'react';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import CollectionsBookmarkIcon from '@mui/icons-material/CollectionsBookmark';
import { useDispatch, useSelector } from 'react-redux';
import Image from 'next/image';
import { logoutSession } from '@/utils';
import ModalDialoge from '../common/ModalDialog/ModalDialoge';
import SearchIcon from '@mui/icons-material/Search';
import HomeIcon from '@mui/icons-material/Home';
import ImportExportIcon from '@mui/icons-material/ImportExport';
import CampaignIcon from '@mui/icons-material/Campaign';
import ExtensionIcon from '@mui/icons-material/Extension';
import { useScreenHeight } from '@/context/ScreenHeightProvider';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import PieChartOutlineIcon from '@mui/icons-material/PieChartOutline';
const SiderBar = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const { availableHeight } = useScreenHeight();

  const pathname = usePathname();
  const { menuOpen, data } = useSelector(user);

  const [adminOpen, setAdminOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);

  const [showdeleteModelFlag, setShowdeleteModelFlag] = useState(false);

  const handleNavigation = (path: string) => {
    router.push(path);
    dispatch(handleMenuOpen());
  };

  const handleAdminClick = () => {
    setAdminOpen(!adminOpen);
  };

  const handleToolsClick = () => {
    setToolsOpen(!toolsOpen);
  };

  const handleLogout = () => {
    dispatch(logout());
    logoutSession();
    dispatch(handleMenuOpen());
  };

  if (pathname.includes('auth')) {
    return null;
  }
  return (
    <>
      {' '}
      <Drawer
        open={menuOpen}
        sx={{
          width: '350px', // Adjust the width as needed
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: '250px', // Adjust the width as needed
            boxSizing: 'border-box',
            overflow: 'hidden',
            backgroundColor: 'var(--epika-primary-color)',
            color: 'white',
            justifyContent: 'space-between',
          },
        }}
        onClose={() => {
          dispatch(handleMenuOpen());
        }}
      >
        <div style={{ textAlign: 'center', paddingBottom: '20px' }}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'end',
              padding: '10px',
            }}
          >
            <CloseIcon
              onClick={() => dispatch(handleMenuOpen())}
              sx={{ cursor: 'pointer', marginRight: '8px' }}
            />
          </Box>
          <Image
            src="https://media.istockphoto.com/id/1223671392/vector/default-profile-picture-avatar-photo-placeholder-vector-illustration.jpg?s=612x612&w=0&k=20&c=s0aTdmT5aU6b8ot7VKm11DeID6NctRCpB755rA1BIP0="
            alt="Avatar"
            width={100}
            height={100}
            style={{
              borderRadius: '50%',
              margin: '20px auto',
              display: 'block',
            }}
          />

          <Typography variant="h5" gutterBottom>
            {data?.name}
          </Typography>
          <div style={{ height: availableHeight - 150, overflow: 'hidden', overflowY: 'scroll' }}>
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              <ListItem button onClick={handleAdminClick}>
                <AdminPanelSettingsOutlinedIcon sx={{ marginRight: '8px' }} />{' '}
                <ListItemText primary="Admin" />
                {adminOpen ? <ExpandLess /> : <ExpandMore />}
              </ListItem>

              <Collapse in={adminOpen} timeout="auto" unmountOnExit sx={{ ml: '15px' }}>
                <ListItem button onClick={() => handleNavigation('/admin/agents/')}>
                  <PersonOutlineOutlinedIcon sx={{ marginRight: '8px' }} />{' '}
                  <ListItemText primary="Agents" />
                </ListItem>
                <ListItem button onClick={() => handleNavigation('/admin/teams/')}>
                  <GroupOutlinedIcon sx={{ marginRight: '8px' }} />
                  <ListItemText primary="Teams" />
                </ListItem>
                <ListItem button onClick={() => handleNavigation('/admin/roles-and-permissions/')}>
                  <LockOutlinedIcon sx={{ marginRight: '8px' }} />
                  <ListItemText primary="Roles & Permissions" />
                </ListItem>
              </Collapse>
              <ListItem button onClick={() => handleNavigation('/campaigns/')}>
                <CampaignIcon sx={{ marginRight: '8px' }} /> <ListItemText primary="Campaigns" />
              </ListItem>
              <ListItem button onClick={() => handleNavigation('/customers/')}>
                <SearchIcon sx={{ marginRight: '8px' }} /> <ListItemText primary="Customers" />
              </ListItem>
              <ListItem button onClick={() => handleNavigation('/dashboard/')}>
                <HomeIcon sx={{ marginRight: '8px' }} /> <ListItemText primary="Dashboard" />
              </ListItem>
              <ListItem button onClick={() => handleNavigation('/followups/')}>
                <CalendarMonthIcon sx={{ marginRight: '8px' }} />{' '}
                <ListItemText primary="Follow-Ups" />
              </ListItem>
              <ListItem button onClick={handleToolsClick}>
                <LightbulbIcon sx={{ marginRight: '8px' }} /> <ListItemText primary="Tools" />
                {toolsOpen ? <ExpandLess /> : <ExpandMore />}
              </ListItem>
              <Collapse in={toolsOpen} timeout="auto" unmountOnExit sx={{ ml: '15px' }}>
                <ListItem button onClick={() => handleNavigation('/analytics/')}>
                  <PieChartOutlineIcon sx={{ marginRight: '8px' }} />{' '}
                  <ListItemText primary="Analytics" />
                </ListItem>
                <ListItem button onClick={() => handleNavigation('/canned/')}>
                  <CollectionsBookmarkIcon sx={{ marginRight: '8px' }} />{' '}
                  <ListItemText primary="Canned Responses" />
                </ListItem>
                <ListItem button onClick={() => handleNavigation('/importexport/')}>
                  <ImportExportIcon sx={{ marginRight: '8px' }} />{' '}
                  <ListItemText primary="Import / Export" />
                </ListItem>
                <ListItem button onClick={() => handleNavigation('/plugins/')}>
                  <ExtensionIcon sx={{ marginRight: '8px' }} />{' '}
                  <ListItemText primary="Web Plugins" />
                </ListItem>
              </Collapse>
            </Box>
          </div>
        </div>
        <ListItem button onClick={() => setShowdeleteModelFlag(true)} sx={{ mb: '15px' }}>
          <CloseIcon sx={{ marginRight: '8px' }} />
          <ListItemText primary="Logout" />
        </ListItem>
      </Drawer>
      <ModalDialoge
        open={showdeleteModelFlag}
        onClose={() => setShowdeleteModelFlag(false)}
        title="Logout"
        dialogType={'delete'}
        contentText={'Are you sure you want to logout?'}
        actionButtonText={'Logout'}
        cancelText={'Cancel'}
        onClickOK={() => handleLogout()}
      />
    </>
  );
};

export default SiderBar;
