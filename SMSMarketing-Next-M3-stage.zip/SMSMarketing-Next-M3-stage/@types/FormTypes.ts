export interface ValidationEmailProps {
  email?: string;
}

export interface UserTableProps {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: {
    name: string;
  };
  active: boolean;
  teams: {
    name: string;
  }[];
}
export interface TeamTableProps {
  _id: string;
  shared: boolean;
  createdAt: string;
  isDelete: boolean;
  email: string;
  text: string;
  updatedAt: string;
  name: 'string';
  membersCount: number;
  members: {
    _id: string;
    name: string;
  }[];
}

export interface AgentAddFormValuesProps {
  firstName: string;
  lastName?: string;
  jobTitle?: string;
  username: string;
  password: string;
  email: string;
  phone: string;
  role: string;
  teams: string[];
}
export interface AgentEditFormValuesProps {
  firstName: string;
  lastName?: string;
  jobTitle?: string;
  username: string;
  email: string;
  phone: string;
  role: string;
  teams: string[];
}

export interface TeamAddFormValuesProps {
  name: string;
  members: string[];
}

export interface TeamEditFormValuesProps {
  name: string;
  members: string[];
}

export interface SettingsEditFormValuesProps {
  responsetype: string;
}

export interface SettingsAddFormValuesProps {
  responsetype: string;
}
